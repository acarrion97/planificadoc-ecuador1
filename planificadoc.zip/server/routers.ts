import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { topicsRouter } from "./topics-router";
import { pcaRouter } from "./pca-router";
import { pcaTrimestralRouter } from "./pca-trimestral-router";
import { inicialRouter } from "./inicial-router";
import { adaptacionesRouter } from "./adaptaciones-router";
import { btRouter } from "./bt-router";
import { cncRouter } from "./cnc-router";
import { evaluacionRouter } from "./evaluacion-router";
import { dcdDesagregacionesRouter } from "./dcd-desagregacion-router";
import { importarFormatoRouter } from "./importar-formato-router";

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  topics: topicsRouter,
  pca: pcaRouter,
  pcaTrimestral: pcaTrimestralRouter,
  inicial: inicialRouter,
  adaptaciones: adaptacionesRouter,
  bt: btRouter,
  cnc: cncRouter,
  evaluacion: evaluacionRouter,
  dcdDesagregaciones: dcdDesagregacionesRouter,
  importarFormato: importarFormatoRouter,
});

export type AppRouter = typeof appRouter;
