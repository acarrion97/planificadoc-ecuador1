import {
  Planificacion, AREAS_INFO, SUBNIVEL_NAMES,
  AdaptacionCurricular, TipoNEE, GradoAdaptacion,
  TIPOS_NEE_INFO, GRADO_ADAPTACION_INFO,
} from "../data/types";
import type { DUAActividad } from "../data/types";
import type { PlanUnidadTrabajoBT } from "../data/types-bt";
import type { PlanConectaNivelaCrea } from "../data/types-cnc";
import { buscarPorCodigo as cncBuscarPorCodigo } from "../data";
import { obtenerFiguraPorId as obtenerFiguraPorIdBT } from "../data/bachillerato-tecnico";
import { INSERCIONES_CURRICULARES } from "../data/inserciones-curriculares";
import { COMPETENCIAS, METODOLOGIAS_ACTIVAS, TECNICAS_EVALUACION, ESTILOS_APRENDIZAJE } from "../data/secciones-planificacion";
import { HABILIDADES_SOCIOEMOCIONALES } from "../data/habilidades-socioemocionales";
import { iconosDestrezaHTML } from "./dcd-iconos";

/**
 * Genera el HTML con formato oficial del Ministerio de Educación de Ecuador 2026-2027
 * Planificación Microcurricular por Trimestre
 */
export function generarHTMLPlanificacion(plan: Planificacion): string {
  const areaInfo = AREAS_INFO[plan.destreza.area];
  const subnivelName = SUBNIVEL_NAMES[plan.destreza.subnivel];
  const isEFL = plan.destreza.area === "EFL";
  const fechaFormateada = new Date(plan.createdAt).toLocaleDateString(isEFL ? "en-US" : "es-EC", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  // Competencias como iconos/badges
  const competenciasBadgesHTML = (() => {
    if (!plan.competencias || plan.competencias.length === 0) return "";
    const badgeMap: Record<string, { label: string; color: string }> = {
      matematicas: { label: "CM", color: "#7C3AED" },
      comunicacionales: { label: "C", color: "#059669" },
      digitales: { label: "CD", color: "#2563EB" },
      socioemocionales: { label: "CS", color: "#DC2626" },
    };
    return plan.competencias.map((id: string) => {
      const badge = badgeMap[id];
      if (!badge) return "";
      return `<span style="display:inline-block;background:${badge.color};color:white;font-size:7px;font-weight:bold;padding:1px 4px;border-radius:3px;margin-right:3px;">${badge.label}</span>`;
    }).join("");
  })();

  // Habilidades socioemocionales
  const habHTML = (() => {
    const ids = plan.habilidadesSocioemocionales || [];
    if (ids.length === 0) return isEFL ? "Not specified" : "No especificadas";
    return '<ul style="margin:0;padding-left:16px;">' + ids.map(id => {
      const hab = HABILIDADES_SOCIOEMOCIONALES.find(h => h.id === id);
      return hab ? `<li>${isEFL ? hab.nameEN : hab.nombre}</li>` : "";
    }).filter(Boolean).join("") + "</ul>";
  })();

  // Estilos de aprendizaje con porcentajes
  const estilosPctHTML = (() => {
    const pct = plan.estilosAprendizajePorcentaje;
    if (!pct) return "";
    return `
      <tr>
        <td style="width:25%;font-weight:bold;font-size:8.5px;">VISUAL: ${pct.visual}%</td>
        <td style="width:25%;font-weight:bold;font-size:8.5px;">AUDITIVO: ${pct.auditivo}%</td>
        <td style="width:25%;font-weight:bold;font-size:8.5px;">LECTOR-ESCRITOR: ${pct.lectorEscritor}%</td>
        <td style="width:25%;font-weight:bold;font-size:8.5px;">KINESTÉSICO: ${pct.kinestesico}%</td>
      </tr>
    `;
  })();

  // Construir las actividades ERCA con DUA squares
  let actividadesHTML = "";
  if (plan.temaSeleccionado?.estructura) {
    const est = plan.temaSeleccionado.estructura;
    const fases = [
      { key: "experiencia" as const, label: isEFL ? "EXPERIENCE" : "EXPERIENCIA", cssClass: "experiencia" },
      { key: "reflexion" as const, label: isEFL ? "REFLECTION" : "REFLEXIÓN", cssClass: "reflexion" },
      { key: "conceptualizacion" as const, label: isEFL ? "CONCEPTUALIZATION" : "CONCEPTUALIZACIÓN", cssClass: "conceptualizacion" },
      { key: "aplicacion" as const, label: isEFL ? "APPLICATION" : "APLICACIÓN", cssClass: "aplicacion" },
    ];

    actividadesHTML = fases.map(fase => {
      const data = est[fase.key];
      if (!data) return "";
      const actividades = data.actividades || [];
      const duaActividades = data.duaActividades || [];

      const actItems = actividades.map((act: string, idx: number) => {
        const dua = duaActividades[idx] || { representacion: false, accionExpresion: false, implicacion: false };
        // Limpiar texto: remover indicadores DUA del texto
        const cleanAct = act
          .replace(/\s*\(\s*I\s*:\s*(true|false)\s*,\s*R\s*:\s*(true|false)\s*,\s*A\s*:\s*(true|false)\s*\)\s*/gi, "")
          .replace(/\s*\[\s*I\s*:\s*(true|false)\s*,\s*R\s*:\s*(true|false)\s*,\s*A\s*:\s*(true|false)\s*\]\s*/gi, "")
          .replace(/\s*DUA\s*:\s*\{[^}]*\}\s*/gi, "")
          .replace(/\s*\(DUA[^)]*\)\s*/gi, "")
          .trim();
        const squares = `
          <span class="dua-sq" style="background:${dua.representacion ? '#EC4899' : '#EC489940'};"></span>
          <span class="dua-sq" style="background:${dua.accionExpresion ? '#1E3A5F' : '#1E3A5F40'};"></span>
          <span class="dua-sq" style="background:${dua.implicacion ? '#22C55E' : '#22C55E40'};"></span>
        `;
        return `<li>${idx + 1}. ${cleanAct} ${squares}</li>`;
      }).join("");

      return `
        <div class="fase">
          <div class="fase-header ${fase.cssClass}">${fase.label} (${data.duracion})</div>
          <div class="fase-label">${isEFL ? "Activities:" : "Actividades:"}</div>
          <ul>${actItems}</ul>
        </div>
      `;
    }).join("");
  } else {
    actividadesHTML = `<p>${plan.actividades || (isEFL ? "Not specified" : "No especificadas")}</p>`;
  }

  // Recursos
  const recursosTexto = plan.temaSeleccionado?.recursos
    ? plan.temaSeleccionado.recursos.join(", ")
    : plan.recursos || (isEFL ? "Not specified" : "No especificados");

  // Evaluación
  const evaluacionTexto = plan.temaSeleccionado?.evaluacionFormativa
    ? plan.temaSeleccionado.evaluacionFormativa
    : plan.evaluacion || (isEFL ? "Not specified" : "No especificada");

  // Indicadores de evaluación
  const indicadoresHTML = plan.destreza.indicadoresEvaluacion
    .map((ind) => `<li>${ind}</li>`)
    .join("");

  // Criterios de evaluación
  const criteriosHTML = plan.destreza.criteriosEvaluacion
    .map((crit) => `<li>${crit}</li>`)
    .join("");

  // Objetivos
  const objetivosHTML = plan.destreza.objetivos
    .map((obj) => `<li>${obj}</li>`)
    .join("");

  // Metodologías activas
  const metodologiasHTML = (() => {
    if (!plan.metodologiasActivas || plan.metodologiasActivas.length === 0) return "";
    return '<ul style="margin:0;padding-left:16px;">' + plan.metodologiasActivas.map((id: string) => {
      const met = METODOLOGIAS_ACTIVAS.find(m => m.id === id);
      return met ? `<li>${isEFL ? met.nameEN : met.nombre}</li>` : '';
    }).join('') + '</ul>';
  })();

  return `<!DOCTYPE html>
<html lang="${isEFL ? 'en' : 'es'}">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${isEFL ? "Microcurricular Lesson Plan" : "Planificación Microcurricular"} - ${plan.destreza.codigo}</title>
  <style>
    @page {
      size: A4 landscape;
      margin: 10mm 8mm 10mm 8mm;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }

    body {
      font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
      font-size: 9px;
      color: #1a1a1a;
      line-height: 1.35;
      background: #fff;
    }

    /* ===== ENCABEZADO ===== */
    .header-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 6px;
    }

    .sello {
      font-size: 9px;
      font-weight: bold;
      color: #003366;
      border: 1px solid #003366;
      padding: 4px 8px;
      text-transform: uppercase;
    }

    .institucion-nombre {
      text-align: center;
      font-size: 12px;
      font-weight: bold;
      color: #003366;
      text-transform: uppercase;
    }

    .anio-lectivo {
      font-size: 11px;
      font-weight: bold;
      color: #003366;
    }

    /* ===== TÍTULO PRINCIPAL ===== */
    .titulo-principal {
      background: #D4A5C7;
      color: #1a1a1a;
      text-align: center;
      padding: 5px 10px;
      font-size: 10px;
      font-weight: bold;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 6px;
      border: 1px solid #999;
    }

    /* ===== SECCIÓN TÍTULOS ===== */
    .seccion-titulo {
      background: #D4A5C7;
      color: #1a1a1a;
      padding: 3px 8px;
      font-size: 9px;
      font-weight: bold;
      text-transform: uppercase;
      letter-spacing: 0.3px;
      margin-bottom: 0;
      border: 1px solid #999;
      border-bottom: none;
    }

    /* ===== TABLAS ===== */
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 6px;
    }

    table td, table th {
      border: 1px solid #666;
      padding: 3px 5px;
      font-size: 8.5px;
      vertical-align: top;
    }

    table th {
      background: #D4A5C7;
      color: #1a1a1a;
      font-weight: bold;
      text-align: center;
      font-size: 8px;
      text-transform: uppercase;
      padding: 4px 3px;
    }

    .label {
      background: #F5E6F0;
      font-weight: bold;
      color: #1a3c5e;
      font-size: 8px;
    }

    .value {
      font-size: 8.5px;
      color: #1a1a1a;
    }

    /* ===== TABLA PRINCIPAL ===== */
    .tabla-principal th {
      background: #D4A5C7;
      color: #1a1a1a;
      font-size: 7.5px;
      padding: 5px 3px;
      text-transform: uppercase;
    }

    .tabla-principal td {
      font-size: 8.5px;
      padding: 5px;
    }

    .col-destreza { width: 20%; }
    .col-indicadores { width: 18%; }
    .col-estrategias { width: 32%; }
    .col-recursos { width: 12%; }
    .col-evaluacion { width: 18%; }

    /* ===== FASES ERCA ===== */
    .fase {
      margin-bottom: 5px;
    }

    .fase-header {
      font-weight: bold;
      font-size: 8px;
      padding: 2px 5px;
      margin-bottom: 2px;
      border-radius: 2px;
      color: white;
    }

    .fase-header.experiencia { background: #2980b9; }
    .fase-header.reflexion { background: #8e44ad; }
    .fase-header.conceptualizacion { background: #27ae60; }
    .fase-header.aplicacion { background: #e67e22; }

    .fase-label {
      font-size: 8px;
      font-weight: bold;
      color: #333;
      margin-bottom: 2px;
    }

    ul {
      padding-left: 12px;
      margin: 2px 0;
      list-style: none;
    }

    li {
      font-size: 8px;
      margin-bottom: 2px;
      line-height: 1.3;
      position: relative;
    }

    /* ===== DUA SQUARES ===== */
    .dua-sq {
      display: inline-block;
      width: 10px;
      height: 10px;
      margin-left: 2px;
      vertical-align: middle;
      border-radius: 1px;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }

    .dua-legend {
      font-size: 7.5px;
      margin-bottom: 4px;
      padding: 3px 6px;
      background: #f9f9f9;
      border: 1px solid #ddd;
      border-radius: 2px;
    }

    .dua-legend-item {
      display: inline-block;
      margin-right: 10px;
    }

    .dua-legend-sq {
      display: inline-block;
      width: 10px;
      height: 10px;
      vertical-align: middle;
      margin-right: 3px;
      border-radius: 1px;
    }

    /* ===== PRINCIPIOS DUA BOX ===== */
    .dua-principios-box {
      border: 1px solid #666;
      margin-bottom: 6px;
    }

    .dua-principio-row {
      padding: 3px 6px;
      border-bottom: 1px solid #ddd;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .dua-principio-row:last-child {
      border-bottom: none;
    }

    .dua-principio-text {
      font-size: 8.5px;
      flex: 1;
    }

    .dua-box-sq {
      width: 14px;
      height: 14px;
      border-radius: 2px;
      display: inline-block;
    }

    /* ===== ESTILOS APRENDIZAJE ===== */
    .estilos-box {
      border: 1px solid #666;
      margin-bottom: 6px;
      padding: 4px 6px;
      font-size: 8px;
    }

    .estilo-item {
      margin-bottom: 2px;
    }

    .estilo-item strong {
      display: inline-block;
      width: 100px;
    }

    /* ===== RECURSOS ===== */
    .recursos-box {
      border: 1px solid #666;
      padding: 4px 6px;
      margin-bottom: 6px;
      font-size: 8.5px;
    }

    /* ===== FIRMAS ===== */
    .firmas {
      display: flex;
      justify-content: space-between;
      margin-top: 20px;
      padding-top: 8px;
    }

    .firma-box {
      text-align: center;
      width: 40%;
    }

    .firma-linea {
      border-top: 1px solid #333;
      padding-top: 3px;
      font-size: 8px;
      font-weight: bold;
      color: #333;
    }

    .firma-cargo {
      font-size: 7.5px;
      color: #666;
      margin-top: 2px;
    }

    /* ===== PIE DE PÁGINA ===== */
    .footer {
      margin-top: 12px;
      border-top: 2px solid #003366;
      padding-top: 4px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .footer-text {
      font-size: 7px;
      color: #666;
      line-height: 1.3;
    }

    .footer-logo {
      text-align: right;
      font-size: 7.5px;
      color: #003366;
      font-weight: bold;
    }

    .app-badge {
      display: inline-block;
      background: #003366;
      color: white;
      font-size: 6.5px;
      padding: 2px 5px;
      border-radius: 2px;
      margin-top: 2px;
    }

    /* ===== OBSERVACIONES ===== */
    .observaciones {
      border: 1px solid #666;
      padding: 4px 6px;
      margin-bottom: 6px;
      min-height: 20px;
      font-size: 8.5px;
    }

    /* ===== DUA SECTION ===== */
    .dua-container {
      border: 1px solid #666;
      margin-bottom: 6px;
    }

    .dua-principio {
      padding: 4px 6px;
      border-bottom: 1px solid #ddd;
    }

    .dua-principio:last-child {
      border-bottom: none;
    }

    .dua-principio-titulo {
      font-weight: bold;
      font-size: 8px;
      text-transform: uppercase;
      margin-bottom: 1px;
      padding: 1px 4px;
      border-radius: 2px;
      color: white;
      display: inline-block;
    }

    .dua-p1 { background: #EC4899; }
    .dua-p2 { background: #1E3A5F; }
    .dua-p3 { background: #22C55E; }

    .dua-subtitulo {
      font-size: 7px;
      color: #666;
      font-style: italic;
      margin-bottom: 2px;
    }

    .dua-texto {
      font-size: 8.5px;
      line-height: 1.35;
      white-space: pre-line;
    }

    .tema-titulo {
      background: #eaf2f8;
      border-left: 4px solid #003366;
      padding: 3px 6px;
      font-weight: bold;
      font-size: 9px;
      color: #003366;
      margin-bottom: 4px;
    }

    .objetivo-clase {
      font-style: italic;
      font-size: 8.5px;
      color: #333;
      margin-bottom: 4px;
      padding: 2px 6px;
      background: #f9f9f9;
      border-left: 3px solid #2980b9;
    }
  </style>
</head>
<body>

  <!-- ENCABEZADO -->
  <div class="header-row">
    <div class="sello">SELLO</div>
    <div class="institucion-nombre">${plan.institucion || (isEFL ? "EDUCATIONAL INSTITUTION" : "UNIDAD EDUCATIVA FISCAL")}</div>
    <div class="anio-lectivo">2026 - 2027</div>
  </div>

  <!-- TÍTULO PRINCIPAL -->
  <div class="titulo-principal">
    ${isEFL
      ? `MICROCURRICULAR LESSON PLAN - ${areaInfo.name.toUpperCase()}`
      : `PLANIFICACIÓN MICROCURRICULAR DE CLASE - ${areaInfo.name.toUpperCase()}`}
  </div>

  <!-- SECCIÓN 1: DATOS INFORMATIVOS -->
  <div class="seccion-titulo">${isEFL ? "1. General Information" : "1. DATOS INFORMATIVOS"}</div>
  <table>
    <tr>
      <td class="label" style="width:14%;">${isEFL ? "Grade/Level:" : "Grado/Curso:"}</td>
      <td class="value" style="width:14%;">${plan.grado || "___"}</td>
      <td class="label" style="width:16%;">${isEFL ? "Pedagogical Period:" : "Período Pedagógico:"}</td>
      <td class="value" style="width:20%;">${plan.periodoPedagogico || areaInfo.name}</td>
      <td class="label" style="width:12%;">${isEFL ? "Quarter:" : "Trimestre:"}</td>
      <td class="value" style="width:14%;">${plan.trimestre || "Primero"}</td>
    </tr>
    <tr>
      <td class="label">${isEFL ? "Level:" : "Nivel:"}</td>
      <td class="value">${plan.nivel || (plan.destreza.subnivel <= 4 ? "Educación General Básica" : "Bachillerato General Unificado")}</td>
      <td class="label">${isEFL ? "Start Date:" : "Fecha Inicio:"}</td>
      <td class="value">${plan.fechaInicio || "___/___/______"}</td>
      <td class="label" colspan="2"></td>
    </tr>
    <tr>
      <td class="label">${isEFL ? "Sublevel:" : "Subnivel:"}</td>
      <td class="value">${subnivelName}</td>
      <td class="label">${isEFL ? "Teacher:" : "Nombre Docente:"}</td>
      <td class="value">${plan.docente || "___"}</td>
      <td class="label">${isEFL ? "End Date:" : "Fecha Fin:"}</td>
      <td class="value">${plan.fechaFin || "___/___/______"}</td>
    </tr>
    <tr>
      <td class="label">${isEFL ? "Section:" : "Paralelo:"}</td>
      <td class="value">${plan.paralelo || '"A"'}</td>
      <td class="label" colspan="4"></td>
    </tr>
  </table>

  <!-- SECCIÓN 2: PRINCIPIOS DUA -->
  <div class="seccion-titulo">${isEFL ? "2. UDL PRINCIPLES" : "2. PRINCIPIOS DUA"}</div>
  <table>
    <tr>
      <td colspan="2" style="width:55%;">
        <div style="padding:2px 0;">
          <span style="font-size:8px;">I. ${isEFL ? "Provide multiple means of representation: What?" : "Proporcionar múltiples formas de representación: ¿qué?"}</span>
          <span class="dua-box-sq" style="background:#EC4899;margin-left:6px;"></span>
        </div>
        <div style="padding:2px 0;">
          <span style="font-size:8px;">II. ${isEFL ? "Provide multiple means of action and expression: How?" : "Proporcionar múltiples formas de acción y expresión: ¿Cómo?"}</span>
          <span class="dua-box-sq" style="background:#1E3A5F;margin-left:6px;"></span>
        </div>
        <div style="padding:2px 0;">
          <span style="font-size:8px;">III. ${isEFL ? "Provide multiple means of engagement or participation: Why?" : "Proporcionar múltiples formas de implicación o participación: ¿Por qué?"}</span>
          <span class="dua-box-sq" style="background:#22C55E;margin-left:6px;"></span>
        </div>
      </td>
      <td colspan="2" style="width:45%;">
        <div style="font-size:8px;font-weight:bold;margin-bottom:3px;">
          ${isEFL ? "3. LEARNING STYLES:" : "3. ESTILOS DE APRENDIZAJE:"} 
          <span style="font-weight:normal;font-style:italic;">${isEFL ? "Percentage distribution in this grade/level." : "Distribución porcentual en este grado/curso."}</span>
        </div>
        <div style="font-size:8px;padding:1px 0;">• <strong>VISUAL</strong>${plan.estilosAprendizajePorcentaje ? ` (${plan.estilosAprendizajePorcentaje.visual}%)` : ""}: ${isEFL ? "diagrams, graphics, colors, texts, outlines, etc." : "diagramas, gráficas, colores, textos, esquemas, etc."}</div>
        <div style="font-size:8px;padding:1px 0;">• <strong>AUDITIVO</strong>${plan.estilosAprendizajePorcentaje ? ` (${plan.estilosAprendizajePorcentaje.auditivo}%)` : ""}: ${isEFL ? "debates, discussions, seminars, music, narrations, etc." : "debates, discusiones, seminarios, música, narraciones, etc."}</div>
        <div style="font-size:8px;padding:1px 0;">• <strong>LECTOR – ESCRITOR</strong>${plan.estilosAprendizajePorcentaje ? ` (${plan.estilosAprendizajePorcentaje.lectorEscritor}%)` : ""}: ${isEFL ? "books, texts, readings, note-taking, essays, summaries, etc." : "libros, textos, lecturas, toma de notas, ensayos, resumen, etc."}</div>
        <div style="font-size:8px;padding:1px 0;">• <strong>KINESTÉSICO</strong>${plan.estilosAprendizajePorcentaje ? ` (${plan.estilosAprendizajePorcentaje.kinestesico}%)` : ""}: ${isEFL ? "demonstrations, physical activities, role plays." : "demostraciones, actividades físicas, juegos de roles."}</div>
      </td>
    </tr>
  </table>

  <!-- SECCIÓN 4: HABILIDADES SOCIOEMOCIONALES -->
  <div class="seccion-titulo">${isEFL ? "4. ASSOCIATED SOCIOEMOTIONAL SKILLS" : "4. HABILIDADES SOCIOEMOCIONALES ASOCIADAS"}</div>
  <div class="recursos-box">
    ${habHTML}
  </div>

  <!-- SECCIÓN 5: OBJETIVOS -->
  <div class="seccion-titulo">${isEFL ? "5. OBJECTIVES" : "5. OBJETIVOS"}</div>
  <div class="recursos-box">
    ${plan.objetivoAprendizaje || (objetivosHTML ? `<ul style="margin:0;padding-left:16px;">${objetivosHTML}</ul>` : (isEFL ? "Not specified" : "No especificado"))}
  </div>

  <!-- SECCIÓN 6: CRITERIOS DE EVALUACIÓN -->
  <div class="seccion-titulo">${isEFL ? "6. ASSESSMENT CRITERIA" : "6. CRITERIOS DE EVALUACIÓN"}</div>
  <div class="recursos-box">
    ${criteriosHTML ? `<ul style="margin:0;padding-left:16px;">${criteriosHTML}</ul>` : (isEFL ? "Not specified" : "No especificados")}
  </div>

  <!-- TABLA PRINCIPAL -->
  ${plan.temaSeleccionado ? `
    <div class="tema-titulo">${isEFL ? "Topic" : "Tema"}: ${plan.temaSeleccionado.titulo}</div>
  ` : ""}

  <table class="tabla-principal">
    <thead>
      <tr>
        <th class="col-destreza">${isEFL ? "Performance Criteria Skills" : "DESTREZAS CON CRITERIOS DE DESEMPEÑO"}</th>
        <th class="col-indicadores">${isEFL ? "Assessment Indicators" : "INDICADORES DE EVALUACIÓN"}</th>
        <th class="col-estrategias">${isEFL ? "Active Methodological Strategies for Teaching and Learning and UDL-based Diversified Strategies" : "ESTRATEGIAS METODOLÓGICAS ACTIVAS PARA LA ENSEÑANZA Y APRENDIZAJE Y ESTRATEGIAS METODOLÓGICAS DIVERSIFICADAS CON BASE AL DUA"}</th>
        <th class="col-recursos">${isEFL ? "Resources" : "RECURSOS"}</th>
        <th class="col-evaluacion">${isEFL ? "Assessment Activities" : "ACTIVIDADES EVALUATIVAS"}</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>
          <strong>${plan.destreza.codigo}</strong>
          ${iconosDestrezaHTML(plan.destreza.codigo)}
          ${competenciasBadgesHTML ? `<div style="margin-top:3px;">${competenciasBadgesHTML}</div>` : ""}
          <br/>
          ${plan.descripcionEfectiva ?? plan.destreza.descripcion}
        </td>
        <td>
          ${habHTML !== (isEFL ? "Not specified" : "No especificadas") ? `
            <div style="margin-bottom:4px;">
              ${(() => {
                const ids = plan.habilidadesSocioemocionales || [];
                return ids.map(id => {
                  const hab = HABILIDADES_SOCIOEMOCIONALES.find(h => h.id === id);
                  if (!hab) return "";
                  return `<div style="margin-bottom:3px;"><strong style="font-size:8px;">${isEFL ? hab.nameEN : hab.nombre}:</strong> <span style="font-size:8px;">${getHabilidadDescripcion(hab.id, isEFL)}</span></div>`;
                }).join("");
              })()}
            </div>
          ` : ""}
          ${indicadoresHTML ? `<ul style="margin-top:4px;">${indicadoresHTML}</ul>` : (isEFL ? "Not specified" : "No especificados")}
        </td>
        <td>
          <!-- DUA Legend -->
          <div class="dua-legend">
            <span class="dua-legend-item"><span class="dua-legend-sq" style="background:#EC4899;"></span>${isEFL ? "Representation" : "Representación"}</span>
            <span class="dua-legend-item"><span class="dua-legend-sq" style="background:#1E3A5F;"></span>${isEFL ? "Action & Expression" : "Acción y Expresión"}</span>
            <span class="dua-legend-item"><span class="dua-legend-sq" style="background:#22C55E;"></span>${isEFL ? "Engagement" : "Implicación"}</span>
          </div>
          ${actividadesHTML}
        </td>
        <td>
          ${recursosTexto}
        </td>
        <td>
          <strong style="font-size:7.5px;">${isEFL ? "Assessment indicators:" : "Indicadores de evaluación:"}</strong><br/>
          ${evaluacionTexto}
          <br/><br/>
          <strong style="font-size:7.5px;">${isEFL ? "Technique:" : "Técnica:"}</strong><br/>
          ${plan.tecnicasInstrumentos || (isEFL ? "Direct observation, participation analysis." : "Observación de participación, análisis de casos y reflexión personal.")}
          <br/><br/>
          <strong style="font-size:7.5px;">${isEFL ? "Instrument:" : "Instrumento:"}</strong><br/>
          ${(() => {
            if (plan.tecnicasEvaluacionSeleccionadas && plan.tecnicasEvaluacionSeleccionadas.length > 0) {
              return plan.tecnicasEvaluacionSeleccionadas.map((id: string) => {
                const tec = TECNICAS_EVALUACION.find(t => t.id === id);
                return tec ? (isEFL ? tec.nameEN : tec.nombre) : '';
              }).filter(Boolean).join(", ");
            }
            return isEFL ? "Checklist, assessment rubric" : "Lista de cotejo, rúbrica de evaluación";
          })()}
        </td>
      </tr>
    </tbody>
  </table>

  <!-- SECCIÓN: DUA DETALLADO -->
  <div class="seccion-titulo">${isEFL ? "UNIVERSAL DESIGN FOR LEARNING (UDL)" : "DISEÑO UNIVERSAL PARA EL APRENDIZAJE (DUA)"}</div>
  <div class="dua-container">
    <div class="dua-principio">
      <span class="dua-principio-titulo dua-p1">${isEFL ? "Principle 1: Multiple Means of Representation" : "Principio 1: Múltiples formas de Representación"}</span>
      <div class="dua-subtitulo">${isEFL ? "The WHAT of learning" : "El QUÉ del aprendizaje"}</div>
      <div class="dua-texto">${plan.dua?.representacion || (isEFL ? "Present information through visual, auditory, and hands-on resources." : "Presentar la información mediante recursos visuales, auditivos y manipulativos.")}</div>
    </div>
    <div class="dua-principio">
      <span class="dua-principio-titulo dua-p2">${isEFL ? "Principle 2: Multiple Means of Action and Expression" : "Principio 2: Múltiples formas de Acción y Expresión"}</span>
      <div class="dua-subtitulo">${isEFL ? "The HOW of learning" : "El CÓMO del aprendizaje"}</div>
      <div class="dua-texto">${plan.dua?.accionExpresion || (isEFL ? "Allow students to demonstrate learning through oral, written, graphic, or practical means." : "Permitir que los estudiantes demuestren lo aprendido de forma oral, escrita, gráfica o práctica.")}</div>
    </div>
    <div class="dua-principio">
      <span class="dua-principio-titulo dua-p3">${isEFL ? "Principle 3: Multiple Means of Engagement" : "Principio 3: Múltiples formas de Implicación"}</span>
      <div class="dua-subtitulo">${isEFL ? "The WHY of learning" : "El POR QUÉ del aprendizaje"}</div>
      <div class="dua-texto">${plan.dua?.implicacion || (isEFL ? "Motivate students through meaningful activities and connection to their context." : "Motivar a los estudiantes mediante actividades significativas y conexión con su contexto.")}</div>
    </div>
  </div>

  ${metodologiasHTML ? `
  <!-- METODOLOGÍAS ACTIVAS -->
  <div class="seccion-titulo">${isEFL ? "ACTIVE METHODOLOGIES" : "METODOLOGÍAS ACTIVAS"}</div>
  <div class="recursos-box">${metodologiasHTML}</div>
  ` : ""}

  <!-- OBSERVACIONES -->
  <div class="seccion-titulo">${isEFL ? "OBSERVATIONS" : "OBSERVACIONES"}</div>
  <div class="observaciones">
    ${plan.observaciones || (isEFL ? "No additional observations." : "Sin observaciones adicionales.")}
  </div>

  ${generarHTMLAdaptacionesCurriculares(plan.adaptacionesCurriculares ?? [])}

  <!-- FIRMAS -->
  <div class="firmas">
    <div class="firma-box">
      <div class="firma-linea">${plan.docente || "________________________"}</div>
      <div class="firma-cargo">${isEFL ? "Teacher" : "Docente"}</div>
    </div>
    <div class="firma-box">
      <div class="firma-linea">________________________</div>
      <div class="firma-cargo">${isEFL ? "Area Director" : "Director/a de Área"}</div>
    </div>
  </div>

  <!-- PIE DE PÁGINA -->
  <div class="footer">
    <div class="footer-text">
      ${isEFL ? "Format based on the guidelines of the Ministry of Education of Ecuador 2026-2027.<br/>National Curriculum - General Basic Education and Unified General Baccalaureate." : "Formato basado en los lineamientos del Ministerio de Educación del Ecuador 2026-2027.<br/>Currículo Nacional - Educación General Básica y Bachillerato General Unificado."}
    </div>
    <div class="footer-logo">
      PlanificaDoc Ecuador
      <div class="app-badge">Generado con PlanificaDoc</div>
    </div>
  </div>

</body>
</html>`;
}

// ============================================================
// PLANIFICACIÓN SEMANAL — HTML GENERATOR
// ============================================================

/** Escapa caracteres HTML para evitar XSS y errores de parseo */
function esc(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/**
 * Genera el bloque HTML de Adaptaciones Curriculares para appender
 * al final de la Planificación Semanal.
 * Devuelve string vacío si no hay adaptaciones activas (documento idéntico al original).
 */
export function generarHTMLAdaptacionesCurriculares(adaptaciones: AdaptacionCurricular[]): string {
  const activas = adaptaciones.filter(a => a.incluirEnExportacion !== false);
  if (activas.length === 0) return "";

  const filasBloqueHTML = activas.map(adap => {
    const tipoNombre = TIPOS_NEE_INFO[adap.tipoNecesidad as TipoNEE]?.nombre ?? adap.tipoNecesidad;
    const gradoInfo  = GRADO_ADAPTACION_INFO[adap.gradoAdaptacion as GradoAdaptacion];
    const codigoLabel = adap.nombreEstudiante
      ? `${esc(adap.nombreEstudiante)} (${esc(adap.codigoEstudiante)})`
      : `Código: ${esc(adap.codigoEstudiante)}`;

    // ── Celda derecha: contenido según grado ──
    let derechaHTML = `<div style="font-size:9px;margin-bottom:4px;">
      <strong style="color:#003366;">${esc(adap.codigoDestreza)}</strong>
      ${adap.descripcionDestreza ? ` &mdash; <em style="color:#444;">${esc(adap.descripcionDestreza)}</em>` : ""}
    </div>`;

    if (adap.gradoAdaptacion >= 2) {
      if (adap.destrezaAdaptada) {
        derechaHTML += `<div style="font-size:9px;background:#EDE9FE;padding:2px 5px;margin-bottom:3px;border-left:3px solid #7B2D8B;">
          <strong style="color:#4A1942;">Destreza adaptada:</strong> ${esc(adap.destrezaAdaptada)}
        </div>`;
      }
      if (adap.criterioAdaptado) {
        derechaHTML += `<div style="font-size:9px;margin-bottom:3px;">
          <strong style="color:#4A1942;">Criterio adaptado:</strong> ${esc(adap.criterioAdaptado)}
        </div>`;
      }
      if (adap.indicadoresAdaptados?.length) {
        derechaHTML += `<div style="font-size:9px;margin-bottom:2px;"><strong style="color:#4A1942;">Indicadores:</strong></div>
          <ul style="margin:0 0 4px 12px;padding:0;">
          ${adap.indicadoresAdaptados.map(i => `<li style="font-size:9px;">${esc(i)}</li>`).join("")}
          </ul>`;
      }
    }

    if (adap.adaptacionesPorDia?.length) {
      // ── ADAPTACIONES POR DÍA — formato ERCA 3 columnas (igual al Word semanal) ──
      derechaHTML += `<div style="font-size:9px;font-weight:bold;color:#000;margin:4px 0 2px;">ADAPTACIONES POR DÍA</div>`;
      const ERCA_PDF_CFG = [
        { key: "experiencia",       label: "EXPERIENCIA",       dark: "2980B9", light: "EBF5FB" },
        { key: "reflexion",         label: "REFLEXIÓN",         dark: "8E44AD", light: "F5EEF8" },
        { key: "conceptualizacion", label: "CONCEPTUALIZACIÓN", dark: "27AE60", light: "EAFAF1" },
        { key: "aplicacion",        label: "APLICACIÓN",        dark: "E67E22", light: "FEF9E7" },
      ] as const;

      adap.adaptacionesPorDia.forEach((dp, di) => {
        // Columna izquierda: objetivo(s) + fases ERCA + leyenda DUA
        let left = "";
        if (dp.objetivo) {
          left += `<div style="font-size:9px;margin-bottom:2px;"><strong>Objetivo:</strong> <em style="color:#444;">${esc(dp.objetivo)}</em></div>`;
        }
        if ((dp as any).objetivoAdaptado) {
          left += `<div style="font-size:9px;margin-bottom:3px;"><strong>Obj. adaptado:</strong> <strong>${esc((dp as any).objetivoAdaptado)}</strong></div>`;
        }
        for (const { key, label, dark, light } of ERCA_PDF_CFG) {
          const val = (dp.adaptacionERCA as any)?.[key];
          if (!val) continue;
          left += `<div style="background:${dark};color:white;font-size:9px;font-weight:bold;padding:2px 5px;margin-top:3px;">${label}</div>
            <div style="background:${light};font-size:9px;padding:2px 5px;margin-bottom:2px;color:#111;">${esc(val)}</div>`;
        }
        left += `<div style="font-size:9px;margin-top:3px;color:#666;">
          <span style="color:#EC4899;">■</span> <span>Representación</span>&nbsp;&nbsp;
          <span style="color:#1E3A5F;">■</span> <span>Acción/Expresión</span>&nbsp;&nbsp;
          <span style="color:#22C55E;">■</span> <span>Implicación</span>
        </div>`;

        // Columna central: recursos adaptados
        const middle = dp.recursosAdaptados?.length
          ? dp.recursosAdaptados.map(r => `<div style="font-size:9px;margin-bottom:2px;">&bull; ${esc(r)}</div>`).join("")
          : `<div style="font-size:9px;color:#888;">—</div>`;

        // Columna derecha: evaluación adaptada
        const right = `<div style="font-size:9px;color:#111;">${esc(dp.evaluacionAdaptada || "—")}</div>`;

        derechaHTML += `
          <table style="width:100%;border-collapse:collapse;margin-bottom:6px;">
            <tr>
              <td colspan="3" style="font-size:9px;font-weight:bold;padding:3px 6px;border:1px solid #888;">${esc(dp.dia.toUpperCase())}</td>
            </tr>
            <tr>
              <td colspan="3" style="background:#1A3A5C;color:white;font-size:9px;font-weight:bold;padding:2px 6px;">ESTRATEGIAS METODOLÓGICAS ACTIVAS PARA LA ENSEÑANZA Y APRENDIZAJE</td>
            </tr>
            <tr>
              <td colspan="3" style="background:#1A3A5C;color:#CCCCCC;font-size:9px;font-style:italic;padding:1px 6px;">Estrategias metodológicas diversificadas con base al DUA</td>
            </tr>
            <tr>
              <td style="background:#374151;color:white;font-size:9px;font-weight:bold;text-align:center;padding:2px 4px;border:1px solid #888;">ESTRATEGIAS ERCA ADAPTADAS</td>
              <td style="background:#374151;color:white;font-size:9px;font-weight:bold;text-align:center;padding:2px 4px;border:1px solid #888;">RECURSOS ADAPTADOS</td>
              <td style="background:#374151;color:white;font-size:9px;font-weight:bold;text-align:center;padding:2px 4px;border:1px solid #888;">EVALUACIÓN ADAPTADA</td>
            </tr>
            <tr>
              <td style="vertical-align:top;padding:4px 5px;border:1px solid #888;width:46%;">${left}</td>
              <td style="vertical-align:top;padding:4px 5px;border:1px solid #888;width:27%;">${middle}</td>
              <td style="vertical-align:top;padding:4px 5px;border:1px solid #888;width:27%;">${right}</td>
            </tr>
          </table>`;
      });
    } else {
      const renderBloque = (b: { categoria: string; descripcion: string; estrategias: string[] }) =>
        `<div style="font-size:9px;margin-bottom:3px;">
          <strong>${esc(b.categoria)}:</strong> ${esc(b.descripcion)}
          <ul style="margin:1px 0 0 10px;padding:0;">
            ${b.estrategias.map(e => `<li style="font-size:9px;margin-bottom:1px;">${esc(e)}</li>`).join("")}
          </ul>
        </div>`;

      if (adap.adaptacionesAcceso?.length) {
        derechaHTML += `<div style="font-size:9px;font-weight:bold;color:#003366;margin:4px 0 2px;">ADAPTACIONES DE ACCESO</div>`;
        derechaHTML += adap.adaptacionesAcceso.map(renderBloque).join("");
      }
      if (adap.gradoAdaptacion >= 2 && adap.adaptacionesProceso?.length) {
        derechaHTML += `<div style="font-size:9px;font-weight:bold;color:#8E44AD;margin:4px 0 2px;">ADAPTACIONES DE PROCESO</div>`;
        derechaHTML += adap.adaptacionesProceso.map(renderBloque).join("");
      }
      if (adap.gradoAdaptacion >= 3 && adap.adaptacionesResultado?.length) {
        derechaHTML += `<div style="font-size:9px;font-weight:bold;color:#E67E22;margin:4px 0 2px;">ADAPTACIONES DE RESULTADO</div>`;
        derechaHTML += adap.adaptacionesResultado.map(renderBloque).join("");
      }
      if (adap.metodologiasSugeridas?.length) {
        derechaHTML += `<div style="font-size:9px;font-weight:bold;color:#003366;margin:4px 0 2px;">METODOLOGÍAS SUGERIDAS</div>
          <ul style="margin:0 0 4px 12px;padding:0;">
            ${adap.metodologiasSugeridas.map(m => `<li style="font-size:9px;">${esc(m)}</li>`).join("")}
          </ul>`;
      }
      if (adap.recursosEspecificos?.length) {
        derechaHTML += `<div style="font-size:9px;margin-top:2px;"><strong>Recursos:</strong> ${adap.recursosEspecificos.map(esc).join(" &middot; ")}</div>`;
      }
    }
    if (adap.seguimiento) {
      derechaHTML += `<div style="font-size:9px;margin-top:3px;"><strong>Seguimiento:</strong> ${esc(adap.seguimiento)}</div>`;
    }
    if (adap.observaciones) {
      derechaHTML += `<div style="font-size:9px;margin-top:2px;color:#555;font-style:italic;">${esc(adap.observaciones)}</div>`;
    }

    return `
      <tr style="page-break-inside:avoid;">
        <th colspan="6" style="background:#7B2D8B;color:white;font-size:9px;text-align:left;padding:3px 6px;font-weight:bold;">
          ${codigoLabel} &nbsp;&middot;&nbsp; ${esc(tipoNombre)} &nbsp;&middot;&nbsp; ${esc(gradoInfo.nombre)}
        </th>
      </tr>
      <tr style="page-break-inside:avoid;">
        <td colspan="2" style="width:25%;background:#F9F5FF;vertical-align:top;padding:5px 6px;border:1px solid #888;">
          <div style="font-size:9px;font-weight:bold;color:#4A1942;margin-bottom:4px;">IDENTIFICACIÓN</div>
          <div style="font-size:9px;margin-bottom:2px;"><strong>Código:</strong> ${esc(adap.codigoEstudiante)}</div>
          <div style="font-size:9px;margin-bottom:2px;"><strong>NEE:</strong> ${esc(tipoNombre)}</div>
          <div style="font-size:9px;margin-bottom:2px;"><strong>Grado:</strong> ${esc(gradoInfo.nombre)}</div>
          ${adap.descripcionNecesidad
            ? `<div style="font-size:9px;color:#555;font-style:italic;margin-top:4px;">${esc(adap.descripcionNecesidad)}</div>`
            : ""}
        </td>
        <td colspan="4" style="vertical-align:top;padding:5px 6px;border:1px solid #888;">
          ${derechaHTML}
        </td>
      </tr>`;
  }).join("");

  return `
    <div style="page-break-before:always;">
      <div class="seccion-titulo" style="background:#4A1942;color:white;border-color:#4A1942;">
        ADAPTACIONES CURRICULARES &mdash; ${activas.length} estudiante${activas.length !== 1 ? "s" : ""}
      </div>
      <table style="width:100%;border-collapse:collapse;margin-bottom:6px;">
        <thead>
          <tr>
            <th colspan="2" style="background:#4A1942;color:white;font-size:9px;padding:3px 6px;text-align:center;border:1px solid #4A1942;">ESTUDIANTE</th>
            <th colspan="4" style="background:#4A1942;color:white;font-size:9px;padding:3px 6px;text-align:center;border:1px solid #4A1942;">ADAPTACIONES PEDAGÓGICAS</th>
          </tr>
        </thead>
        <tbody>
          ${filasBloqueHTML}
        </tbody>
      </table>
    </div>`;
}

/**
 * Genera el HTML con el formato oficial del Ministerio de Educación de Ecuador
 * para una Planificación Semanal (5 días).
 * Tabla principal: DÍA | DCD | INDICADORES | ESTRATEGIAS+DUA | RECURSOS | ACTIVIDADES EVALUATIVAS
 */
export function generarHTMLSemanal(
  semana: import("../data/types").PlanificacionSemanal,
  adaptaciones?: AdaptacionCurricular[],
): string {
  const DIAS = ["lunes", "martes", "miercoles", "jueves", "viernes"] as const;
  type DiaSemanaKey = typeof DIAS[number];
  const DIA_LABEL: Record<DiaSemanaKey, string> = {
    lunes: "LUNES", martes: "MARTES", miercoles: "MIÉRCOLES", jueves: "JUEVES", viernes: "VIERNES",
  };

  // Helper: limpia texto de actividades quitando marcadores DUA residuales
  const cleanAct = (act: string) => act
    .replace(/\s*\(\s*I\s*:\s*(true|false)\s*,\s*R\s*:\s*(true|false)\s*,\s*A\s*:\s*(true|false)\s*\)\s*/gi, "")
    .replace(/\s*\[\s*I\s*:\s*(true|false)\s*,\s*R\s*:\s*(true|false)\s*,\s*A\s*:\s*(true|false)\s*\]\s*/gi, "")
    .replace(/\s*DUA\s*:\s*\{[^}]*\}\s*/gi, "")
    .replace(/\s*\(DUA[^)]*\)\s*/gi, "")
    .trim();

  type FaseKey = { duracion?: string; actividades?: string[]; duaActividades?: Array<{ representacion: boolean; accionExpresion: boolean; implicacion: boolean }> };
  type EstructuraMap = Record<string, FaseKey>;

  // Construir filas de la tabla principal
  // Una fila por cada hora de clase de cada día activo
  const diasActivos = DIAS.filter((d) => semana.dias[d]?.activo);

  const filasHTML = diasActivos.map((dia) => {
    const diaConfig = semana.dias[dia];
    const horasConPlan = diaConfig.horas.filter(h => h.temaSeleccionado);
    if (horasConPlan.length === 0) return "";

    return horasConPlan.map((hora, horaIdx) => {
      const plan = hora.temaSeleccionado!;
      const est = plan.estructura as EstructuraMap;

      // ── Columna 2: DCD ──
      const dcdHTML = `
        <strong style="color:#003366;font-size:9px;">${hora.codigoDestreza}</strong><br/>
        <span style="font-size:9px;">${hora.descripcionEfectiva ?? hora.destreza?.descripcion ?? ""}</span>
        ${iconosDestrezaHTML(hora.codigoDestreza)}
        ${plan.objetivoClase ? `<div style="margin-top:3px;font-size:9px;color:#555;font-style:italic;border-left:2px solid #003366;padding-left:4px;">${plan.objetivoClase}</div>` : ""}`;

      // ── Columna 3: Indicadores de evaluación ──
      const indicadores = hora.destreza?.indicadoresEvaluacion || [];
      const indHTML = indicadores.length
        ? `<ul style="padding-left:10px;margin:0;">${indicadores.map(i => `<li style="font-size:9px;margin-bottom:2px;">${i}</li>`).join("")}</ul>`
        : `<span style="font-size:9px;color:#888;">—</span>`;

      // ── Columna 4: Estrategias ERCA + DUA ──
      const fases = [
        { key: "experiencia", label: "EXPERIENCIA", color: "#2980b9" },
        { key: "reflexion", label: "REFLEXIÓN", color: "#8e44ad" },
        { key: "conceptualizacion", label: "CONCEPTUALIZACIÓN", color: "#27ae60" },
        { key: "aplicacion", label: "APLICACIÓN", color: "#e67e22" },
      ];

      const estrategiasHTML = `
        <div style="font-size:9px;margin-bottom:3px;">
          <span style="display:inline-block;width:8px;height:8px;background:#EC4899;border-radius:1px;vertical-align:middle;"></span> Representación&nbsp;&nbsp;
          <span style="display:inline-block;width:8px;height:8px;background:#1E3A5F;border-radius:1px;vertical-align:middle;"></span> Acción/Expresión&nbsp;&nbsp;
          <span style="display:inline-block;width:8px;height:8px;background:#22C55E;border-radius:1px;vertical-align:middle;"></span> Implicación
        </div>
        ${fases.map(({ key, label, color }) => {
          const fase = est[key];
          if (!fase?.actividades?.length) return "";
          // Actividades ERCA a 12px (~9pt en papel, A4 impreso con 1px≈0.75pt).
          // Coherente con el Word semanal (10pt) sin duplicar páginas. Rango aceptable: 11-13px.
          const actsHTML = (fase.actividades).map((act, idx) => {
            const dua = fase.duaActividades?.[idx] ?? { representacion: false, accionExpresion: false, implicacion: false };
            return `<li style="font-size:12px;margin-bottom:2px;line-height:1.3;">${idx + 1}. ${cleanAct(act)}
              <span style="display:inline-block;width:7px;height:7px;background:${dua.representacion ? "#EC4899" : "#EC489938"};border-radius:1px;vertical-align:middle;margin-left:2px;-webkit-print-color-adjust:exact;print-color-adjust:exact;"></span>
              <span style="display:inline-block;width:7px;height:7px;background:${dua.accionExpresion ? "#1E3A5F" : "#1E3A5F38"};border-radius:1px;vertical-align:middle;margin-left:1px;-webkit-print-color-adjust:exact;print-color-adjust:exact;"></span>
              <span style="display:inline-block;width:7px;height:7px;background:${dua.implicacion ? "#22C55E" : "#22C55E38"};border-radius:1px;vertical-align:middle;margin-left:1px;-webkit-print-color-adjust:exact;print-color-adjust:exact;"></span>
            </li>`;
          }).join("");
          return `<div style="margin-bottom:4px;">
            <div style="background:${color};color:white;font-size:9px;font-weight:bold;padding:1px 4px;border-radius:2px;margin-bottom:2px;">${label}${fase.duracion ? ` (${fase.duracion})` : ""}</div>
            <ul style="list-style:none;padding:0;margin:0;">${actsHTML}</ul>
          </div>`;
        }).join("")}`;

      // ── Columna 5: Recursos ──
      const recursosHTML = plan.recursos?.length
        ? plan.recursos.map(r => `<div style="font-size:9px;margin-bottom:2px;">• ${r}</div>`).join("")
        : `<span style="font-size:9px;color:#888;">—</span>`;

      // ── Columna 6: Actividades Evaluativas ──
      const evalHTML = `
        ${plan.evaluacionFormativa ? `<div style="font-size:9px;margin-bottom:4px;">${plan.evaluacionFormativa}</div>` : ""}
        ${hora.tecnicasEvaluacion?.length ? `<div style="font-size:9px;color:#555;margin-top:2px;"><strong>Técnicas:</strong> ${hora.tecnicasEvaluacion.join(", ")}</div>` : ""}
        ${hora.destreza?.criteriosEvaluacion?.length ? `<div style="font-size:9px;color:#555;margin-top:3px;"><strong>Criterios:</strong><ul style="padding-left:10px;margin:2px 0;">${hora.destreza.criteriosEvaluacion.map(c => `<li style="font-size:9px;">${c}</li>`).join("")}</ul></div>` : ""}`;

      // rowspan en la celda de día solo para la primera hora
      const diaCell = horaIdx === 0
        ? `<td rowspan="${horasConPlan.length}" style="background:#D4A5C7;font-weight:bold;font-size:9px;text-align:center;vertical-align:middle;writing-mode:vertical-rl;text-orientation:mixed;transform:rotate(180deg);width:28px;padding:4px 2px;letter-spacing:1px;">${DIA_LABEL[dia]}</td>`
        : "";

      return `<tr>
        ${diaCell}
        <td style="width:16%;vertical-align:top;padding:5px;">${dcdHTML}</td>
        <td style="width:14%;vertical-align:top;padding:5px;">${indHTML}</td>
        <td style="width:36%;vertical-align:top;padding:5px;">${estrategiasHTML}</td>
        <td style="width:12%;vertical-align:top;padding:5px;">${recursosHTML}</td>
        <td style="width:16%;vertical-align:top;padding:5px;">${evalHTML}</td>
      </tr>`;
    }).join("");
  }).join("");

  return `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Planificaci&oacute;n Semanal &mdash; ${semana.semanaInicio}</title>
  <style>
    @page { size: A4 landscape; margin: 10mm 8mm; }
    * { margin:0; padding:0; box-sizing:border-box; -webkit-print-color-adjust:exact!important; print-color-adjust:exact!important; }
    body { font-family:'Helvetica Neue',Helvetica,Arial,sans-serif; font-size:9px; color:#1a1a1a; line-height:1.35; background:#fff; }

    .header-row { display:flex; align-items:center; justify-content:space-between; margin-bottom:5px; }
    .sello { font-size:9px; font-weight:bold; color:#003366; border:1px solid #003366; padding:3px 7px; text-transform:uppercase; }
    .inst-nombre { text-align:center; font-size:9px; font-weight:bold; color:#003366; text-transform:uppercase; }
    .anio { font-size:9px; font-weight:bold; color:#003366; }

    .titulo-doc { background:#D4A5C7; color:#1a1a1a; text-align:center; padding:4px 10px; font-size:9px; font-weight:bold; text-transform:uppercase; letter-spacing:.5px; margin-bottom:5px; border:1px solid #999; }

    table.datos { width:100%; border-collapse:collapse; margin-bottom:5px; }
    table.datos td { border:1px solid #888; padding:2px 5px; font-size:9px; vertical-align:middle; }
    .lbl { background:#F5E6F0; font-weight:bold; color:#1a3c5e; }

    table.principal { width:100%; border-collapse:collapse; margin-bottom:6px; table-layout:fixed; }
    table.principal th { background:#D4A5C7; color:#1a1a1a; font-size:9px; font-weight:bold; text-align:center; padding:4px 3px; border:1px solid #888; text-transform:uppercase; vertical-align:middle; line-height:1.2; }
    table.principal td { border:1px solid #888; vertical-align:top; font-size:9px; }

    .estilos-row { display:flex; gap:16px; margin-bottom:5px; padding:4px 8px; border:1px solid #ccc; border-radius:3px; font-size:9px; background:#fafafa; }
    .estilo-item { font-size:9px; }
    .estilo-item strong { display:inline-block; min-width:110px; }

    .footer { margin-top:10px; border-top:2px solid #003366; padding-top:4px; display:flex; justify-content:space-between; align-items:center; }
    .footer-txt { font-size:9px; color:#777; }
    .footer-logo { font-size:9px; color:#003366; font-weight:bold; text-align:right; }
    .app-badge { display:inline-block; background:#003366; color:white; font-size:9px; padding:1px 4px; border-radius:2px; margin-top:1px; }

    .firmas { display:flex; justify-content:space-between; margin-top:14px; }
    .firma-box { text-align:center; width:42%; }
    .firma-linea { border-top:1px solid #333; padding-top:3px; font-size:9px; font-weight:bold; }
    .firma-cargo { font-size:9px; color:#666; margin-top:2px; }
  </style>
</head>
<body>

  <!-- ENCABEZADO -->
  <div class="header-row">
    <div class="sello">SELLO</div>
    <div class="inst-nombre">${semana.institucion || "UNIDAD EDUCATIVA FISCAL"}</div>
    <div class="anio">2026 &ndash; 2027</div>
  </div>

  <!-- TÍTULO -->
  <div class="titulo-doc">PLANIFICACI&Oacute;N MICROCURRICULAR SEMANAL</div>

  <!-- DATOS INFORMATIVOS -->
  <table class="datos">
    <tr>
      <td class="lbl" style="width:11%;">Docente:</td>
      <td style="width:21%;">${semana.docente || "___"}</td>
      <td class="lbl" style="width:9%;">Grado/Curso:</td>
      <td style="width:13%;">${semana.grado || "___"}${semana.paralelo ? " &mdash; " + semana.paralelo : ""}</td>
      <td class="lbl" style="width:9%;">Trimestre:</td>
      <td style="width:10%;">${semana.trimestre || "___"}</td>
      <td class="lbl" style="width:9%;">Semana:</td>
      <td style="width:18%;">${semana.semanaInicio} &mdash; ${semana.semanaFin}</td>
    </tr>
    <tr>
      <td class="lbl">Instituci&oacute;n:</td>
      <td colspan="3">${semana.institucion || "___"}</td>
      <td class="lbl">Nivel:</td>
      <td>${semana.nivel || "___"}</td>
      <td class="lbl">Per&iacute;odos:</td>
      <td>${semana.periodos || "___"}</td>
    </tr>
    <tr>
      <td class="lbl">N.&ordm; de unidad de planificaci&oacute;n:</td>
      <td style="width:8%;">${(semana as any).numeroUnidad || "___"}</td>
      <td class="lbl" colspan="1">T&iacute;tulo de unidad de planificaci&oacute;n:</td>
      <td colspan="2">${(semana as any).tituloUnidad || "___"}</td>
      <td class="lbl">Objetivos espec&iacute;ficos de la unidad de planificaci&oacute;n:</td>
      <td colspan="2">${(semana as any).objetivosUnidad || "___"}</td>
    </tr>
  </table>

  <!-- TABLA PRINCIPAL -->
  <table class="principal">
    <thead>
      <tr>
        <th style="width:3%;">D&Iacute;A</th>
        <th style="width:16%;">DESTREZAS CON CRITERIOS<br/>DE DESEMPE&Ntilde;O</th>
        <th style="width:14%;">INDICADORES DE<br/>EVALUACI&Oacute;N</th>
        <th style="width:36%;">ESTRATEGIAS METODOL&Oacute;GICAS ACTIVAS PARA LA ENSE&Ntilde;ANZA Y APRENDIZAJE<br/>Y ESTRATEGIAS METODOL&Oacute;GICAS DIVERSIFICADAS CON BASE AL DUA</th>
        <th style="width:12%;">RECURSOS</th>
        <th style="width:16%;">ACTIVIDADES<br/>EVALUATIVAS</th>
      </tr>
    </thead>
    <tbody>
      ${filasHTML || `<tr><td colspan="6" style="text-align:center;padding:20px;color:#888;font-style:italic;">No hay planificaciones generadas.</td></tr>`}
    </tbody>
  </table>

  ${generarHTMLAdaptacionesCurriculares(adaptaciones ?? semana.adaptacionesCurriculares ?? [])}

  <!-- FIRMAS -->
  <div class="firmas">
    <div class="firma-box">
      <div class="firma-linea">${semana.docente || "________________________"}</div>
      <div class="firma-cargo">Docente</div>
    </div>
    <div class="firma-box">
      <div class="firma-linea">________________________</div>
      <div class="firma-cargo">Director/a de &Aacute;rea</div>
    </div>
  </div>

  <!-- PIE DE PÁGINA -->
  <div class="footer">
    <div class="footer-txt">Formato basado en los lineamientos del Ministerio de Educaci&oacute;n del Ecuador 2026-2027.<br/>Curr&iacute;culo Nacional &mdash; EGB y BGU.</div>
    <div class="footer-logo">
      PlanificaDoc Ecuador
      <div class="app-badge">Generado con PlanificaDoc</div>
    </div>
  </div>

</body>
</html>`;
}

/**
 * Descripciones breves de habilidades socioemocionales para la columna de indicadores
 */
function getHabilidadDescripcion(id: string, isEFL: boolean): string {
  const descripciones: Record<string, { es: string; en: string }> = {
    conciencia_social: {
      es: "Comprende las interacciones sociales y culturales y valora la importancia de la equidad y la justicia en las relaciones con los demás.",
      en: "Understands social and cultural interactions and values the importance of equity and justice in relationships.",
    },
    pensamiento_critico: {
      es: "Analiza la validez de la información y genera soluciones creativas a problemas complejos. Reconoce distintas fuentes de información.",
      en: "Analyzes the validity of information and generates creative solutions to complex problems.",
    },
    pensamiento_etico: {
      es: "Analiza cuestiones éticas en la toma de decisiones y actúa de manera responsable y respetuosa en diferentes contextos.",
      en: "Analyzes ethical issues in decision-making and acts responsibly and respectfully in different contexts.",
    },
    manejo_problemas: {
      es: "Identifica problemas cotidianos complejos, propone soluciones y evalúa su efectividad.",
      en: "Identifies complex everyday problems, proposes solutions and evaluates their effectiveness.",
    },
    trabajo_colaborativo: {
      es: "Trabaja de manera efectiva en equipo, demostrando habilidades de comunicación, empatía y colaboración.",
      en: "Works effectively in teams, demonstrating communication, empathy and collaboration skills.",
    },
    comunicacion_asertiva: {
      es: "Se comunica de manera clara, respetuosa y efectiva en diferentes contextos y con diferentes interlocutores.",
      en: "Communicates clearly, respectfully and effectively in different contexts and with different interlocutors.",
    },
    autoconocimiento: {
      es: "Reconoce sus fortalezas, debilidades, emociones y valores, y los utiliza para su desarrollo personal.",
      en: "Recognizes strengths, weaknesses, emotions and values, and uses them for personal development.",
    },
    autorregulacion: {
      es: "Gestiona sus emociones y comportamientos de manera efectiva para alcanzar metas personales y académicas.",
      en: "Manages emotions and behaviors effectively to achieve personal and academic goals.",
    },
    empatia: {
      es: "Comprende y comparte los sentimientos de los demás, mostrando sensibilidad ante diferentes perspectivas.",
      en: "Understands and shares others' feelings, showing sensitivity to different perspectives.",
    },
    resiliencia: {
      es: "Demuestra resiliencia y perseverancia ante los desafíos, manteniendo una actitud positiva.",
      en: "Demonstrates resilience and perseverance in the face of challenges, maintaining a positive attitude.",
    },
    toma_decisiones: {
      es: "Toma decisiones informadas, responsables y basadas en principios éticos considerando el bienestar propio y de los demás.",
      en: "Makes informed, responsible decisions based on ethical principles considering own and others' well-being.",
    },
    perseverancia: {
      es: "Mantiene el esfuerzo y la dedicación ante las dificultades, buscando alcanzar sus objetivos con constancia.",
      en: "Maintains effort and dedication in the face of difficulties, seeking to achieve goals with consistency.",
    },
  };

  const desc = descripciones[id];
  if (!desc) return "";
  return isEFL ? desc.en : desc.es;
}

// ============================================================
// BACHILLERATO TÉCNICO — PLAN DE UNIDAD DE TRABAJO — HTML GENERATOR
// Módulo intencionalmente independiente de las funciones EGB/BGU de arriba
// (aislamiento del sistema BT). Reutiliza solo esc() (helper genérico de
// escape HTML) y las mismas clases CSS .firmas/.firma-box/.firma-linea que
// el resto de la app, para mantener consistencia visual entre exportaciones.
// ============================================================

export function generarHTMLPlanBT(plan: PlanUnidadTrabajoBT): string {
  const criteriosDe = (procedimientoId: string) =>
    plan.procedimientoCriterioEvaluacion
      .filter((pc) => pc.procedimientoId === procedimientoId)
      .map((pc) => pc.criterioEvaluacionId)
      .join(", ") || "—";

  const filasProcedimientos = plan.unidadTrabajo.procedimientos
    .map(
      (p, i) => `
    <tr>
      <td style="text-align:center;">${i + 1}</td>
      <td><strong>${esc(p.nombre)}</strong></td>
      <td>${esc(p.objetivo)}</td>
      <td>${esc(p.tiempo)}</td>
      <td>${p.fases.map((f) => `<div><strong>${esc(f.nombre)}:</strong> ${esc(f.descripcion)}</div>`).join("")}</td>
      <td>${p.recursos.map((r) => `<div>• ${esc(r)}</div>`).join("")}</td>
      <td>${esc(criteriosDe(p.id))}</td>
      <td>${esc(p.evaluacion.tecnica)}<br/>${esc(p.evaluacion.instrumento)}</td>
    </tr>`
    )
    .join("");

  const contenidosHTML = (["conceptuales", "procedimentales", "actitudinales"] as const)
    .map((k) => {
      const items = plan.unidadTrabajo.contenidos[k];
      if (!items.length) return "";
      return `<div style="margin-top:6px;"><strong>${k[0].toUpperCase()}${k.slice(1)}</strong>${items
        .map((it) => `<div>• ${esc(it)}</div>`)
        .join("")}</div>`;
    })
    .join("");

  const estrategiasHTML = plan.unidadTrabajo.estrategiasMetodologicas
    .map((e) => `<div>• <strong>${esc(e.nombre)}</strong>${e.descripcion ? `: ${esc(e.descripcion)}` : ""}</div>`)
    .join("");

  const adaptacionesHTML = plan.adaptacionesCurriculares?.length
    ? plan.adaptacionesCurriculares
        .map(
          (a) => `
    <table class="tabla-plan" style="margin-bottom:8px;">
      <tr><th>Especificación de la necesidad educativa atendida</th><th>Especificación de la adaptación aplicada</th></tr>
      <tr>
        <td>${esc(a.categoriaNecesidad)}${a.descripcionNecesidad ? " — " + esc(a.descripcionNecesidad) : ""}</td>
        <td>${(a.adaptacionesAcceso || []).map((x) => `<div>• ${esc(x.categoria)}: ${esc(x.descripcion)}</div>`).join("") || "—"}</td>
      </tr>
    </table>`
        )
        .join("")
    : `<p style="color:#666;font-style:italic;">No se registraron adaptaciones curriculares para esta unidad.</p>`;

  const bibliografiaHTML = plan.bibliografiaWebgrafia?.length
    ? plan.bibliografiaWebgrafia.map((r) => `<div>• ${esc(r)}</div>`).join("")
    : `<p style="color:#666;">—</p>`;

  return `<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8" />
<title>Plan de Unidad de Trabajo — ${esc(plan.unidadTrabajo.nombre)}</title>
<style>
  * { box-sizing: border-box; }
  body { font-family: Arial, Helvetica, sans-serif; color: #1a1a1a; margin: 24px; font-size: 11px; }
  h1 { background:#003366; color:#fff; padding:10px 14px; font-size:16px; margin:0 0 4px; }
  h2 { background:#1A3A5C; color:#fff; padding:6px 10px; font-size:12px; margin:16px 0 8px; }
  .subt { color:#555; font-style:italic; margin:0 0 16px; }
  table.tabla-plan { width:100%; border-collapse:collapse; margin-bottom:8px; }
  table.tabla-plan th, table.tabla-plan td { border:1px solid #999; padding:6px 8px; text-align:left; vertical-align:top; font-size:10px; }
  table.tabla-plan th { background:#EAF4F6; font-weight:bold; }
  .label-cell { background:#EAF4F6; font-weight:bold; width:28%; }
  .firmas { display:flex; justify-content:space-between; margin-top:24px; gap:16px; }
  .firma-box { text-align:center; width:32%; }
  .firma-linea { border-top:1px solid #333; padding-top:4px; font-size:10px; margin-top:36px; }
  @media print { body { margin: 10mm; } }
</style>
</head>
<body>
  <h1>PLAN DE UNIDAD DE TRABAJO</h1>
  <p class="subt">Bachillerato Técnico</p>

  <h2>1.- DATOS DE REFERENCIA</h2>
  <table class="tabla-plan">
    <tr><td class="label-cell">Institución educativa</td><td>${esc(plan.institucion || "—")}</td></tr>
    <tr><td class="label-cell">Docente</td><td>${esc(plan.docente || "—")}</td></tr>
    <tr><td class="label-cell">Curso / Paralelo</td><td>${esc(plan.curso || "—")} / ${esc(plan.paralelo || "—")}</td></tr>
    <tr><td class="label-cell">Año lectivo</td><td>${esc(plan.anioLectivo || "—")}</td></tr>
    <tr><td class="label-cell">Módulo formativo</td><td>${esc(plan.nombreModuloFormativo || "—")}</td></tr>
    <tr><td class="label-cell">Objetivo del módulo</td><td>${esc(plan.objetivoModuloFormativo || "—")}</td></tr>
    <tr><td class="label-cell">Unidad de Trabajo</td><td>N.° ${plan.unidadTrabajo.numero} — ${esc(plan.unidadTrabajo.nombre || "—")}</td></tr>
    <tr><td class="label-cell">Horas pedagógicas</td><td>${plan.unidadTrabajo.tiempoEstimadoPeriodos || plan.horasPedagogicas || "—"}</td></tr>
  </table>

  <h2>2.- DESARROLLO DE LA UNIDAD DE TRABAJO</h2>
  <table class="tabla-plan">
    <tr>
      <th>N.°</th><th>Nombre</th><th>Objetivo</th><th>Tiempo</th>
      <th>Secuencia de la actividad</th><th>Recursos</th><th>Criterios</th><th>Técnica / Instrumento</th>
    </tr>
    ${filasProcedimientos}
  </table>

  <div style="margin-top:10px;"><strong>Contenidos</strong>${contenidosHTML}</div>
  ${estrategiasHTML ? `<div style="margin-top:10px;"><strong>Estrategias metodológicas</strong>${estrategiasHTML}</div>` : ""}

  <h2>3.- ADAPTACIONES CURRICULARES</h2>
  ${adaptacionesHTML}

  <h2>4.- BIBLIOGRAFÍA/WEBGRAFÍA</h2>
  ${bibliografiaHTML}

  <div class="firmas">
    <div class="firma-box">
      <div class="firma-linea">${esc(plan.elaboradoPor?.nombre || plan.docente || "________________________")}</div>
      <div style="font-size:9px;color:#555;">ELABORADO POR (Docente)</div>
    </div>
    <div class="firma-box">
      <div class="firma-linea">${esc(plan.revisadoPor?.nombre || "________________________")}</div>
      <div style="font-size:9px;color:#555;">REVISADO POR</div>
    </div>
    <div class="firma-box">
      <div class="firma-linea">${esc(plan.aprobadoPor?.nombre || "________________________")}</div>
      <div style="font-size:9px;color:#555;">APROBADO POR</div>
    </div>
  </div>
</body>
</html>`;
}

/**
 * HTML del plan "Conecta, Nivela y Crea" (CNC) para exportación a PDF —
 * las 5 semanas de arranque del año escolar, modalidad general o BT.
 */
/** Indicadores de evaluación reales del catálogo curricular (igual que la tabla de planificación semanal) */
function cncIndicadoresDe(codigo: string): string[] {
  return cncBuscarPorCodigo(codigo)?.indicadoresEvaluacion ?? [];
}

/** Indicadores reales de una lista de destrezas — si una destreza no tiene indicadores en el catálogo, cae al nivel detectado */
function cncIndicadoresParaDestrezas(items: { destrezaCodigo: string; nivelDetectado?: string }[]): string[] {
  const out: string[] = [];
  for (const it of items) {
    const ind = cncIndicadoresDe(it.destrezaCodigo);
    if (ind.length) out.push(...ind);
    else if (it.nivelDetectado) out.push(`Nivel detectado: ${it.nivelDetectado}`);
  }
  return out;
}

const CNC_COLUMNAS_SEMANA = [
  "SEMANA",
  "DESTREZAS CON CRITERIOS DE DESEMPEÑO",
  "INDICADORES DE EVALUACIÓN",
  "ESTRATEGIAS METODOLÓGICAS ACTIVAS PARA LA ENSEÑANZA Y APRENDIZAJE",
  "RECURSOS",
  "ACTIVIDADES EVALUATIVAS",
];

/**
 * Criterios de evaluación reales del módulo técnico seleccionado (catálogo
 * FIP) — equivalente BT de los indicadores del currículo general, para la
 * columna INDICADORES de las Semanas 4-5 (producto acreditable).
 */
function criteriosTecnicosDeModuloCNC(plan: PlanConectaNivelaCrea): string[] {
  if (!plan.figuraProfesionalId || !plan.moduloId) return [];
  const figura = obtenerFiguraPorIdBT(plan.figuraProfesionalId);
  const modulo = figura?.modulos.find((m) => m.codigo === plan.moduloId);
  const out: string[] = [];
  for (const ra of modulo?.resultadosAprendizaje ?? []) {
    for (const ce of ra.criteriosEvaluacion ?? []) {
      if (ce.texto && !out.includes(ce.texto)) out.push(ce.texto);
    }
  }
  return out;
}

/** Recursos de las Semanas 4-5: sugeridos por la IA; respaldo para planes previos al campo. */
function recursosProyectoCNC(plan: PlanConectaNivelaCrea): string[] {
  const sugeridos = plan.aiResult?.recursosProyectoSugeridos?.filter(Boolean) ?? [];
  if (sugeridos.length) return sugeridos;
  if (plan.modalidad === "bt") return plan.semana1BT?.reconocimientoEspacios.filter(Boolean) ?? [];
  return plan.semana4y5.proyecto.areasIntegradas.filter(Boolean);
}

export function generarHTMLPlanCNC(plan: PlanConectaNivelaCrea): string {
  const esBT = plan.modalidad === "bt";

  const seccion = (label: string) => `<tr><td colspan="6" class="section-row">${esc(label)}</td></tr>`;
  const subheading = (text: string) => `<tr><td colspan="6" class="subheading">${esc(text)}</td></tr>`;
  const dosLabelValue = (l1: string, v1: string, l2: string, v2: string) =>
    `<tr><td class="label-cell">${esc(l1)}</td><td colspan="2">${esc(v1 || "—")}</td><td class="label-cell">${esc(l2)}</td><td colspan="2">${esc(v2 || "—")}</td></tr>`;
  const labelValue = (label: string, value: string) =>
    `<tr><td class="label-cell">${esc(label)}</td><td colspan="5">${esc(value || "—")}</td></tr>`;
  const bullets = (lines: string[]) =>
    `<tr><td colspan="6">${lines.filter(Boolean).length
      ? lines.filter(Boolean).map((l) => `<div>${esc(l)}</div>`).join("")
      : "—"}</td></tr>`;
  const header6 = (labels: string[]) => `<tr>${labels.map((l) => `<th>${esc(l)}</th>`).join("")}</tr>`;
  const semanaCellHTML = (label: string) => `<td style="text-align:center;font-weight:bold;">${esc(label)}</td>`;
  const contentCellHTML = (lines: string[]) =>
    `<td>${lines.length ? lines.map((l) => `<div>${esc(l)}</div>`).join("") : "—"}</td>`;

  // Cuadrado DUA — misma convención visual (color pleno si aplica, atenuado si no) que el resto de la app.
  const duaSquareHTML = (activo: boolean, color: string) =>
    `<span style="display:inline-block;width:6px;height:6px;background:${activo ? color : color + "38"};border-radius:1px;vertical-align:middle;margin-left:1px;-webkit-print-color-adjust:exact;print-color-adjust:exact;"></span>`;
  const duaSquaresHTML = (dua?: DUAActividad) => {
    const d = dua ?? { representacion: false, accionExpresion: false, implicacion: false };
    return duaSquareHTML(d.representacion, "#EC4899") + duaSquareHTML(d.accionExpresion, "#1E3A5F") + duaSquareHTML(d.implicacion, "#22C55E");
  };
  /** Celda de actividades con indicadores DUA por línea — igual convención que el resto de la app (no JSON ni etiquetas sueltas) */
  const actividadesConDuaCellHTML = (actividades: string[], dua?: DUAActividad[]) => {
    const items = actividades.filter(Boolean);
    if (!items.length) return `<td>—</td>`;
    const leyenda = dua?.length
      ? `<div style="font-size:7px;margin-bottom:2px;">
          ${duaSquareHTML(true, "#EC4899")} Repr.&nbsp;
          ${duaSquareHTML(true, "#1E3A5F")} Acc/Exp.&nbsp;
          ${duaSquareHTML(true, "#22C55E")} Impl.
        </div>`
      : "";
    return `<td>${leyenda}${items.map((act, idx) => `<div>${esc(act)}${dua?.length ? duaSquaresHTML(dua[idx]) : ""}</div>`).join("")}</td>`;
  };

  const semana1HTML = `<tr>
      ${semanaCellHTML("SEMANA 1")}
      ${contentCellHTML(plan.semana1.diagnosticoAcademico.map((d) => `${d.destrezaCodigo}: ${d.destrezaDescripcion}`))}
      ${contentCellHTML(cncIndicadoresParaDestrezas(plan.semana1.diagnosticoAcademico))}
      ${actividadesConDuaCellHTML(plan.semana1.actividadesAdaptacion, plan.semana1.duaActividadesAdaptacion)}
      ${contentCellHTML(plan.aiResult?.recursosSemana1Sugeridos ?? [])}
      ${contentCellHTML(["Diagnóstico dual (académico y socioemocional)"])}
    </tr>`;

  const nivelacionSemanasHTML = [2, 3].map((numSemana) => {
    const actividadesSemana = plan.semana2y3.actividadesNivelacion.filter((a) => a.semana === numSemana);
    const parejasSemana = plan.semana2y3.parejasConivelacion.filter(
      (_, i) => (numSemana === 2 ? i % 2 === 0 : i % 2 === 1)
    );
    return `<tr>
        ${semanaCellHTML(`SEMANA ${numSemana}`)}
        ${contentCellHTML(actividadesSemana.map((a) => `${a.destrezaCodigo}: ${a.destrezaDescripcion}`))}
        ${contentCellHTML(cncIndicadoresParaDestrezas(actividadesSemana))}
        ${contentCellHTML(actividadesSemana.map((a) => a.descripcionActividad || "—"))}
        ${contentCellHTML(parejasSemana.map((p) => `Co-nivelación: ${p.estudianteApoyoNombre || "—"} → ${p.estudianteApoyadoNombre || "—"} (${p.destrezaFocoDescripcion})`))}
        ${contentCellHTML(plan.aiResult?.actividadesEvaluativasNivelacionSugeridas ?? [])}
      </tr>`;
  }).join("");

  const conivelacionHTML = plan.semana2y3.parejasConivelacion.length
    ? plan.semana2y3.parejasConivelacion
        .map((p) => `<tr><td colspan="2">${esc(p.estudianteApoyoNombre)}</td><td colspan="2">${esc(p.estudianteApoyadoNombre)}</td><td colspan="2">${esc(p.destrezaFocoDescripcion)}</td></tr>`)
        .join("")
    : bullets([]);

  return `<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8" />
<title>Conecta, Nivela y Crea</title>
<style>
  * { box-sizing: border-box; }
  body { font-family: Arial, Helvetica, sans-serif; color: #000; margin: 24px; font-size: 8px; }
  table.tabla-plan { width:100%; border-collapse:collapse; }
  table.tabla-plan td, table.tabla-plan th { border:1px solid #999; padding:5px 8px; text-align:left; vertical-align:top; font-size:8px; }
  table.tabla-plan th { background:#1A3A5C; color:#fff; font-weight:bold; }
  .title-cell { background:#003366; color:#fff; text-align:center; padding:12px; }
  .title-cell .titulo { font-size:14px; font-weight:bold; }
  .title-cell .subt { font-size:8px; margin-top:2px; }
  .section-row { background:#DDEFF1; font-weight:bold; padding:6px 8px; }
  .subheading { font-weight:bold; }
  .label-cell { background:#EAF4F6; font-weight:bold; width:16%; }
  .banner-oficial { background:#DC2626; color:#fff; font-weight:bold; }
  @media print { body { margin: 10mm; } }
</style>
</head>
<body>
  <table class="tabla-plan">
    <tr><td colspan="6" class="title-cell">
      <div class="titulo">CONECTA, NIVELA Y CREA</div>
      <div class="subt">${esBT ? "Arranque del año escolar — Bachillerato Técnico" : "Arranque del año escolar — 5 semanas"}</div>
    </td></tr>

    ${seccion("DATOS INFORMATIVOS")}
    ${dosLabelValue("Institución:", plan.institucion, "Docente:", plan.docente)}
    ${dosLabelValue("Grado / Paralelo:", `${plan.grado || "—"} / ${plan.paralelo || "—"}`, "Año lectivo:", plan.anioLectivo)}
    ${dosLabelValue("Modalidad:", esBT ? "Bachillerato Técnico" : "General (EGB/BGU)", "Módulo:", esBT ? (plan.moduloId || "—") : "—")}

    ${seccion("SEMANA 1 — CONECTA")}
    ${labelValue("Metodología declarada:", plan.semana1.metodologiaDeclarada)}
    ${header6(CNC_COLUMNAS_SEMANA)}
    ${semana1HTML}
    ${esBT && plan.semana1BT ? `
    ${subheading("Reconocimiento de espacios técnicos")}
    ${bullets(plan.semana1BT.reconocimientoEspacios)}
    ${plan.semana1BT.diagnosticoTecnico.length ? subheading("Diagnóstico técnico (criterios reales del módulo)") : ""}
    ${plan.semana1BT.diagnosticoTecnico.length ? bullets(plan.semana1BT.diagnosticoTecnico.map((d) => `${d.criterioTexto} — ${d.nivelDetectado}`)) : ""}
    ` : ""}
    ${subheading("Diagnóstico socioemocional")}
    ${bullets(plan.semana1.diagnosticoSocioemocional.map((h) => `${h.habilidadId}${h.observaciones ? " — " + h.observaciones : ""}`))}
    ${labelValue("Coordinación DECE:", plan.semana1.coordinacionDece)}
    ${plan.semana1.tecnicasReflexion.filter(Boolean).length ? subheading("Técnicas de reflexión") : ""}
    ${plan.semana1.tecnicasReflexion.filter(Boolean).length ? bullets(plan.semana1.tecnicasReflexion) : ""}

    ${seccion("SEMANAS 2-3 — NIVELA")}
    ${header6(CNC_COLUMNAS_SEMANA)}
    ${nivelacionSemanasHTML}
    ${esBT && plan.semana2y3BT?.actividadesNivelacionTecnica.length ? `
    ${subheading("Nivelación técnica")}
    <tr><th colspan="2">Criterio técnico</th><th colspan="2">Actividad</th><th colspan="2">Articulación con Matemática</th></tr>
    ${plan.semana2y3BT.actividadesNivelacionTecnica.map((a) => `<tr><td colspan="2">${esc(a.criterioTexto)}</td><td colspan="2">${esc(a.descripcionActividad || "—")}</td><td colspan="2">${esc(a.articulacionMatematica || "—")}</td></tr>`).join("")}
    ` : ""}
    ${subheading("Parejas de co-nivelación (tutoría entre pares)")}
    ${plan.semana2y3.parejasConivelacion.length ? `<tr><th colspan="2">Apoya</th><th colspan="2">Apoyado</th><th colspan="2">Destreza foco</th></tr>` : ""}
    ${conivelacionHTML}

    ${seccion("SEMANAS 4-5 — CREA")}
    <tr><td colspan="6" class="banner-oficial">ESTE PROYECTO CONSTITUYE UNA EVALUACIÓN CUALITATIVA FORMATIVA OFICIAL</td></tr>
    ${esBT && plan.semana4y5BT
      ? `${labelValue("Tipo de producto acreditable:", plan.semana4y5BT.productoAcreditable.tipo.replace(/_/g, " "))}
         ${labelValue("Descripción:", plan.semana4y5BT.productoAcreditable.descripcion)}
         ${header6(CNC_COLUMNAS_SEMANA)}
         <tr>
           ${semanaCellHTML("SEMANA 4")}
           ${contentCellHTML([plan.semana4y5BT.productoAcreditable.tipo.replace(/_/g, " ")])}
           ${contentCellHTML(criteriosTecnicosDeModuloCNC(plan))}
           ${contentCellHTML(plan.semana4y5BT.productoAcreditable.actividadesSemana4?.filter(Boolean).length ? plan.semana4y5BT.productoAcreditable.actividadesSemana4.filter(Boolean) : ["Diseño y elaboración del producto acreditable"])}
           ${contentCellHTML(recursosProyectoCNC(plan))}
           ${contentCellHTML(["Seguimiento formativo del proceso de elaboración"])}
         </tr>
         <tr>
           ${semanaCellHTML("SEMANA 5")}
           ${contentCellHTML([plan.semana4y5BT.productoAcreditable.tipo.replace(/_/g, " ")])}
           ${contentCellHTML(criteriosTecnicosDeModuloCNC(plan))}
           ${contentCellHTML(plan.semana4y5BT.productoAcreditable.actividadesSemana5?.filter(Boolean).length ? plan.semana4y5BT.productoAcreditable.actividadesSemana5.filter(Boolean) : ["Presentación del producto acreditable"])}
           ${contentCellHTML(recursosProyectoCNC(plan))}
           ${contentCellHTML(["Evaluación cualitativa formativa oficial"])}
         </tr>`
       : `${labelValue("Título:", plan.semana4y5.proyecto.titulo)}
          ${labelValue("Áreas integradas:", plan.semana4y5.proyecto.areasIntegradas.join(", "))}
          ${labelValue("Descripción:", plan.semana4y5.proyecto.descripcion)}
          ${labelValue("Producto final:", plan.semana4y5.proyecto.productoFinal)}
          ${header6(CNC_COLUMNAS_SEMANA)}
          <tr>
            ${semanaCellHTML("SEMANA 4")}
            ${contentCellHTML(plan.semana4y5.proyecto.destrezasReforzadas)}
            ${contentCellHTML(plan.semana4y5.proyecto.evidenciasCognitivas)}
            ${contentCellHTML(plan.semana4y5.proyecto.actividadesSemana4?.filter(Boolean).length ? plan.semana4y5.proyecto.actividadesSemana4.filter(Boolean) : ["Diseño y desarrollo del proyecto interdisciplinario"])}
            ${contentCellHTML(recursosProyectoCNC(plan))}
            ${contentCellHTML(["Seguimiento formativo del desarrollo del proyecto"])}
          </tr>
          <tr>
            ${semanaCellHTML("SEMANA 5")}
            ${contentCellHTML(plan.semana4y5.proyecto.destrezasReforzadas)}
            ${contentCellHTML(plan.semana4y5.proyecto.evidenciasActitudinales)}
            ${contentCellHTML(plan.semana4y5.proyecto.actividadesSemana5?.filter(Boolean).length ? plan.semana4y5.proyecto.actividadesSemana5.filter(Boolean) : ["Presentación y socialización del proyecto interdisciplinario"])}
            ${contentCellHTML(recursosProyectoCNC(plan))}
            ${contentCellHTML(["Evaluación cualitativa formativa oficial"])}
          </tr>`}
  </table>
</body>
</html>`;
}
