﻿export type Area =
  | "M"
  | "LL"
  | "CN"
  | "CS"
  | "EF"
  | "ECA"
  | "CN.B"
  | "CN.Q"
  | "CN.F"
  | "CS.H"
  | "CS.F"
  | "CS.EC"
  | "CAI"
  | "EFL"
  | "EG"
  | "INI";

export type Subnivel = -1 | 0 | 1 | 2 | 3 | 4 | 5;

export interface AreaInfo {
  code: Area;
  name: string;
  color: string;
  icon: string;
  emoji: string;
  bloques: Record<number, string>;
}

export interface Destreza {
  codigo: string;
  area: Area;
  subnivel: Subnivel;
  bloque: number;
  secuencial: number;
  descripcion: string;
  objetivos: string[];
  criteriosEvaluacion: string[];
  indicadoresEvaluacion: string[];
  /** IDs de habilidades socioemocionales pre-asignadas (solo CAI — bloqueadas en UI) */
  habilidadesSocioemocionales?: string[];
}

// ============================================================
// DESAGREGACIÓN / GRADACIÓN DE DCD POR GRADO
// ============================================================

/** Estado de una fila de desagregación: generada por IA, editada o aprobada por el docente */
export type EstadoDesagregacion = "generado" | "editado" | "aprobado";

/**
 * Fila de desagregación/gradación de una DCD para un grado del subnivel.
 * Es una DERIVACIÓN editable que referencia a la DCD oficial por código:
 * el catálogo (data/destrezas-*.ts) nunca se modifica. El último grado del
 * subnivel conserva la DCD e indicador completos (texto oficial).
 */
export interface DcdDesagregacion {
  /** Código de la DCD oficial del catálogo */
  codigoDCD: string;
  /** Subnivel al que pertenece la DCD */
  subnivel: Subnivel;
  /** Grado destino de esta versión graduada (p. ej. 3) */
  grado: number;
  /** Último grado del subnivel — recibe la versión completa */
  gradoMaximo: number;
  /** Snapshot del texto oficial de la DCD */
  descripcionDCD: string;
  /** Texto oficial del indicador de evaluación asociado */
  indicadorOriginal: string;
  /** Texto graduado de la DCD para este grado */
  dcdGraduada: string;
  /** Texto graduado del indicador para este grado */
  indicadorGraduado: string;
  /** Proceso cognitivo esperado para el grado (referencia Marzano) */
  procesoCognitivo?: string;
  /** Estado de la fila */
  estado: EstadoDesagregacion;
  /** Número de versión: se incrementa en cada regeneración */
  version: number;
}

/** Insumo por grado para generar una desagregación (sin estado ni versión, que asigna el servidor) */
export interface DcdDesagregacionInput {
  /** Código de la DCD oficial del catálogo */
  codigoDCD: string;
  subnivel: Subnivel;
  /** Grado destino de esta versión graduada */
  grado: number;
  /** Último grado del subnivel */
  gradoMaximo: number;
  /** Texto oficial de la DCD */
  descripcionDCD: string;
  /** Texto oficial del indicador */
  indicadorOriginal: string;
  /** Proceso cognitivo esperado para el grado (verbos Marzano) */
  procesoCognitivo?: string;
}

/**
 * Indicadores DUA por actividad: 3 principios representados como cuadrados de colores.
 * - implicacion (verde): Múltiples formas de Implicación
 * - representacion (rosa/rojo): Múltiples formas de Representación
 * - accionExpresion (azul): Múltiples formas de Acción y Expresión
 */
export interface DUAActividad {
  implicacion: boolean;
  representacion: boolean;
  accionExpresion: boolean;
}

/**
 * Fase de una clase con título, duración y actividades.
 * Cada actividad puede tener indicadores DUA asociados.
 */
export interface FaseClase {
  titulo: string;
  duracion: string;
  actividades: string[];
  /** Indicadores DUA por cada actividad (mismo índice que actividades[]) */
  duaActividades?: DUAActividad[];
}

/**
 * Estructura de una clase de 45 minutos distribuida en 4 fases ERCA:
 * - Experiencia (10 min): Activación de conocimientos previos y vivencias
 * - Reflexión (10 min): Análisis y cuestionamiento de la experiencia
 * - Conceptualización (15 min): Construcción formal del conocimiento
 * - Aplicación (10 min): Transferencia y práctica del aprendizaje
 */
export interface EstructuraClase {
  experiencia: FaseClase;
  reflexion: FaseClase;
  conceptualizacion: FaseClase;
  aplicacion: FaseClase;
}

/**
 * Adaptación curricular específica para un día de la semana.
 * Se genera cuando hay contexto de planificación semanal (actividades ERCA reales).
 */
export interface AdaptacionDiaPlan {
  dia: string;
  adaptacionAcceso: string;
  adaptacionMetodologica: string;
  recursosAdaptados: string[];
  evaluacionAdaptada: string;
}

/** Evaluación formativa estructurada con técnica, instrumento, evidencia y criterio */
export interface EvaluacionEstructurada {
  tecnica: string;
  instrumento: string;
  evidencia: string;
  criterio: string;
}

/** Criterio de una rúbrica de evaluación con 4 niveles de desempeño (MinEduc Ecuador) */
export interface RubricaCriterio {
  criterio: string;
  excelente: string;
  satisfactorio: string;
  enProceso: string;
  noAlcanza: string;
}

/**
 * Tema sugerido para una destreza, con estructura de clase pre-generada
 */
export interface TemaSugerido {
  id: string;
  titulo: string;
  descripcionBreve: string;
  objetivoClase: string;
  estructura: EstructuraClase;
  recursos: string[];
  evaluacionFormativa: string;
  /** Evaluación formativa estructurada (generada por IA) — backward compatible */
  evaluacionEstructurada?: EvaluacionEstructurada;
  /** Rúbrica de evaluación con 3 criterios × 4 niveles (generada por IA) */
  rubricaSemanal?: RubricaCriterio[];
}

/**
 * Porcentajes de estilos de aprendizaje del grupo (suman 100%)
 */
export interface EstilosAprendizajePorcentaje {
  visual: number;
  auditivo: number;
  lectorEscritor: number;
  kinestesico: number;
}

export interface Planificacion {
  id: string;
  fecha: string;
  institucion: string;
  docente: string;
  grado: string;
  asignatura: string;
  periodos: string;
  semana?: string;
  unidadDidactica?: string;
  /** Formato oficial 2026-2027 */
  periodoPedagogico?: string;
  trimestre?: string;
  nivel?: string;
  fechaInicio?: string;
  fechaFin?: string;
  paralelo?: string;
  bloquesCurriculares?: string[];
  /** Habilidades socioemocionales asociadas */
  habilidadesSocioemocionales?: string[];
  /** Porcentajes de estilos de aprendizaje del grupo */
  estilosAprendizajePorcentaje?: EstilosAprendizajePorcentaje;
  destreza: Destreza;
  /**
   * Descripción efectiva de la DCD usada en esta planificación: la versión
   * graduada (desagregación) cuando fue seleccionada, o vacío para usar la
   * `descripcion` oficial del catálogo. Es un resultado MATERIALIZADO en el
   * plan (snapshot): editar o regenerar la desagregación después no lo cambia.
   */
  descripcionEfectiva?: string;
  objetivoAprendizaje: string;
  temaSeleccionado?: TemaSugerido;
  actividades: string;
  recursos: string;
  evaluacion: string;
  tecnicasInstrumentos: string;
  observaciones: string;
  /** Si el docente eligió trabajar con ejes transversales */
  usaEjesTransversales?: boolean;
  /** IDs de inserciones curriculares seleccionadas */
  insercionesCurriculares?: string[];
  /** Legacy: single insercion field (backward compat) */
  insercionCurricular?: string;
  /** Si el docente eligió trabajar con competencias */
  usaCompetencias?: boolean;
  /** IDs de competencias seleccionadas */
  competencias?: string[];
  /** IDs de metodologías activas seleccionadas */
  metodologiasActivas?: string[];
  /** IDs de técnicas e instrumentos de evaluación seleccionadas */
  tecnicasEvaluacionSeleccionadas?: string[];
  /** IDs de estilos de aprendizaje seleccionados */
  estilosAprendizaje?: string[];
  dua?: {
    representacion: string;
    accionExpresion: string;
    implicacion: string;
  };
  /** Adaptaciones curriculares vinculadas a esta planificación diaria */
  adaptacionesCurriculares?: AdaptacionCurricular[];
  createdAt: string;
  updatedAt: string;
}

// ============================================================
// PLANIFICACIÓN CURRICULAR ANUAL (PCA)
// ============================================================

/** Eje transversal seleccionable en la PCA */
export interface EjeTransversalPCA {
  id: string;
  nombre: string;
  descripcion: string;
}

/** DCD seleccionada para una unidad: código + enunciado completo */
export interface DcdSeleccionada {
  codigo: string;
  enunciado: string;
  /**
   * Procedencia de la versión: "oficial" (catálogo) o "desagregada" (graduada
   * por grado). Opcional con default "oficial" para compatibilidad con
   * selecciones existentes (p. ej. CNC).
   */
  origen?: "oficial" | "desagregada";
  /** Grado de la versión desagregada (solo cuando origen === "desagregada"). */
  grado?: number;
}

/** Una unidad de planificación dentro de la PCA */
export interface PcaUnidad {
  id: string;
  /** Número de unidad (1, 2, 3...) */
  numero: number;
  /** DCD seleccionadas por el docente para esta unidad */
  dcdsSeleccionadas: DcdSeleccionada[];
  /** Duración en semanas — el docente la define */
  duracionSemanas: number;
  // ──── Campos generados por la IA ────
  titulo?: string;
  objetivosEspecificos?: string;
  contenidos?: string;
  orientacionesMetodologicas?: string;
  evaluacion?: string;
}

/** Datos del formulario PCA que el docente completa (Tipo A) */
export interface PcaFormData {
  institucion: string;
  docente: string;
  area: Area;
  subnivel: Subnivel;
  grado: string;
  anioLectivo: string;
  paralelo: string;
  // Sección Tiempo
  cargaHorariaSemanal: number;
  semanasTrabajoTotal: number;
  semanasEvaluacion: number;
  // Sección Ejes Transversales
  usaEjesTransversales: boolean;
  ejesTransversales: string[];
  // Sección Unidades
  unidades: PcaUnidad[];
  // Sección Metodologías y Evaluación
  metodologiasActivas: string[];
  tecnicasEvaluacion: string[];
  // Sección Bibliografía
  bibliografiaDocente: string;
  // Sección Firmas
  firmaElaboradoPor: string;
  firmaElaboradoFecha: string;
  firmaRevisadoPor: string;
  firmaRevisadoFecha: string;
  firmaAprobadoPor: string;
  firmaAprobadoFecha: string;
}

/** Resultado completo generado por la IA para la PCA */
export interface PcaAiResult {
  objetivosArea: string;
  objetivosGrado: string;
  unidades: Array<{
    numero: number;
    titulo: string;
    objetivosEspecificos: string;
    contenidos: string;
    orientacionesMetodologicas: string;
    evaluacion: string;
    duracionSemanas: number;
  }>;
  bibliografiaSugerida: string;
  observaciones: string;
}

/** Documento PCA completo tal como se guarda en la BD */
export interface PcaDocument {
  id: number;
  sessionId: string;
  status: "draft" | "generated" | "paid";
  formData: PcaFormData;
  aiResult: PcaAiResult | null;
  clientTransactionId: string | null;
  payphoneTransactionId: number | null;
  authorizationCode: string | null;
  amountPaid: number | null;
  createdAt: string;
  updatedAt: string;
}

export const SUBNIVEL_NAMES: Record<Subnivel, string> = {
  [-1]: "",
  0: "",
  1: "Preparatoria",
  2: "Básica Elemental",
  3: "Básica Media",
  4: "Básica Superior",
  5: "Bachillerato",
};

export const SUBNIVEL_GRADOS: Record<Subnivel, string> = {
  [-1]: "",
  0: "",
  1: "1er grado EGB",
  2: "2do - 4to grado EGB",
  3: "5to - 7mo grado EGB",
  4: "8vo - 10mo grado EGB",
  5: "1ro - 3ro BGU",
};

// ============================================================
// PLANIFICACIÓN SEMANAL
// ============================================================

/** Una hora de clase dentro de un día de la semana */
export interface HoraSemanal {
  id: string;
  codigoDestreza: string;
  destreza: Destreza | null;
  /**
   * Descripción efectiva de la DCD de esta hora: la versión graduada
   * (desagregación) cuando fue seleccionada, o vacío para usar la `descripcion`
   * oficial. Resultado MATERIALIZADO (snapshot): no se re-resuelve contra la
   * desagregación al generar el documento.
   */
  descripcionEfectiva?: string;
  tema: string;
  temasAlternativos: TemaSugerido[];
  temaSeleccionado: TemaSugerido | null;
  // Configuración didáctica por hora (antes estaban en ConfiguracionDia)
  habilidadesSocioemocionales: string[];
  usaEjesTransversales: boolean;
  insercionesCurriculares: string[];
  usaCompetencias: boolean;
  competencias: string[];
  metodologiasActivas: string[];
  tecnicasEvaluacion: string[];
  deporteEnfoque?: string;
}

/** Configuración completa de un día de la semana */
export interface ConfiguracionDia {
  activo: boolean;
  cantidadHoras: 1 | 2 | 3;
  horas: HoraSemanal[];
}

/** Planificación semanal completa (5 días) */
export interface PlanificacionSemanal {
  id: string;
  fecha: string;
  semanaInicio: string;
  semanaFin: string;
  institucion: string;
  docente: string;
  asignatura?: string;
  subnivel?: string;
  grado: string;
  nivel: string;
  paralelo: string;
  periodoPedagogico: string;
  trimestre: string;
  periodos: string;
  numeroUnidad: string;
  tituloUnidad: string;
  objetivosUnidad: string;
  bloqueCAI?: number;
  duaRepresentacion: string;
  duaAccionExpresion: string;
  duaImplicacion: string;
  pctVisual: string;
  pctAuditivo: string;
  pctLectorEscritor: string;
  pctKinestesico: string;
  dias: {
    lunes: ConfiguracionDia;
    martes: ConfiguracionDia;
    miercoles: ConfiguracionDia;
    jueves: ConfiguracionDia;
    viernes: ConfiguracionDia;
  };
  createdAt: string;
  updatedAt: string;
  /** Adaptaciones curriculares vinculadas a esta planificación semanal */
  adaptacionesCurriculares?: AdaptacionCurricular[];
}

// ============================================================
// ADAPTACIONES CURRICULARES
// ============================================================

export type GradoAdaptacion = 1 | 2 | 3;

export type TipoNEE =
  | "discapacidad_visual"
  | "discapacidad_auditiva"
  | "discapacidad_motriz"
  | "discapacidad_intelectual"
  | "tea"
  | "tdah"
  | "dislexia"
  | "discalculia"
  | "trastorno_lenguaje"
  | "altas_capacidades"
  | "dificultades_socioemocionales"
  | "otra";

export interface AdaptacionPedagogicaSugerida {
  categoria: string;
  descripcion: string;
  estrategias: string[];
}

export interface AdaptacionAiResult {
  perfilNEE: {
    tipo: string;
    descripcion: string;
    fortalezas: string[];
    desafios: string[];
    apoyos: string[];
  };
  destrezaOriginal: {
    codigo: string;
    descripcion: string;
  };
  /** Solo para grado 2 y 3 */
  destrezaAdaptada?: string;
  /** Solo para grado 2 y 3 */
  criterioAdaptado?: string;
  /** Solo para grado 2 y 3 */
  indicadoresAdaptados?: string[];
  /** Siempre presente (grado 1, 2, 3) */
  adaptacionesAcceso: AdaptacionPedagogicaSugerida[];
  /** Solo para grado 2 y 3 */
  adaptacionesProceso?: AdaptacionPedagogicaSugerida[];
  /** Solo para grado 3 */
  adaptacionesResultado?: AdaptacionPedagogicaSugerida[];
  metodologiasSugeridas: string[];
  recursosEspecificos: string[];
  seguimiento: string;
  observaciones: string;
  /** Adaptaciones por fase del ciclo ERCA — opcional, campos nuevos */
  adaptacionesERCA?: {
    experiencia: string[];
    reflexion: string[];
    conceptualizacion: string[];
    aplicacion: string[];
  };
  /** Criterios e instrumentos de evaluación adaptados */
  evaluacionAdaptada?: {
    criterios: string[];
    instrumentos: string[];
  };
  /** Rúbrica de evaluación con 4 niveles de desempeño */
  rubrica?: Array<{
    criterio: string;
    excelente: string;
    satisfactorio: string;
    enProceso: string;
    necesitaApoyo: string;
  }>;
  /**
   * Adaptaciones organizadas por día, referenciando las actividades ERCA reales
   * de la planificación semanal vinculada. Sustituye las secciones genéricas de
   * acceso / proceso / resultado / metodologías cuando hay contexto semanal.
   */
  adaptacionesPorDia?: AdaptacionDiaPlan[];
}

/**
 * Adaptación curricular por día de la semana, vinculada a la planificación semanal.
 * Incluye adaptación de cada fase ERCA planificada para ese día.
 */
export interface AdaptacionDiaPlan {
  dia: string;
  /** Objetivo de clase del día (tomado de la planificación semanal) */
  objetivo?: string;
  /** Objetivo adaptado al perfil NEE del estudiante (generado por IA) */
  objetivoAdaptado?: string;
  adaptacionAcceso: string;
  /** Adaptación de cada fase ERCA del día (estrategias metodológicas activas) */
  adaptacionERCA: {
    experiencia: string;
    reflexion: string;
    conceptualizacion: string;
    aplicacion: string;
  };
  recursosAdaptados: string[];
  evaluacionAdaptada: string;
}

export interface CurricularAdaptationForm {
  // Identificación del contexto
  institucion: string;
  docente: string;
  anioLectivo: string;
  area: string;
  subnivel: number;
  grado: string;
  paralelo: string;
  periodoPedagogico: string;
  trimestre: string;
  /** Código anónimo — no se requiere nombre real del estudiante */
  codigoEstudiante: string;
  // Destreza a adaptar
  codigoDestreza: string;
  descripcionDestreza: string;
  // Configuración de la adaptación
  gradoAdaptacion: GradoAdaptacion;
  tipoNEE: TipoNEE;
  estiloAprendizaje: string;
  // Perfil pedagógico
  fortalezas: string;
  desafios: string;
  apoyosDisponibles: string;
}

export interface CurricularAdaptation {
  id: string;
  sessionId: string;
  form: CurricularAdaptationForm;
  aiResult: AdaptacionAiResult | null;
  version: number;
  status: "draft" | "generated";
  createdAt: string;
  updatedAt: string;
}

/**
 * Versión embebida que se guarda dentro de PlanificacionSemanal y se incluye
 * en los documentos exportados (Word/PDF).
 * NO incluir diagnósticos médicos — solo información pedagógica.
 * Usar código anónimo; el nombre del estudiante es opcional.
 */
export interface AdaptacionCurricular {
  id: string;
  /** Código anónimo del estudiante — no exponer nombre real por defecto */
  codigoEstudiante: string;
  /** Nombre del estudiante — opcional y configurable para la exportación */
  nombreEstudiante?: string;
  /** Si false, no aparece en el documento exportado */
  incluirEnExportacion: boolean;
  // Contexto curricular
  codigoDestreza: string;
  descripcionDestreza?: string;
  gradoAdaptacion: GradoAdaptacion;
  categoriaNecesidad: string;
  tipoNecesidad: TipoNEE;
  /** Descripción pedagógica del perfil — sin lenguaje médico ni diagnóstico clínico */
  descripcionNecesidad?: string;
  // Resultados de la adaptación (según grado)
  destrezaAdaptada?: string;        // grado 2 y 3
  criterioAdaptado?: string;        // grado 2 y 3
  indicadoresAdaptados?: string[];  // grado 2 y 3
  adaptacionesAcceso: AdaptacionPedagogicaSugerida[];
  adaptacionesProceso?: AdaptacionPedagogicaSugerida[];    // grado 2 y 3
  adaptacionesResultado?: AdaptacionPedagogicaSugerida[];  // grado 3
  metodologiasSugeridas?: string[];
  recursosEspecificos?: string[];
  seguimiento?: string;
  observaciones?: string;
  /** Adaptaciones por día vinculadas a la planificación semanal */
  adaptacionesPorDia?: AdaptacionDiaPlan[];
  createdAt: string;
}

export const TIPOS_NEE_INFO: Record<TipoNEE, { nombre: string; emoji: string }> = {
  discapacidad_visual:          { nombre: "Discapacidad Visual",              emoji: "👁️" },
  discapacidad_auditiva:        { nombre: "Discapacidad Auditiva / Hipoacusia", emoji: "👂" },
  discapacidad_motriz:          { nombre: "Discapacidad Motriz / Física",     emoji: "♿" },
  discapacidad_intelectual:     { nombre: "Discapacidad Intelectual",         emoji: "🧠" },
  tea:                          { nombre: "TEA — Trastorno del Espectro Autista", emoji: "🧩" },
  tdah:                         { nombre: "TDAH — Déficit de Atención e Hiperactividad", emoji: "⚡" },
  dislexia:                     { nombre: "Dislexia",                        emoji: "📖" },
  discalculia:                  { nombre: "Discalculia",                     emoji: "🔢" },
  trastorno_lenguaje:           { nombre: "Trastorno del Lenguaje",          emoji: "💬" },
  altas_capacidades:            { nombre: "Altas Capacidades / Superdotación", emoji: "⭐" },
  dificultades_socioemocionales:{ nombre: "Dificultades Socioemocionales",   emoji: "💛" },
  otra:                         { nombre: "Otra NEE",                        emoji: "📋" },
};

export const GRADO_ADAPTACION_INFO: Record<GradoAdaptacion, { nombre: string; descripcion: string; color: string }> = {
  1: {
    nombre: "Grado 1 — No Significativa",
    descripcion: "Adaptaciones de acceso: ajustes en metodología, recursos y organización del aula sin modificar la destreza ni los criterios de evaluación.",
    color: "#16A34A",
  },
  2: {
    nombre: "Grado 2 — Moderada",
    descripcion: "Adaptaciones de acceso y de proceso: se ajustan actividades, tiempos y agrupamientos. La destreza se simplifica levemente pero conserva el objetivo central.",
    color: "#D97706",
  },
  3: {
    nombre: "Grado 3 — Significativa",
    descripcion: "Adaptaciones de acceso, proceso y resultado: se modifica sustancialmente la destreza, el criterio de evaluación y los indicadores de logro.",
    color: "#DC2626",
  },
};

// Ámbitos de desarrollo y aprendizaje del currículo integrador de Preparatoria
// (subnivel 1). No es un área curricular: agrupa destrezas de varias áreas
// (M, CN, CS, LL, EFL, EF, ECA) cuyo `bloque` coincide con el número de ámbito.
// Fuente: Currículo Priorizado 2025, Subnivel Preparatoria, secciones 8.1-8.7 (pp.20-38).
export const AMBITOS_PREPARATORIA: Record<number, string> = {
  1: "Identidad y Autonomía",
  2: "Convivencia",
  3: "Descubrimiento y comprensión del medio natural y cultural",
  4: "Relaciones lógico-matemáticas",
  5: "Comprensión y expresión oral y escrita",
  6: "Comprensión y expresión artística",
  7: "Expresión corporal",
};

export const AREAS_INFO: Record<Area, AreaInfo> = {
  M: {
    code: "M",
    name: "Matemática",
    color: "#2563EB",
    icon: "calculate",
    emoji: "\uD83D\uDD22",
    bloques: {
      1: "Álgebra y funciones",
      2: "Geometría y medida",
      3: "Estadística y probabilidad",
    },
  },
  LL: {
    code: "LL",
    name: "Lengua y Literatura",
    color: "#DC2626",
    icon: "menu-book",
    emoji: "\uD83D\uDCD6",
    bloques: {
      1: "Lengua y cultura",
      2: "Comunicación oral",
      3: "Lectura",
      4: "Escritura",
      5: "Literatura",
    },
  },
  CN: {
    code: "CN",
    name: "Ciencias Naturales",
    color: "#16A34A",
    icon: "science",
    emoji: "\uD83E\uDDEA",
    bloques: {
      1: "Los seres vivos y su ambiente",
      2: "Cuerpo humano y salud",
      3: "Materia y energía",
      4: "La Tierra y el Universo",
      5: "Ciencia en acción",
    },
  },
  CS: {
    code: "CS",
    name: "Estudios Sociales",
    color: "#D97706",
    icon: "public",
    emoji: "\uD83C\uDF0D",
    bloques: {
      1: "Historia e identidad",
      2: "Los seres humanos en el espacio",
      3: "La convivencia",
    },
  },
  EF: {
    code: "EF",
    name: "Educación Física",
    color: "#7C3AED",
    icon: "sports-soccer",
    emoji: "\u26BD",
    bloques: {
      1: "Prácticas lúdicas: los juegos y el jugar",
      2: "Prácticas gimnásticas",
      3: "Prácticas corporales expresivo-comunicativas",
      4: "Prácticas deportivas",
      5: "Construcción de la identidad corporal",
      6: "Relaciones entre prácticas corporales y salud",
    },
  },
  ECA: {
    code: "ECA",
    name: "Educación Cultural y Artística",
    color: "#EC4899",
    icon: "palette",
    emoji: "\uD83C\uDFA8",
    bloques: {
      1: "El yo: la identidad",
      2: "El encuentro con otros: la alteridad",
      3: "El entorno: espacio, tiempo y objetos",
    },
  },
  "CN.B": {
    code: "CN.B",
    name: "Biología",
    color: "#059669",
    icon: "biotech",
    emoji: "\uD83E\uDDA0",
    bloques: {
      1: "Origen y evolución de la vida",
      2: "Biología celular",
      3: "Biología animal y vegetal",
      4: "Cuerpo humano y salud",
      5: "Biología en acción",
    },
  },
  "CN.Q": {
    code: "CN.Q",
    name: "Química",
    color: "#7C3AED",
    icon: "science",
    emoji: "\u2697\uFE0F",
    bloques: {
      1: "Materia y sus transformaciones",
      2: "Estructura atómica y tabla periódica",
      3: "Reacciones químicas y estequiometría",
      4: "Química orgánica",
      5: "Química en acción",
    },
  },
  "CN.F": {
    code: "CN.F",
    name: "Física",
    color: "#0284C7",
    icon: "bolt",
    emoji: "\u269B\uFE0F",
    bloques: {
      1: "Movimiento y fuerza",
      2: "Energía, trabajo y potencia",
      3: "Ondas y sonido",
      4: "Óptica y luz",
      5: "Electricidad y magnetismo",
      6: "Física moderna y nuclear",
    },
  },
  "CS.H": {
    code: "CS.H",
    name: "Historia",
    color: "#B45309",
    icon: "history-edu",
    emoji: "\uD83C\uDFDB\uFE0F",
    bloques: {
      1: "Cultura y orígenes de la humanidad",
      2: "Civilizaciones antiguas y medievales",
      3: "América Latina y el mundo moderno",
      4: "Economía, sociedad y política contemporánea",
    },
  },
  "CS.F": {
    code: "CS.F",
    name: "Filosofía",
    color: "#6D28D9",
    icon: "psychology",
    emoji: "\uD83E\uDDD0",
    bloques: {
      1: "El origen del pensamiento filosófico y su método",
      2: "La argumentación y la construcción del discurso lógico",
      3: "Filosofía occidental y latinoamericana",
      4: "El individuo y la comunidad: lo ético, lo estético y lo hedónico",
    },
  },
  "CS.EC": {
    code: "CS.EC",
    name: "Educación para la Ciudadanía",
    color: "#0F766E",
    icon: "account-balance",
    emoji: "🏛️",
    bloques: {
      1: "Ciudadanía, derechos y sus declaraciones",
      2: "Igualdad natural y participación",
      3: "Orígenes de la democracia moderna",
      4: "Derechos civiles y políticos",
      5: "Democracia como experiencia social",
      6: "Democracia en Ecuador",
      7: "Cultura, identidad y plurinacionalidad",
      8: "Estado, nación y gobierno",
      9: "Asambleas constituyentes",
      10: "Republicanismo y modelos democráticos",
    },
  },
  "CAI": {
    code: "CAI",
    name: "Cívica — Acomp. Integral (CAI)",
    color: "#DC2626",
    icon: "account-balance",
    emoji: "🏛️",
    bloques: {
      1: "Período de Convivencia y Ciudadanía",
    },
  },
  EFL: {
    code: "EFL",
    name: "Inglés",
    color: "#0369A1",
    icon: "translate",
    emoji: "\uD83C\uDF10",
    bloques: {
      1: "Communication and cultural awareness",
      2: "Oral communication",
      3: "Reading",
      4: "Writing",
      5: "Language through the arts",
    },
  },
  EG: {
    code: "EG",
    name: "Emprendimiento y Gestión",
    color: "#CA8A04",
    icon: "business-center",
    emoji: "\uD83D\uDCBC",
    bloques: {
      1: "Contabilidad y administración",
      2: "Legislación laboral y tributaria",
      3: "Economía y finanzas",
      4: "Emprendimiento e innovación",
      5: "Plan de negocios",
    },
  },
  INI: {
    code: "INI",
    name: "Educación Inicial",
    color: "#0EA5E9",
    icon: "child-care",
    emoji: "🧒",
    bloques: {
      1: "Identidad y Autonomía",
      2: "Convivencia",
      3: "Relaciones con el medio natural y cultural",
      4: "Relaciones lógico-matemáticas",
      5: "Comprensión y Expresión del Lenguaje",
      6: "Expresión Artística",
      7: "Expresión corporal y motricidad",
    },
  },
};
