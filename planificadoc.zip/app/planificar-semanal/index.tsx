import { useState, useCallback, useEffect } from "react";
import {
  Text, View, ScrollView, TextInput, StyleSheet, Alert, Platform,
  ActivityIndicator, Switch, Pressable, FlatList, Modal,
} from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { DestrezaIconos } from "@/components/DestrezaIconos";
import { DcdDesagregacionPanel } from "@/components/DcdDesagregacionPanel";
import { useColors } from "@/hooks/use-colors";
import { usePlanificaciones } from "@/lib/planificaciones-context";
import {
  buscarDestrezas, TODAS_LAS_DESTREZAS, AREAS_INFO, SUBNIVEL_NAMES, SUBNIVEL_GRADOS,
  obtenerInsercionesPorAsignatura, METODOLOGIAS_ACTIVAS,
  TECNICAS_EVALUACION, HABILIDADES_SOCIOEMOCIONALES, obtenerNombreBloque,
  NOMBRES_BLOQUES_CAI, CRITERIOS_CAI, OBJETIVO_NIVEL_CAI,
  buscarPorCodigo, gradosDeSubnivel, resolverDcdConIndicador,
} from "@/data";
import type { Destreza, ConfiguracionDia, HoraSemanal, PlanificacionSemanal, TemaSugerido, DUAActividad, DcdDesagregacion } from "@/data/types";
import { trpc } from "@/lib/trpc";

// ─── Colores DUA fijos ───────────────────────────────────────
const DUA_ROSADO = "#EC4899";
const DUA_AZUL   = "#1E3A5F";
const DUA_VERDE  = "#22C55E";

const DEPORTES_EF: { value: string; label: string }[] = [
  { value: "Fútbol",             label: "⚽ Fútbol" },
  { value: "Básquetbol",         label: "🏀 Básquetbol" },
  { value: "Voleibol",           label: "🏐 Voleibol" },
  { value: "Atletismo",          label: "🏃 Atletismo" },
  { value: "Natación",           label: "🏊 Natación" },
  { value: "Gimnasia",           label: "🤸 Gimnasia" },
  { value: "Balonmano",          label: "🤾 Balonmano" },
  { value: "Béisbol / Softbol",  label: "⚾ Béisbol / Softbol" },
  { value: "Tenis de mesa",      label: "🏓 Tenis de mesa" },
  { value: "Ciclismo",           label: "🚴 Ciclismo" },
  { value: "Ajedrez",            label: "♟️ Ajedrez" },
];

const DIAS_SEMANA = ["lunes", "martes", "miercoles", "jueves", "viernes"] as const;
type DiaSemanaKey = typeof DIAS_SEMANA[number];
const DIA_LABEL: Record<DiaSemanaKey, string> = {
  lunes: "Lunes", martes: "Martes", miercoles: "Miércoles",
  jueves: "Jueves", viernes: "Viernes",
};
const DIA_EMOJI: Record<DiaSemanaKey, string> = {
  lunes: "🟦", martes: "🟩", miercoles: "🟨", jueves: "🟧", viernes: "🟥",
};

function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
}

function getTodayDate() {
  const d = new Date();
  return `${String(d.getDate()).padStart(2,"0")}/${String(d.getMonth()+1).padStart(2,"0")}/${d.getFullYear()}`;
}

function getLunesDeEstaSemana(): string {
  const d = new Date();
  const day = d.getDay();
  const diff = day === 0 ? -6 : 1 - day;
  d.setDate(d.getDate() + diff);
  return `${String(d.getDate()).padStart(2,"0")}/${String(d.getMonth()+1).padStart(2,"0")}/${d.getFullYear()}`;
}

function getViernesDeEstaSemana(): string {
  const d = new Date();
  const day = d.getDay();
  const diff = day === 0 ? -2 : 5 - day;
  d.setDate(d.getDate() + diff);
  return `${String(d.getDate()).padStart(2,"0")}/${String(d.getMonth()+1).padStart(2,"0")}/${d.getFullYear()}`;
}

function makeHora(): HoraSemanal {
  return {
    id: generateId(),
    codigoDestreza: "",
    destreza: null,
    tema: "",
    temasAlternativos: [],
    temaSeleccionado: null,
    habilidadesSocioemocionales: [],
    usaEjesTransversales: false,
    insercionesCurriculares: [],
    usaCompetencias: false,
    competencias: [],
    metodologiasActivas: [],
    tecnicasEvaluacion: [],
    deporteEnfoque: "",
  };
}

function makeDia(activo = true): ConfiguracionDia {
  return { activo, cantidadHoras: 1, horas: [makeHora()] };
}

/** Una DCD es desagregable si su subnivel tiene grados y tiene indicador de evaluación. */
function esDesagregable(codigo: string): boolean {
  const d = buscarPorCodigo(codigo);
  if (!d) return false;
  if (!gradosDeSubnivel(d.subnivel)) return false;
  return resolverDcdConIndicador(codigo) != null;
}

/** Extrae el número del grado desde la etiqueta ("3ro EGB" → 3, "2do BGU" → 2). */
function gradoNumerico(grado: string): number | null {
  const m = grado.match(/\d+/);
  return m ? parseInt(m[0], 10) : null;
}

type Paso = "configuracion" | "generando" | "resultado";

type DiasState = Record<DiaSemanaKey, ConfiguracionDia>;

// ─── Componente principal ────────────────────────────────────
export default function PlanificarSemanalScreen() {
  const colors = useColors();
  const router = useRouter();
  const { addSemana } = usePlanificaciones();

  // ── Paso de flujo ──
  const [paso, setPaso] = useState<Paso>("configuracion");

  // ── Datos generales ──
  const [institucion, setInstitucion] = useState("");
  const [docente, setDocente] = useState("");
  const [subnivel, setSubnivel] = useState<number | null>(null); // 1-5
  const [asignatura, setAsignatura] = useState("");              // nombre del área
  const [selectedAreaCode, setSelectedAreaCode] = useState<string>("");
  const [grado, setGrado] = useState("");
  const [nivel, setNivel] = useState("");
  const [paralelo, setParalelo] = useState("");
  const [trimestre, setTrimestre] = useState("Primero");
  const [semanaInicio, setSemanaInicio] = useState(getLunesDeEstaSemana());
  const [semanaFin, setSemanaFin] = useState(getViernesDeEstaSemana());
  const [numeroUnidad, setNumeroUnidad] = useState("");
  const [tituloUnidad, setTituloUnidad] = useState("");
  const [objetivosUnidad, setObjetivosUnidad] = useState("");
  const [bloqueCAI, setBloqueCAI] = useState<number | null>(null);

  // ── Configuración por día ──
  const [dias, setDias] = useState<DiasState>({
    lunes: makeDia(true),
    martes: makeDia(true),
    miercoles: makeDia(true),
    jueves: makeDia(true),
    viernes: makeDia(true),
  });

  // ── Resultado generado ──
  const [diasConPlanes, setDiasConPlanes] = useState<Record<string, { horaIndex: number; plan: any }[]>>({});
  const [tabActivo, setTabActivo] = useState<DiaSemanaKey>("lunes");
  const [errorGeneral, setErrorGeneral] = useState<string | null>(null);

  // ── tRPC ──
  const generateWeekMutation = trpc.topics.generateWeekPlan.useMutation();
  const generateAiMutation = trpc.topics.generateAi.useMutation();

  // ─── Helpers para editar días/horas ───────────────────────

  const updateDia = useCallback((dia: DiaSemanaKey, update: Partial<ConfiguracionDia>) => {
    setDias(prev => ({ ...prev, [dia]: { ...prev[dia], ...update } }));
  }, []);

  const updateHora = useCallback((dia: DiaSemanaKey, horaId: string, update: Partial<HoraSemanal>) => {
    setDias(prev => ({
      ...prev,
      [dia]: {
        ...prev[dia],
        horas: prev[dia].horas.map(h => h.id === horaId ? { ...h, ...update } : h),
      },
    }));
  }, []);

  const setCantidadHoras = useCallback((dia: DiaSemanaKey, cantidad: 1 | 2 | 3) => {
    setDias(prev => {
      const current = prev[dia];
      let horas = [...current.horas];
      while (horas.length < cantidad) horas.push(makeHora());
      horas = horas.slice(0, cantidad);
      return { ...prev, [dia]: { ...current, cantidadHoras: cantidad, horas } };
    });
  }, []);

  const copiarAlSiguienteDia = useCallback((dia: DiaSemanaKey) => {
    const idx = DIAS_SEMANA.indexOf(dia);
    if (idx === DIAS_SEMANA.length - 1) return;
    const siguiente = DIAS_SEMANA[idx + 1];
    const origen = dias[dia];
    setDias(prev => ({
      ...prev,
      [siguiente]: {
        ...origen,
        horas: origen.horas.map(h => ({
          ...makeHora(),
          codigoDestreza: h.codigoDestreza,
          destreza: h.destreza,
          tema: h.tema,
          habilidadesSocioemocionales: [...h.habilidadesSocioemocionales],
          usaEjesTransversales: h.usaEjesTransversales,
          insercionesCurriculares: [...h.insercionesCurriculares],
          usaCompetencias: h.usaCompetencias,
          competencias: [...h.competencias],
          metodologiasActivas: [...h.metodologiasActivas],
          tecnicasEvaluacion: [...h.tecnicasEvaluacion],
        })),
      },
    }));
  }, [dias]);

  const toggleChipHora = useCallback((
    dia: DiaSemanaKey,
    horaId: string,
    field: "habilidadesSocioemocionales" | "insercionesCurriculares" | "competencias" | "metodologiasActivas" | "tecnicasEvaluacion",
    id: string
  ) => {
    setDias(prev => ({
      ...prev,
      [dia]: {
        ...prev[dia],
        horas: prev[dia].horas.map(h => {
          if (h.id !== horaId) return h;
          const current = h[field] as string[];
          return { ...h, [field]: current.includes(id) ? current.filter(x => x !== id) : [...current, id] };
        }),
      },
    }));
  }, []);

  const toggleBoolHora = useCallback((
    dia: DiaSemanaKey,
    horaId: string,
    field: "usaEjesTransversales" | "usaCompetencias"
  ) => {
    setDias(prev => ({
      ...prev,
      [dia]: {
        ...prev[dia],
        horas: prev[dia].horas.map(h =>
          h.id === horaId ? { ...h, [field]: !h[field] } : h
        ),
      },
    }));
  }, []);

  // ─── Selección de bloque curricular CAI ─────────────────
  const handleSelectBloqueCAI = useCallback((bloque: number) => {
    setBloqueCAI(bloque);
    setNumeroUnidad(String(bloque));
    setTituloUnidad(NOMBRES_BLOQUES_CAI[bloque] ?? "");
    const criterio = subnivel !== null ? (CRITERIOS_CAI[subnivel]?.[bloque] ?? "") : "";
    setObjetivosUnidad(criterio);
  }, [subnivel]);

  // ─── Sugerir temas para una hora ─────────────────────────

  const [loadingHoraId, setLoadingHoraId] = useState<string | null>(null);

  const sugerirTemas = useCallback(async (dia: DiaSemanaKey, horaId: string) => {
    const hora = dias[dia].horas.find(h => h.id === horaId);
    if (!hora?.destreza || !hora.tema.trim()) return;
    setLoadingHoraId(horaId);
    try {
      const result = await generateAiMutation.mutateAsync({
        codigoDestreza: hora.destreza.codigo,
        descripcionDestreza: hora.destreza.descripcion,
        area: hora.destreza.area,
        bloque: obtenerNombreBloque(hora.destreza.area, hora.destreza.bloque),
        subnivel: hora.destreza.subnivel,
        temaDocente: hora.tema.trim(),
        temasExistentes: [hora.tema.trim()],
      });
      if (result.success && result.temas.length > 0) {
        updateHora(dia, horaId, { temasAlternativos: result.temas as TemaSugerido[] });
      }
    } catch (err: any) {
      console.error("Error sugerirTemas:", err);
    } finally {
      setLoadingHoraId(null);
    }
  }, [dias, generateAiMutation, updateHora]);

  // ─── Generación semanal ───────────────────────────────────

  const handleGenerarSemana = async () => {
    if (!docente.trim()) {
      const msg = "Por favor ingresa el nombre del docente";
      Platform.OS === "web" ? alert(msg) : Alert.alert("", msg);
      return;
    }

    const inputDias: any[] = [];
    for (const dia of DIAS_SEMANA) {
      const config = dias[dia];
      if (!config.activo) continue;
      const horasValidas = config.horas.filter(h => h.destreza && h.tema.trim());
      if (horasValidas.length === 0) continue;
      inputDias.push({
        dia,
        horas: horasValidas.map((h, i) => ({
          horaIndex: i,
          codigoDestreza: h.destreza!.codigo,
          descripcionDestreza: h.destreza!.descripcion,
          area: h.destreza!.area,
          bloque: obtenerNombreBloque(h.destreza!.area, h.destreza!.bloque),
          subnivel: h.destreza!.subnivel,
          tema: h.temaSeleccionado?.titulo || h.tema,
          ejesTransversales: h.usaEjesTransversales ? h.insercionesCurriculares : [],
          competencias: h.usaCompetencias ? h.competencias : [],
          metodologias: h.metodologiasActivas,
          deporteEnfoque: h.destreza?.area === "EF" && h.deporteEnfoque ? h.deporteEnfoque : undefined,
          indicadoresEvaluacion: h.destreza!.indicadoresEvaluacion ?? [],
          criteriosEvaluacion: h.destreza!.criteriosEvaluacion ?? [],
        })),
      });
    }

    if (inputDias.length === 0) {
      const msg = "Activa al menos un día con destreza y tema";
      Platform.OS === "web" ? alert(msg) : Alert.alert("", msg);
      return;
    }

    setPaso("generando");
    setErrorGeneral(null);

    try {
      const result = await generateWeekMutation.mutateAsync({ dias: inputDias });
      if (result.success) {
        setDiasConPlanes(result.diasConPlanes as any);
        // Activar primer día activo
        const primerDiaActivo = DIAS_SEMANA.find(d => dias[d].activo && (result.diasConPlanes[d]?.length ?? 0) > 0);
        if (primerDiaActivo) setTabActivo(primerDiaActivo);
        setPaso("resultado");
      } else {
        setErrorGeneral((result as any).error || "Error al generar");
        setPaso("configuracion");
      }
    } catch (err: any) {
      setErrorGeneral(err.message || "Error inesperado");
      setPaso("configuracion");
    }
  };

  const regenerarHora = async (dia: DiaSemanaKey, horaIndex: number) => {
    const config = dias[dia];
    const hora = config.horas[horaIndex];
    if (!hora?.destreza) return;
    try {
      const result = await generateWeekMutation.mutateAsync({
        dias: [{
          dia,
          horas: [{
            horaIndex,
            codigoDestreza: hora.destreza.codigo,
            descripcionDestreza: hora.destreza.descripcion,
            area: hora.destreza.area,
            bloque: obtenerNombreBloque(hora.destreza.area, hora.destreza.bloque),
            subnivel: hora.destreza.subnivel,
            tema: hora.temaSeleccionado?.titulo || hora.tema,
            ejesTransversales: hora.usaEjesTransversales ? hora.insercionesCurriculares : [],
            competencias: hora.usaCompetencias ? hora.competencias : [],
            metodologias: hora.metodologiasActivas,
            indicadoresEvaluacion: hora.destreza!.indicadoresEvaluacion ?? [],
            criteriosEvaluacion: hora.destreza!.criteriosEvaluacion ?? [],
          }],
        }],
      });
      if (result.success && result.diasConPlanes[dia]) {
        setDiasConPlanes(prev => ({
          ...prev,
          [dia]: (prev[dia] || []).map(h =>
            h.horaIndex === horaIndex
              ? { ...h, plan: result.diasConPlanes[dia][0]?.plan }
              : h
          ),
        }));
      }
    } catch (err: any) {
      console.error("Error regenerarHora:", err);
    }
  };

  const buildSemana = (): PlanificacionSemanal => {
    const now = new Date().toISOString();
    const mapDia = (diaKey: DiaSemanaKey) => ({
      ...dias[diaKey],
      horas: dias[diaKey].horas.map((h, i) => ({
        ...h,
        temaSeleccionado: diasConPlanes[diaKey]?.[i] ? {
          id: h.temaSeleccionado?.id || generateId(),
          titulo: h.temaSeleccionado?.titulo || h.tema,
          descripcionBreve: "",
          objetivoClase: diasConPlanes[diaKey][i]?.plan?.objetivoClase || "",
          estructura: diasConPlanes[diaKey][i]?.plan?.estructura,
          recursos: diasConPlanes[diaKey][i]?.plan?.recursos || [],
          evaluacionFormativa: diasConPlanes[diaKey][i]?.plan?.evaluacionFormativa || "",
          evaluacionEstructurada: diasConPlanes[diaKey][i]?.plan?.evaluacionEstructurada ?? undefined,
          rubricaSemanal: diasConPlanes[diaKey][i]?.plan?.rubricaSemanal ?? undefined,
        } : h.temaSeleccionado,
      })),
    });
    return {
      id: generateId(),
      fecha: getTodayDate(),
      semanaInicio,
      semanaFin,
      institucion,
      docente,
      asignatura,
      subnivel: subnivel !== null ? SUBNIVEL_NAMES[subnivel as keyof typeof SUBNIVEL_NAMES] : "",
      grado,
      nivel,
      paralelo,
      periodoPedagogico: "",
      trimestre,
      periodos: "1",
      numeroUnidad,
      tituloUnidad,
      objetivosUnidad,
      bloqueCAI: bloqueCAI ?? undefined,
      duaRepresentacion: "",
      duaAccionExpresion: "",
      duaImplicacion: "",
      pctVisual: "",
      pctAuditivo: "",
      pctLectorEscritor: "",
      pctKinestesico: "",
      dias: {
        lunes: mapDia("lunes"),
        martes: mapDia("martes"),
        miercoles: mapDia("miercoles"),
        jueves: mapDia("jueves"),
        viernes: mapDia("viernes"),
      },
      createdAt: now,
      updatedAt: now,
    };
  };

  const handleGuardar = async () => {
    const semana = buildSemana();
    await addSemana(semana);
    router.replace(`/ver-semana/${semana.id}` as any);
  };

  const handleGuardarParaAdaptacion = async () => {
    const semana = buildSemana();
    await addSemana(semana);
    router.replace({ pathname: "/adaptacion-curricular", params: { semanaId: semana.id } });
  };

  // ─── RENDER ───────────────────────────────────────────────

  if (paso === "generando") {
    return (
      <ScreenContainer edges={["top","bottom","left","right"]} className="flex-1">
        <View style={{ flex: 1, justifyContent: "center", alignItems: "center", padding: 32 }}>
          <ActivityIndicator size="large" color="#003366" />
          <Text style={{ fontSize: 18, fontWeight: "700", color: colors.foreground, marginTop: 24, textAlign: "center" }}>
            Generando planificación semanal...
          </Text>
          <Text style={{ fontSize: 14, color: colors.muted, marginTop: 8, textAlign: "center" }}>
            La IA está trabajando en paralelo para cada hora de clase.{"\n"}Esto puede tomar entre 15 y 40 segundos.
          </Text>
        </View>
      </ScreenContainer>
    );
  }

  if (paso === "resultado") {
    return <ResultadoView
      colors={colors}
      dias={dias}
      diasConPlanes={diasConPlanes}
      tabActivo={tabActivo}
      setTabActivo={setTabActivo}
      onRegenerarHora={regenerarHora}
      onGuardar={handleGuardar}
      onGuardarParaAdaptacion={handleGuardarParaAdaptacion}
      onVolver={() => setPaso("configuracion")}
      isGuardando={false}
    />;
  }

  // ── PASO CONFIGURACIÓN ──────────────────────────────────
  return (
    <ScreenContainer edges={["top","bottom","left","right"]} className="flex-1">
      <ScrollView contentContainerStyle={{ paddingBottom: 60 }}>
        {/* Header */}
        <View className="px-5 pt-4 pb-2">
          <Pressable onPress={() => router.back()} style={({ pressed }) => [styles.backBtn, { opacity: pressed ? 0.6 : 1 }]}>
            <Text style={{ fontSize: 18 }}>{"←"}</Text>
            <Text style={{ color: colors.primary, fontSize: 16, marginLeft: 6 }}>Atrás</Text>
          </Pressable>
          <Text style={[styles.pageTitle, { color: colors.foreground }]}>Planificación Semanal</Text>
          <Text style={{ color: colors.muted, fontSize: 13, marginTop: 2 }}>2026 - 2027 · 5 días de clase</Text>
        </View>

        {errorGeneral && (
          <View style={styles.errorBanner}>
            <Text style={{ color: "#DC2626", fontSize: 13 }}>{"⚠️"} {errorGeneral}</Text>
          </View>
        )}

        {/* ── SECCIÓN 1: Datos informativos ── */}
        <SectionHeader title="1. Datos Informativos" emoji="ℹ️" colors={colors} />
        <View style={[styles.sectionBody, { backgroundColor: colors.surface, borderColor: colors.border, marginHorizontal: 20 }]}>
          <FieldLabel label="Institución Educativa" colors={colors} />
          <TextInput style={[styles.input, { color: colors.foreground, borderColor: colors.border }]}
            value={institucion} onChangeText={setInstitucion} placeholder="Nombre de la institución"
            placeholderTextColor={colors.muted} />

          <FieldLabel label="Nombre Docente *" colors={colors} />
          <TextInput style={[styles.input, { color: colors.foreground, borderColor: colors.border }]}
            value={docente} onChangeText={setDocente} placeholder="Nombre completo"
            placeholderTextColor={colors.muted} />

          {/* Subnivel */}
          <FieldLabel label="Subnivel" colors={colors} />
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 4 }}>
            {([2, 3, 4, 5] as const).map(n => {
              const name = SUBNIVEL_NAMES[n];
              const active = subnivel === n;
              return (
                <Pressable key={n} onPress={() => {
                  setSubnivel(n);
                  setNivel(n <= 4 ? "EGB" : "BGU");
                  setGrado("");
                  setAsignatura("");
                  setSelectedAreaCode("");
                }}
                  style={[styles.trimestreBtn, {
                    borderColor: active ? "#003366" : colors.border,
                    backgroundColor: active ? "#003366" : colors.surface,
                  }]}>
                  <Text style={{ color: active ? "#fff" : colors.foreground, fontSize: 12, fontWeight: "600" }}>{name}</Text>
                </Pressable>
              );
            })}
          </View>

          {/* Asignatura — chips según subnivel */}
          {subnivel !== null && (
            <>
              <FieldLabel label="Asignatura" colors={colors} />
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 4 }}>
                {(subnivel === 5
                  ? (["CN.B","CN.Q","CN.F","CS.H","CS.F","CS.EC","EFL","EG","CAI"] as const)
                  : (["M","LL","CN","CS","EF","ECA","EFL","CAI"] as const)
                ).map(code => {
                  const info = AREAS_INFO[code];
                  const active = selectedAreaCode === code;
                  return (
                    <Pressable key={code} onPress={() => {
                      if (active) { setAsignatura(""); setSelectedAreaCode(""); }
                      else { setAsignatura(info.name); setSelectedAreaCode(code); }
                    }}
                      style={[styles.trimestreBtn, {
                        borderColor: active ? info.color : colors.border,
                        backgroundColor: active ? info.color + "20" : colors.surface,
                        paddingHorizontal: 12,
                      }]}>
                      <Text style={{ color: active ? info.color : colors.foreground, fontSize: 12, fontWeight: active ? "700" : "500" }}>
                        {info.emoji} {info.name}
                      </Text>
                    </Pressable>
                  );
                })}
              </View>
            </>
          )}

          {/* Grado — chips según subnivel */}
          {subnivel !== null && (
            <>
              <FieldLabel label="Grado" colors={colors} />
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 4 }}>
                {(subnivel === 2 ? ["2do EGB","3ro EGB","4to EGB"]
                  : subnivel === 3 ? ["5to EGB","6to EGB","7mo EGB"]
                  : subnivel === 4 ? ["8vo EGB","9no EGB","10mo EGB"]
                  : ["1ro BGU","2do BGU","3ro BGU"]
                ).map(g => {
                  const active = grado === g;
                  return (
                    <Pressable key={g} onPress={() => setGrado(active ? "" : g)}
                      style={[styles.trimestreBtn, {
                        borderColor: active ? "#003366" : colors.border,
                        backgroundColor: active ? "#003366" : colors.surface,
                      }]}>
                      <Text style={{ color: active ? "#fff" : colors.foreground, fontSize: 12, fontWeight: "600" }}>{g}</Text>
                    </Pressable>
                  );
                })}
              </View>
            </>
          )}

          {/* Paralelo */}
          <FieldLabel label="Paralelo" colors={colors} />
          <View style={{ flexDirection: "row", gap: 8, flexWrap: "wrap", marginBottom: 4 }}>
            {["A","B","C","D","E"].map(p => {
              const active = paralelo === p;
              return (
                <Pressable key={p} onPress={() => setParalelo(active ? "" : p)}
                  style={[styles.trimestreBtn, {
                    borderColor: active ? "#003366" : colors.border,
                    backgroundColor: active ? "#003366" : colors.surface,
                    minWidth: 44,
                  }]}>
                  <Text style={{ color: active ? "#fff" : colors.foreground, fontSize: 13, fontWeight: "700", textAlign: "center" }}>{p}</Text>
                </Pressable>
              );
            })}
          </View>

          <FieldLabel label="Trimestre" colors={colors} />
          <View style={{ flexDirection: "row", gap: 8 }}>
            {["Primero", "Segundo", "Tercero"].map(t => (
              <Pressable key={t} onPress={() => setTrimestre(t)}
                style={[styles.trimestreBtn, { borderColor: trimestre === t ? "#003366" : colors.border, backgroundColor: trimestre === t ? "#003366" : colors.surface }]}>
                <Text style={{ color: trimestre === t ? "#fff" : colors.foreground, fontSize: 12, fontWeight: "600" }}>{t}</Text>
              </Pressable>
            ))}
          </View>

          <View style={{ flexDirection: "row", gap: 8, marginTop: 8 }}>
            <View style={{ flex: 1 }}>
              <FieldLabel label="Semana inicio" colors={colors} />
              <TextInput style={[styles.input, { color: colors.foreground, borderColor: colors.border }]}
                value={semanaInicio} onChangeText={setSemanaInicio} placeholder="DD/MM/AAAA"
                placeholderTextColor={colors.muted} />
            </View>
            <View style={{ flex: 1 }}>
              <FieldLabel label="Semana fin" colors={colors} />
              <TextInput style={[styles.input, { color: colors.foreground, borderColor: colors.border }]}
                value={semanaFin} onChangeText={setSemanaFin} placeholder="DD/MM/AAAA"
                placeholderTextColor={colors.muted} />
            </View>
          </View>

          {selectedAreaCode === "CAI" ? (
            /* ── Bloque curricular CAI ── */
            <>
              {subnivel !== null && OBJETIVO_NIVEL_CAI[subnivel] ? (
                <View style={{ backgroundColor: colors.surface, borderRadius: 8, padding: 10, marginBottom: 8, borderLeftWidth: 3, borderLeftColor: "#7C3AED" }}>
                  <Text style={{ fontSize: 11, fontWeight: "700", color: "#7C3AED", marginBottom: 2 }}>OBJETIVO DEL NIVEL</Text>
                  <Text style={{ fontSize: 12, color: colors.foreground, lineHeight: 17 }}>{OBJETIVO_NIVEL_CAI[subnivel]}</Text>
                </View>
              ) : null}
              <FieldLabel label="Bloque curricular" colors={colors} />
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 8 }}>
                {[1, 2, 3].map(n => {
                  const active = bloqueCAI === n;
                  return (
                    <Pressable
                      key={n}
                      onPress={() => handleSelectBloqueCAI(n)}
                      style={{
                        paddingHorizontal: 12, paddingVertical: 8, borderRadius: 8,
                        borderWidth: 1.5,
                        borderColor: active ? "#7C3AED" : colors.border,
                        backgroundColor: active ? "#7C3AED18" : "transparent",
                      }}
                    >
                      <Text style={{ fontWeight: "600", fontSize: 12, color: active ? "#7C3AED" : colors.muted }}>
                        Bloque {n}
                      </Text>
                      <Text style={{ fontSize: 11, color: active ? "#7C3AED" : colors.muted, marginTop: 2 }}>
                        {NOMBRES_BLOQUES_CAI[n]}
                      </Text>
                    </Pressable>
                  );
                })}
              </View>
              {bloqueCAI !== null && (
                <>
                  <FieldLabel label="Criterio de evaluación del bloque" colors={colors} />
                  <TextInput
                    style={[styles.inputSm, { color: colors.foreground, borderColor: colors.border }]}
                    value={objetivosUnidad}
                    onChangeText={setObjetivosUnidad}
                    placeholder="Criterio de evaluación del bloque..."
                    placeholderTextColor={colors.muted}
                    multiline
                    numberOfLines={3}
                  />
                </>
              )}
            </>
          ) : (
            /* ── Unidad de planificación (otras asignaturas) ── */
            <>
              <View style={{ flexDirection: "row", gap: 8, marginTop: 4 }}>
                <View style={{ width: 80 }}>
                  <FieldLabel label="N.º Unidad" colors={colors} />
                  <TextInput style={[styles.input, { color: colors.foreground, borderColor: colors.border }]}
                    value={numeroUnidad} onChangeText={setNumeroUnidad} placeholder="1"
                    placeholderTextColor={colors.muted} keyboardType="number-pad" />
                </View>
                <View style={{ flex: 1 }}>
                  <FieldLabel label="Título de unidad de planificación" colors={colors} />
                  <TextInput style={[styles.input, { color: colors.foreground, borderColor: colors.border }]}
                    value={tituloUnidad} onChangeText={setTituloUnidad} placeholder="Nombre de la unidad"
                    placeholderTextColor={colors.muted} />
                </View>
              </View>
              <FieldLabel label="Objetivos específicos de la unidad de planificación" colors={colors} />
              <TextInput style={[styles.inputSm, { color: colors.foreground, borderColor: colors.border }]}
                value={objetivosUnidad} onChangeText={setObjetivosUnidad}
                placeholder="Escribe los objetivos de la unidad..."
                placeholderTextColor={colors.muted} multiline numberOfLines={3} />
            </>
          )}
        </View>

        {/* ── SECCIÓN 2: Configuración por día ── */}
        <SectionHeader title="2. Configuración por Día" emoji="📅" colors={colors} />
        {DIAS_SEMANA.map((dia, diaIdx) => (
          <DiaConfigBlock
            key={dia}
            dia={dia}
            config={dias[dia]}
            colors={colors}
            isLast={diaIdx === DIAS_SEMANA.length - 1}
            areaCode={selectedAreaCode}
            subnivel={subnivel}
            gradoContexto={gradoNumerico(grado)}
            bloqueCAI={bloqueCAI}
            onToggleActivo={() => updateDia(dia, { activo: !dias[dia].activo })}
            onSetCantidadHoras={(n) => setCantidadHoras(dia, n)}
            onUpdateHora={(horaId, update) => updateHora(dia, horaId, update)}
            onSugerirTemas={(horaId) => sugerirTemas(dia, horaId)}
            loadingHoraId={loadingHoraId}
            onToggleChipHora={(horaId, field, id) => toggleChipHora(dia, horaId, field, id)}
            onToggleBoolHora={(horaId, field) => toggleBoolHora(dia, horaId, field)}
            onCopiarAlSiguiente={() => copiarAlSiguienteDia(dia)}
          />
        ))}

        {/* ── Botón generar ── */}
        <View style={{ marginHorizontal: 20, marginTop: 24 }}>
          <Pressable
            onPress={handleGenerarSemana}
            style={({ pressed }) => [styles.btnGenerar, { opacity: pressed ? 0.8 : 1 }]}
          >
            <Text style={{ fontSize: 20 }}>🚀</Text>
            <Text style={styles.btnGenerarText}>Generar Planificación Semanal</Text>
          </Pressable>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

// ─── Subcomponente: bloque de configuración de un día ────────

function DiaConfigBlock({
  dia, config, colors, isLast, areaCode, subnivel, gradoContexto, bloqueCAI,
  onToggleActivo, onSetCantidadHoras, onUpdateHora, onSugerirTemas,
  loadingHoraId, onToggleChipHora, onToggleBoolHora, onCopiarAlSiguiente,
}: {
  dia: DiaSemanaKey;
  config: ConfiguracionDia;
  colors: any;
  isLast: boolean;
  areaCode: string;
  subnivel: number | null;
  gradoContexto: number | null;
  bloqueCAI: number | null;
  onToggleActivo: () => void;
  onSetCantidadHoras: (n: 1 | 2 | 3) => void;
  onUpdateHora: (horaId: string, update: Partial<HoraSemanal>) => void;
  onSugerirTemas: (horaId: string) => void;
  loadingHoraId: string | null;
  onToggleChipHora: (horaId: string, field: "habilidadesSocioemocionales" | "insercionesCurriculares" | "competencias" | "metodologiasActivas" | "tecnicasEvaluacion", id: string) => void;
  onToggleBoolHora: (horaId: string, field: "usaEjesTransversales" | "usaCompetencias") => void;
  onCopiarAlSiguiente: () => void;
}) {
  const [expandido, setExpandido] = useState(true);

  return (
    <View style={[styles.diaBlock, { borderColor: colors.border, marginHorizontal: 20 }]}>
      {/* Header del día */}
      <Pressable onPress={() => setExpandido(e => !e)} style={styles.diaHeader}>
        <Text style={{ fontSize: 18 }}>{DIA_EMOJI[dia]}</Text>
        <Text style={[styles.diaTitulo, { color: colors.foreground }]}>{DIA_LABEL[dia]}</Text>
        <Switch value={config.activo} onValueChange={onToggleActivo}
          trackColor={{ false: "#ccc", true: "#003366" }} thumbColor="#fff" />
        <Text style={{ color: colors.muted, marginLeft: 8 }}>{expandido ? "▲" : "▼"}</Text>
      </Pressable>

      {expandido && config.activo && (
        <View style={{ paddingHorizontal: 14, paddingBottom: 14 }}>
          {/* Número de horas */}
          <Text style={[styles.fieldLabel, { color: colors.muted, marginBottom: 6 }]}>Número de horas:</Text>
          <View style={{ flexDirection: "row", gap: 8, marginBottom: 14 }}>
            {([1, 2, 3] as const).map(n => (
              <Pressable key={n} onPress={() => onSetCantidadHoras(n)}
                style={[styles.horaBtn, { borderColor: config.cantidadHoras === n ? "#003366" : colors.border, backgroundColor: config.cantidadHoras === n ? "#003366" : colors.surface }]}>
                <Text style={{ color: config.cantidadHoras === n ? "#fff" : colors.foreground, fontWeight: "700" }}>{n}</Text>
              </Pressable>
            ))}
          </View>

          {/* Horas */}
          {config.horas.map((hora, horaIdx) => (
            <HoraBlock key={hora.id} hora={hora} horaIdx={horaIdx} colors={colors}
              areaCode={areaCode} subnivel={subnivel} gradoContexto={gradoContexto} bloqueCAI={bloqueCAI}
              isLoadingIA={loadingHoraId === hora.id}
              onUpdate={(update) => onUpdateHora(hora.id, update)}
              onSugerirTemas={() => onSugerirTemas(hora.id)}
              onToggleChip={(field, id) => onToggleChipHora(hora.id, field, id)}
              onToggleBool={(field) => onToggleBoolHora(hora.id, field)} />
          ))}

          {/* Copiar al siguiente */}
          {!isLast && (
            <Pressable onPress={onCopiarAlSiguiente}
              style={({ pressed }) => [styles.btnCopiar, { borderColor: colors.border, opacity: pressed ? 0.7 : 1 }]}>
              <Text style={{ fontSize: 14 }}>📋</Text>
              <Text style={{ color: colors.foreground, fontSize: 13, marginLeft: 6 }}>Copiar configuración al siguiente día</Text>
            </Pressable>
          )}
        </View>
      )}

      {expandido && !config.activo && (
        <View style={{ padding: 16, alignItems: "center" }}>
          <Text style={{ color: colors.muted, fontSize: 13 }}>Día desactivado — no se generará planificación</Text>
        </View>
      )}
    </View>
  );
}

// ─── Subcomponente: una hora dentro de un día ────────────────

function HoraBlock({
  hora, horaIdx, colors, areaCode, subnivel, gradoContexto, bloqueCAI, isLoadingIA, onUpdate, onSugerirTemas, onToggleChip, onToggleBool,
}: {
  hora: HoraSemanal;
  horaIdx: number;
  colors: any;
  areaCode: string;
  subnivel: number | null;
  gradoContexto: number | null;
  bloqueCAI: number | null;
  isLoadingIA: boolean;
  onUpdate: (update: Partial<HoraSemanal>) => void;
  onSugerirTemas: () => void;
  onToggleChip: (field: "habilidadesSocioemocionales" | "insercionesCurriculares" | "competencias" | "metodologiasActivas" | "tecnicasEvaluacion", id: string) => void;
  onToggleBool: (field: "usaEjesTransversales" | "usaCompetencias") => void;
}) {
  const [busqueda, setBusqueda] = useState("");
  const [resultados, setResultados] = useState<Destreza[]>([]);
  const [buscando, setBuscando] = useState(false);
  const [showDCDModal, setShowDCDModal] = useState(false);
  /** Código de la DCD cuyo panel de desagregación está abierto (null = cerrado). */
  const [desagregacionCodigo, setDesagregacionCodigo] = useState<string | null>(null);
  // Pool de destrezas: filtra por área + subnivel; para CAI también por bloque si está seleccionado
  const buildPool = () => TODAS_LAS_DESTREZAS.filter(d => {
    if (d.area !== areaCode) return false;
    if (subnivel !== null && d.subnivel !== subnivel) return false;
    if (areaCode === "CAI" && bloqueCAI !== null && d.bloque !== bloqueCAI) return false;
    return true;
  });

  // Cuando cambia el área/bloque/subnivel, pre-carga las primeras destrezas
  useEffect(() => {
    if (areaCode) {
      const pool = buildPool();
      setBusqueda("");
      setResultados(pool.slice(0, 10));
      setBuscando(pool.length > 0);
    } else {
      setResultados([]);
      setBuscando(false);
    }
  }, [areaCode, subnivel, bloqueCAI]);

  const handleBuscarDestreza = (q: string) => {
    setBusqueda(q);
    if (areaCode) {
      const pool = buildPool();
      if (q.length < 2) {
        setResultados(pool.slice(0, 10));
        setBuscando(pool.length > 0);
      } else {
        const filtered = pool.filter(
          d => d.codigo.toUpperCase().includes(q.toUpperCase()) ||
               d.descripcion.toUpperCase().includes(q.toUpperCase())
        ).slice(0, 10);
        setResultados(filtered);
        setBuscando(filtered.length > 0);
      }
    } else {
      if (q.length < 2) { setResultados([]); setBuscando(false); return; }
      const found = buscarDestrezas(q).slice(0, 10);
      setResultados(found);
      setBuscando(found.length > 0);
    }
  };

  const handleSeleccionarDestreza = (d: Destreza) => {
    setBusqueda("");
    setResultados([]);
    setBuscando(false);
    setShowDCDModal(false);
    onUpdate({
      codigoDestreza: d.codigo,
      destreza: d,
      habilidadesSocioemocionales: d.habilidadesSocioemocionales ?? [],
    });
  };

  const abrirDCDModal = () => {
    setBusqueda("");
    if (areaCode) {
      const pool = buildPool();
      setResultados(pool.slice(0, 20));
      setBuscando(pool.length > 0);
    } else {
      setResultados([]);
      setBuscando(false);
    }
    setShowDCDModal(true);
  };

  const areaInfo = hora.destreza ? AREAS_INFO[hora.destreza.area] : null;
  const desagregable = hora.destreza != null && gradoContexto != null && esDesagregable(hora.destreza.codigo);
  const sufijoGrado = subnivel === 5 ? "BGU" : "EGB";

  return (
    <View style={[styles.horaBlock, { borderColor: colors.border }]}>
      <Text style={[styles.horaTitulo, { color: colors.foreground }]}>— Hora {horaIdx + 1} —</Text>

      {/* Búsqueda de destreza */}
      <Text style={[styles.fieldLabel, { color: colors.muted }]}>DCD (Destreza con Criterio de Desempeño)</Text>

      {/* Botón para abrir el picker */}
      <Pressable
        onPress={abrirDCDModal}
        style={({ pressed }) => [{
          borderWidth: 1,
          borderRadius: 8,
          padding: 10,
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
          opacity: pressed ? 0.7 : 1,
          borderColor: hora.destreza ? "#22C55E" : colors.border,
          backgroundColor: hora.destreza ? "#22C55E10" : colors.surface,
        }]}
      >
        {hora.destreza ? (
          <View style={{ flex: 1 }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
              <Text style={{ color: areaInfo?.color || colors.primary, fontWeight: "700", fontSize: 12 }}>{hora.destreza.codigo}</Text>
              <DestrezaIconos codigo={hora.destreza.codigo} size={15} />
            </View>
            <Text style={{ color: colors.foreground, fontSize: 12, marginTop: 2 }} numberOfLines={2}>{hora.destreza.descripcion}</Text>
          </View>
        ) : (
          <Text style={{ color: colors.muted, fontSize: 13 }}>🔍 Seleccionar DCD...</Text>
        )}
        <Text style={{ color: colors.muted, fontSize: 16, marginLeft: 8 }}>▼</Text>
      </Pressable>

      {/* Modal picker de DCDs */}
      <Modal visible={showDCDModal} transparent animationType="fade" onRequestClose={() => setShowDCDModal(false)}>
        <Pressable
          style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.45)", justifyContent: "center", alignItems: "center" }}
          onPress={() => setShowDCDModal(false)}
        >
          <Pressable
            style={{ width: "90%", maxWidth: 520, backgroundColor: colors.background, borderRadius: 14, padding: 16, maxHeight: "80%" }}
            onPress={() => {}}
          >
            <Text style={{ fontWeight: "700", fontSize: 14, color: colors.foreground, marginBottom: 10 }}>Seleccionar DCD</Text>
            <TextInput
              autoFocus
              style={[styles.input, { color: colors.foreground, borderColor: colors.border, marginBottom: 8 }]}
              value={busqueda}
              onChangeText={handleBuscarDestreza}
              placeholder="Busca por código o descripción... ej: M.4.1.1"
              placeholderTextColor={colors.muted}
            />
            <ScrollView keyboardShouldPersistTaps="handled" style={{ maxHeight: 360 }}>
              {resultados.map(d => {
                const ai = AREAS_INFO[d.area];
                return (
                  <Pressable
                    key={d.codigo}
                    onPress={() => handleSeleccionarDestreza(d)}
                    style={({ pressed }) => [styles.dropdownItem, { borderBottomColor: colors.border, opacity: pressed ? 0.7 : 1 }]}
                  >
                    <View style={{ minWidth: 70 }}>
                      <Text style={{ color: ai?.color || colors.primary, fontWeight: "700", fontSize: 12 }}>{d.codigo}</Text>
                      <DestrezaIconos codigo={d.codigo} size={13} style={{ marginTop: 3 }} />
                    </View>
                    <Text style={{ color: colors.foreground, fontSize: 12, flex: 1, marginLeft: 8 }}>{d.descripcion}</Text>
                  </Pressable>
                );
              })}
              {resultados.length === 0 && (
                <Text style={{ color: colors.muted, textAlign: "center", padding: 20, fontStyle: "italic" }}>
                  {busqueda.length < 2 ? "Escribe para buscar..." : "Sin resultados"}
                </Text>
              )}
            </ScrollView>
            <Pressable
              onPress={() => setShowDCDModal(false)}
              style={{ marginTop: 12, padding: 10, borderRadius: 8, backgroundColor: colors.border, alignItems: "center" }}
            >
              <Text style={{ color: colors.foreground, fontWeight: "600" }}>Cancelar</Text>
            </Pressable>
          </Pressable>
        </Pressable>
      </Modal>

      {/* Desagregación por grado (ruta opcional tras seleccionar una DCD) */}
      {desagregable && (
        <View style={{ marginTop: 8 }}>
          <Pressable
            onPress={() => setDesagregacionCodigo(hora.destreza!.codigo)}
            style={({ pressed }) => ({
              backgroundColor: "#7C3AED",
              borderRadius: 8,
              paddingHorizontal: 12,
              paddingVertical: 8,
              flexDirection: "row",
              alignItems: "center",
              gap: 6,
              opacity: pressed ? 0.8 : 1,
            })}
          >
            <Text style={{ fontSize: 13 }}>⚡</Text>
            <Text style={{ color: "#fff", fontSize: 12, fontWeight: "700", flex: 1 }}>
              {hora.descripcionEfectiva
                ? `Cambiar versión desagregada (${hora.destreza!.codigo})`
                : `Desagregar para ${gradoContexto}.º ${sufijoGrado}`}
            </Text>
          </Pressable>
          {hora.descripcionEfectiva && (
            <Pressable
              onPress={() => onUpdate({ descripcionEfectiva: undefined })}
              style={({ pressed }) => ({
                borderWidth: 1,
                borderColor: "#7C3AED",
                borderRadius: 8,
                paddingHorizontal: 12,
                paddingVertical: 8,
                marginTop: 6,
                opacity: pressed ? 0.7 : 1,
              })}
            >
              <Text style={{ color: "#7C3AED", fontSize: 11, fontWeight: "600" }}>
                ↩ Volver a DCD oficial
              </Text>
            </Pressable>
          )}
        </View>
      )}

      {desagregacionCodigo ? (
        <DcdDesagregacionPanel
          codigoDCD={desagregacionCodigo}
          gradoContexto={gradoContexto ?? undefined}
          visible={!!desagregacionCodigo}
          onClose={() => setDesagregacionCodigo(null)}
          onSeleccionar={(fila: DcdDesagregacion) => {
            onUpdate({ descripcionEfectiva: fila.dcdGraduada });
            setDesagregacionCodigo(null);
          }}
        />
      ) : null}

      {/* Deporte (solo EF) */}
      {hora.destreza?.area === "EF" && (
        <View style={{ marginTop: 10 }}>
          <Text style={[styles.fieldLabel, { color: colors.muted }]}>Deporte específico (opcional)</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} keyboardShouldPersistTaps="handled">
            <View style={{ flexDirection: "row", gap: 6, paddingVertical: 4 }}>
              {DEPORTES_EF.map((d) => {
                const sel = hora.deporteEnfoque === d.value;
                return (
                  <Pressable
                    key={d.value}
                    onPress={() => onUpdate({ deporteEnfoque: sel ? "" : d.value })}
                    style={[styles.chip, {
                      backgroundColor: sel ? "#003366" : colors.surface,
                      borderColor: sel ? "#003366" : colors.border,
                    }]}
                  >
                    <Text style={{ color: sel ? "#fff" : colors.foreground, fontSize: 12 }}>{d.label}</Text>
                  </Pressable>
                );
              })}
            </View>
          </ScrollView>
        </View>
      )}

      {/* Tema */}
      <Text style={[styles.fieldLabel, { color: colors.muted, marginTop: 10 }]}>Tema de la hora</Text>
      <TextInput
        style={[styles.input, { color: colors.foreground, borderColor: colors.border }]}
        value={hora.tema}
        onChangeText={(t) => onUpdate({ tema: t })}
        placeholder="Escribe el tema de esta hora..."
        placeholderTextColor={colors.muted}
      />

      {/* Botón sugerir */}
      {hora.destreza && hora.tema.trim().length > 2 && (
        <>
          <Pressable onPress={onSugerirTemas} disabled={isLoadingIA}
            style={({ pressed }) => [styles.btnSugerir, { opacity: isLoadingIA ? 0.6 : pressed ? 0.8 : 1 }]}>
            <Text style={{ fontSize: 14 }}>{isLoadingIA ? "⏳" : "✨"}</Text>
            <Text style={{ color: "#fff", fontSize: 13, fontWeight: "600", marginLeft: 6 }}>
              {isLoadingIA ? "Generando sugerencias..." : "Sugerir alternativas con IA"}
            </Text>
          </Pressable>
          {isLoadingIA && (
            <Text style={{ fontSize: 11, color: "#7C3AED", textAlign: "center", marginTop: 6 }}>
              Esto puede tomar entre 15 y 30 segundos...
            </Text>
          )}
        </>
      )}

      {/* Alternativas sugeridas */}
      {hora.temasAlternativos.length > 0 && (
        <View style={{ marginTop: 8 }}>
          <Text style={[styles.fieldLabel, { color: colors.muted }]}>Elige una alternativa:</Text>
          {hora.temasAlternativos.map((tema: any) => (
            <Pressable key={tema.id} onPress={() => onUpdate({ temaSeleccionado: tema, tema: tema.titulo })}
              style={({ pressed }) => [
                styles.altCard,
                {
                  backgroundColor: hora.temaSeleccionado?.id === tema.id ? "#003366" + "15" : colors.surface,
                  borderColor: hora.temaSeleccionado?.id === tema.id ? "#003366" : colors.border,
                  opacity: pressed ? 0.8 : 1,
                }
              ]}>
              <Text style={{ fontWeight: "700", fontSize: 13, color: colors.foreground }}>{tema.titulo}</Text>
              <Text style={{ fontSize: 12, color: colors.muted, marginTop: 2 }}>{tema.descripcionBreve}</Text>
            </Pressable>
          ))}
        </View>
      )}

      {/* Habilidades Socioemocionales */}
      <Text style={[styles.subSectionTitle, { color: colors.foreground }]}>Habilidades Socioemocionales</Text>
      <View style={styles.chipsWrap}>
        {(hora.destreza?.habilidadesSocioemocionales?.length
          ? HABILIDADES_SOCIOEMOCIONALES.filter(h => hora.destreza!.habilidadesSocioemocionales.includes(h.id))
          : HABILIDADES_SOCIOEMOCIONALES.filter(h => !h.caiOnly)
        ).map(h => (
          <ChipBtn key={h.id} label={`${h.emoji} ${h.nombre}`}
            selected={hora.habilidadesSocioemocionales.includes(h.id)}
            onPress={() => onToggleChip("habilidadesSocioemocionales", h.id)} colors={colors} />
        ))}
      </View>

      {/* Metodologías Activas */}
      <Text style={[styles.subSectionTitle, { color: colors.foreground }]}>Metodologías Activas</Text>
      <View style={styles.chipsWrap}>
        {METODOLOGIAS_ACTIVAS.map(m => (
          <ChipBtn key={m.id} label={m.nombre}
            selected={hora.metodologiasActivas.includes(m.id)}
            onPress={() => onToggleChip("metodologiasActivas", m.id)} colors={colors} />
        ))}
      </View>

      {/* Técnicas de Evaluación */}
      <Text style={[styles.subSectionTitle, { color: colors.foreground }]}>Técnicas de Evaluación</Text>
      <View style={styles.chipsWrap}>
        {TECNICAS_EVALUACION.map(t => (
          <ChipBtn key={t.id} label={t.nombre}
            selected={hora.tecnicasEvaluacion.includes(t.id)}
            onPress={() => onToggleChip("tecnicasEvaluacion", t.id)} colors={colors} />
        ))}
      </View>
    </View>
  );
}

// ─── Vista de resultado ──────────────────────────────────────

function ResultadoView({
  colors, dias, diasConPlanes, tabActivo, setTabActivo,
  onRegenerarHora, onGuardar, onGuardarParaAdaptacion, onVolver, isGuardando,
}: {
  colors: any;
  dias: DiasState;
  diasConPlanes: Record<string, { horaIndex: number; plan: any }[]>;
  tabActivo: DiaSemanaKey;
  setTabActivo: (d: DiaSemanaKey) => void;
  onRegenerarHora: (dia: DiaSemanaKey, horaIndex: number) => void;
  onGuardar: () => void;
  onGuardarParaAdaptacion: () => void;
  onVolver: () => void;
  isGuardando: boolean;
}) {
  const diasActivos = DIAS_SEMANA.filter(d => dias[d].activo && (diasConPlanes[d]?.length ?? 0) > 0);
  const [tabAdaptaciones, setTabAdaptaciones] = useState(false);

  return (
    <ScreenContainer edges={["top","bottom","left","right"]} className="flex-1">
      <View style={{ flex: 1 }}>
        {/* Header */}
        <View style={[styles.resultHeader, { borderBottomColor: colors.border }]}>
          <Pressable onPress={onVolver} style={{ padding: 8 }}>
            <Text style={{ color: colors.primary, fontSize: 15 }}>{"← Editar"}</Text>
          </Pressable>
          <Text style={[styles.resultTitle, { color: colors.foreground }]}>Planificación Semanal</Text>
          <Pressable onPress={onGuardar}
            style={({ pressed }) => [styles.btnGuardar, { opacity: pressed || isGuardando ? 0.7 : 1 }]}>
            {isGuardando
              ? <ActivityIndicator size="small" color="#fff" />
              : <Text style={{ color: "#fff", fontSize: 13, fontWeight: "700" }}>💾 Guardar</Text>}
          </Pressable>
        </View>

        {/* Tabs por día */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={[styles.tabsRow, { borderBottomColor: colors.border }]}>
          {diasActivos.map(d => (
            <Pressable key={d} onPress={() => { setTabActivo(d); setTabAdaptaciones(false); }}
              style={[styles.tab, { borderBottomColor: !tabAdaptaciones && tabActivo === d ? "#003366" : "transparent" }]}>
              <Text style={{ fontSize: 14 }}>{DIA_EMOJI[d]}</Text>
              <Text style={[styles.tabLabel, { color: !tabAdaptaciones && tabActivo === d ? "#003366" : colors.muted }]}>
                {DIA_LABEL[d]}
              </Text>
            </Pressable>
          ))}
          <Pressable onPress={() => setTabAdaptaciones(true)}
            style={[styles.tab, { borderBottomColor: tabAdaptaciones ? "#7B2D8B" : "transparent" }]}>
            <Text style={{ fontSize: 14 }}>♿</Text>
            <Text style={[styles.tabLabel, { color: tabAdaptaciones ? "#7B2D8B" : colors.muted }]}>ADAPT.</Text>
          </Pressable>
        </ScrollView>

        {/* Contenido adaptaciones */}
        {tabAdaptaciones && (
          <ScrollView contentContainerStyle={{ padding: 24, paddingBottom: 48, alignItems: "center" }}>
            <View style={{ width: "100%", maxWidth: 520 }}>
              <View style={{ backgroundColor: "#4A1942", borderRadius: 14, padding: 20, marginBottom: 20, alignItems: "center" }}>
                <Text style={{ fontSize: 36, marginBottom: 8 }}>♿</Text>
                <Text style={{ color: "#fff", fontSize: 16, fontWeight: "700", textAlign: "center", marginBottom: 6 }}>
                  Adaptaciones Curriculares
                </Text>
                <Text style={{ color: "#E9D5FF", fontSize: 13, textAlign: "center" }}>
                  Para agregar adaptaciones curriculares a esta planificación, primero guárdala. Los datos del contexto (institución, docente, grado) se pre-rellenarán automáticamente.
                </Text>
              </View>

              <Pressable
                onPress={onGuardarParaAdaptacion}
                style={({ pressed }) => ({
                  backgroundColor: pressed ? "#6B21A8" : "#7B2D8B",
                  borderRadius: 12, paddingVertical: 16,
                  alignItems: "center", marginBottom: 12,
                  opacity: isGuardando ? 0.7 : 1,
                })}
              >
                {isGuardando
                  ? <ActivityIndicator color="#fff" size="small" />
                  : <Text style={{ color: "#fff", fontWeight: "700", fontSize: 15 }}>
                      💾 Guardar y agregar adaptación
                    </Text>}
              </Pressable>

              <Pressable
                onPress={onGuardar}
                style={({ pressed }) => ({
                  backgroundColor: colors.surface, borderRadius: 12,
                  paddingVertical: 13, alignItems: "center",
                  borderWidth: 1, borderColor: colors.border,
                  opacity: pressed ? 0.7 : 1,
                })}
              >
                <Text style={{ color: colors.foreground, fontWeight: "600", fontSize: 14 }}>
                  💾 Solo guardar (sin adaptaciones)
                </Text>
              </Pressable>
            </View>
          </ScrollView>
        )}

        {/* Contenido del día activo */}
        {!tabAdaptaciones && (
        <ScrollView contentContainerStyle={{ paddingBottom: 40 }}>
          {(diasConPlanes[tabActivo] || []).sort((a, b) => a.horaIndex - b.horaIndex).map((item) => {
            const { horaIndex, plan } = item as any;
            const hora = dias[tabActivo]?.horas[horaIndex];
            if (!plan) {
              return (
                <View key={horaIndex} style={[styles.horaPlanCard, { borderColor: "#FCA5A5", backgroundColor: "#FEF2F2" }]}>
                  <View style={{ padding: 16, alignItems: "center", gap: 10 }}>
                    <Text style={{ fontSize: 24 }}>⚠️</Text>
                    <Text style={{ fontWeight: "700", color: "#DC2626", fontSize: 14 }}>
                      Error al generar Hora {horaIndex + 1}
                    </Text>
                    {item.error ? <Text style={{ color: "#DC2626", fontSize: 12, textAlign: "center" }}>{item.error}</Text> : null}
                    <Pressable onPress={() => onRegenerarHora(tabActivo, horaIndex)}
                      style={({ pressed }) => ({ backgroundColor: "#DC2626", paddingHorizontal: 16, paddingVertical: 8, borderRadius: 8, opacity: pressed ? 0.7 : 1 })}>
                      <Text style={{ color: "#fff", fontWeight: "600", fontSize: 13 }}>🔄 Reintentar</Text>
                    </Pressable>
                  </View>
                </View>
              );
            }
            return (
              <HoraPlanCard
                key={horaIndex}
                horaIndex={horaIndex}
                hora={hora}
                plan={plan}
                colors={colors}
                onRegenerar={() => onRegenerarHora(tabActivo, horaIndex)}
              />
            );
          })}
          {(!diasConPlanes[tabActivo] || diasConPlanes[tabActivo].length === 0) && (
            <View style={{ padding: 32, alignItems: "center" }}>
              <Text style={{ color: colors.muted }}>No hay planificación para este día</Text>
            </View>
          )}
        </ScrollView>
        )}
      </View>
    </ScreenContainer>
  );
}

// ─── Card de una hora planificada ────────────────────────────

function HoraPlanCard({ horaIndex, hora, plan, colors, onRegenerar }: {
  horaIndex: number;
  hora: HoraSemanal | undefined;
  plan: any;
  colors: any;
  onRegenerar: () => void;
}) {
  const areaInfo = hora?.destreza ? AREAS_INFO[hora.destreza.area] : null;

  return (
    <View style={[styles.horaPlanCard, { borderColor: colors.border, backgroundColor: colors.surface }]}>
      {/* Header de la hora */}
      <View style={[styles.horaPlanHeader, { backgroundColor: areaInfo?.color ? areaInfo.color + "12" : "#003366" + "10" }]}>
        <Text style={[styles.horaPlanTitle, { color: areaInfo?.color || "#003366" }]}>
          Hora {horaIndex + 1} — {hora?.destreza?.codigo || ""}
        </Text>
        <Text style={{ color: colors.muted, fontSize: 12 }} numberOfLines={1}>
          {hora?.temaSeleccionado?.titulo || hora?.tema || ""}
        </Text>
      </View>

      {/* Objetivo */}
      {plan.objetivoClase && (
        <View style={{ padding: 12, borderBottomWidth: 1, borderBottomColor: colors.border }}>
          <Text style={{ fontSize: 11, fontWeight: "700", color: "#003366", marginBottom: 3 }}>🎯 OBJETIVO DE APRENDIZAJE</Text>
          <Text style={{ fontSize: 13, color: colors.foreground, lineHeight: 18 }}>{plan.objetivoClase}</Text>
        </View>
      )}

      {/* ERCA */}
      {plan.estructura && (
        <View style={{ padding: 12 }}>
          {[
            { key: "experiencia", label: "EXPERIENCIA", emoji: "💡", color: "#2980B9" },
            { key: "reflexion", label: "REFLEXIÓN", emoji: "🤔", color: "#8E44AD" },
            { key: "conceptualizacion", label: "CONCEPTUALIZACIÓN", emoji: "📚", color: "#27AE60" },
            { key: "aplicacion", label: "APLICACIÓN", emoji: "✅", color: "#E67E22" },
          ].map(({ key, label, emoji, color }) => {
            const fase = plan.estructura[key];
            if (!fase) return null;
            return (
              <View key={key} style={[styles.faseSection, { borderLeftColor: color }]}>
                <View style={styles.faseHeaderRow}>
                  <Text style={{ fontSize: 14 }}>{emoji}</Text>
                  <Text style={[styles.faseName, { color }]}>{label}</Text>
                  <Text style={{ fontSize: 12, color: colors.muted }}>{fase.duracion}</Text>
                </View>
                {(fase.actividades || []).map((act: string, i: number) => {
                  const dua: DUAActividad = fase.duaActividades?.[i] || { representacion: false, accionExpresion: false, implicacion: false };
                  return (
                    <View key={i} style={styles.actRow}>
                      <View style={[styles.actNum, { backgroundColor: color + "18" }]}>
                        <Text style={{ color, fontSize: 11, fontWeight: "700" }}>{i + 1}</Text>
                      </View>
                      <Text style={{ flex: 1, fontSize: 12, color: colors.foreground, lineHeight: 17, marginLeft: 8 }}>{act}</Text>
                      <View style={styles.duaSquaresRow}>
                        <View style={[styles.duaMini, { backgroundColor: dua.representacion ? DUA_ROSADO : DUA_ROSADO + "35" }]} />
                        <View style={[styles.duaMini, { backgroundColor: dua.accionExpresion ? DUA_AZUL : DUA_AZUL + "35" }]} />
                        <View style={[styles.duaMini, { backgroundColor: dua.implicacion ? DUA_VERDE : DUA_VERDE + "35" }]} />
                      </View>
                    </View>
                  );
                })}
              </View>
            );
          })}
        </View>
      )}

      {/* Recursos */}
      {plan.recursos?.length > 0 && (
        <View style={[styles.planFooterSection, { borderTopColor: colors.border }]}>
          <Text style={styles.planFooterLabel}>📦 Recursos</Text>
          <Text style={{ fontSize: 12, color: colors.foreground }}>{plan.recursos.join(" · ")}</Text>
        </View>
      )}

      {/* Evaluación */}
      {(plan as any).evaluacionEstructurada ? (
        <View style={[styles.planFooterSection, { borderTopColor: colors.border }]}>
          <Text style={styles.planFooterLabel}>📊 Evaluación formativa</Text>
          {[
            ["Técnica", (plan as any).evaluacionEstructurada.tecnica],
            ["Instrumento", (plan as any).evaluacionEstructurada.instrumento],
            ["Evidencia", (plan as any).evaluacionEstructurada.evidencia],
            ["Criterio", (plan as any).evaluacionEstructurada.criterio],
          ].map(([label, value]) => value ? (
            <View key={label as string} style={{ flexDirection: "row", marginTop: 4 }}>
              <Text style={{ fontSize: 11, fontWeight: "700", color: "#003366", minWidth: 80 }}>{label as string}: </Text>
              <Text style={{ fontSize: 11, color: colors.foreground, flex: 1 }}>{value as string}</Text>
            </View>
          ) : null)}
        </View>
      ) : plan.evaluacionFormativa ? (
        <View style={[styles.planFooterSection, { borderTopColor: colors.border }]}>
          <Text style={styles.planFooterLabel}>📊 Evaluación formativa</Text>
          <Text style={{ fontSize: 12, color: colors.foreground }}>{plan.evaluacionFormativa}</Text>
        </View>
      ) : null}

      {/* DUA Legend */}
      <View style={[styles.duaLegend, { borderTopColor: colors.border }]}>
        <View style={styles.duaLegendItem}><View style={[styles.duaMini, { backgroundColor: DUA_ROSADO }]} /><Text style={styles.duaLegendTxt}>Representación</Text></View>
        <View style={styles.duaLegendItem}><View style={[styles.duaMini, { backgroundColor: DUA_AZUL }]} /><Text style={styles.duaLegendTxt}>Acción/Expresión</Text></View>
        <View style={styles.duaLegendItem}><View style={[styles.duaMini, { backgroundColor: DUA_VERDE }]} /><Text style={styles.duaLegendTxt}>Implicación</Text></View>
      </View>

      {/* Regenerar */}
      <View style={{ paddingHorizontal: 12, paddingBottom: 12 }}>
        <Pressable onPress={onRegenerar}
          style={({ pressed }) => [styles.btnRegenerar, { borderColor: colors.border, opacity: pressed ? 0.7 : 1 }]}>
          <Text style={{ fontSize: 13 }}>🔄</Text>
          <Text style={{ fontSize: 12, color: colors.foreground, marginLeft: 6 }}>Regenerar esta hora</Text>
        </Pressable>
      </View>
    </View>
  );
}

// ─── Helpers UI ───────────────────────────────────────────────

function SectionHeader({ title, emoji, colors }: { title: string; emoji: string; colors: any }) {
  return (
    <View style={[styles.sectionHeaderRow, { marginHorizontal: 20 }]}>
      <Text style={{ fontSize: 16 }}>{emoji}</Text>
      <Text style={[styles.sectionHeaderText, { color: colors.foreground }]}>{title}</Text>
    </View>
  );
}

function FieldLabel({ label, colors }: { label: string; colors: any }) {
  return <Text style={[styles.fieldLabel, { color: colors.muted }]}>{label}</Text>;
}

function ChipBtn({ label, selected, onPress, colors }: {
  label: string; selected: boolean; onPress: () => void; colors: any;
}) {
  return (
    <Pressable onPress={onPress}
      style={[styles.chip, { backgroundColor: selected ? "#003366" : colors.surface, borderColor: selected ? "#003366" : colors.border }]}>
      <Text style={{ color: selected ? "#fff" : colors.foreground, fontSize: 12 }}>{label}</Text>
    </Pressable>
  );
}

// ─── Estilos ──────────────────────────────────────────────────

const styles = StyleSheet.create({
  backBtn: { flexDirection: "row", alignItems: "center" },
  pageTitle: { fontSize: 22, fontWeight: "800", marginTop: 8 },
  errorBanner: { margin: 20, padding: 12, backgroundColor: "#FEE2E2", borderRadius: 8 },
  sectionHeaderRow: { flexDirection: "row", alignItems: "center", marginTop: 20, marginBottom: 8 },
  sectionHeaderText: { fontSize: 15, fontWeight: "700", marginLeft: 8 },
  sectionBody: { borderRadius: 12, padding: 16, borderWidth: 1, marginBottom: 4 },
  fieldLabel: { fontSize: 12, fontWeight: "600", marginBottom: 4, marginTop: 8 },
  input: { borderWidth: 1, borderRadius: 8, paddingHorizontal: 12, paddingVertical: 10, fontSize: 14, marginBottom: 4 },
  inputSm: { borderWidth: 1, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 8, fontSize: 13, marginTop: 4 },
  trimestreBtn: { flex: 1, paddingVertical: 8, borderRadius: 8, borderWidth: 1, alignItems: "center" },
  estiloRow: { flexDirection: "row", alignItems: "center", marginBottom: 8, gap: 6 },
  estiloLabel: { fontSize: 12, fontWeight: "600", width: 100 },
  estiloBarBg: { flex: 1, height: 10, borderRadius: 5, overflow: "hidden" },
  estiloBarFill: { height: "100%", borderRadius: 5 },
  pctInput: { width: 44, borderWidth: 1, borderRadius: 6, paddingHorizontal: 6, paddingVertical: 4, fontSize: 13, textAlign: "center" },
  diaBlock: { borderWidth: 1, borderRadius: 12, marginBottom: 12, overflow: "hidden" },
  diaHeader: { flexDirection: "row", alignItems: "center", padding: 14, gap: 8 },
  diaTitulo: { fontSize: 16, fontWeight: "700", flex: 1 },
  horaBtn: { width: 44, height: 36, borderRadius: 8, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  horaBlock: { borderWidth: 1, borderRadius: 10, padding: 12, marginBottom: 12 },
  horaTitulo: { fontSize: 13, fontWeight: "700", textAlign: "center", marginBottom: 10 },
  dropdownList: { borderWidth: 1, borderRadius: 8, marginBottom: 4, maxHeight: 220 },
  dropdownItem: { flexDirection: "row", alignItems: "center", padding: 10, borderBottomWidth: 1 },
  destrezaSelected: { borderWidth: 1, borderRadius: 8, padding: 10, marginTop: 6 },
  btnSugerir: { backgroundColor: "#7C3AED", flexDirection: "row", alignItems: "center", justifyContent: "center", padding: 10, borderRadius: 8, marginTop: 8 },
  altCard: { borderWidth: 1, borderRadius: 8, padding: 10, marginBottom: 6 },
  subSectionTitle: { fontSize: 13, fontWeight: "700", marginTop: 14, marginBottom: 6 },
  chipsWrap: { flexDirection: "row", flexWrap: "wrap", gap: 6 },
  chip: { borderWidth: 1, borderRadius: 16, paddingHorizontal: 10, paddingVertical: 5 },
  toggleRow: { flexDirection: "row", alignItems: "center", marginTop: 14, marginBottom: 6 },
  btnCopiar: { flexDirection: "row", alignItems: "center", borderWidth: 1, borderRadius: 8, padding: 10, marginTop: 14 },
  btnGenerar: { backgroundColor: "#003366", flexDirection: "row", alignItems: "center", justifyContent: "center", paddingVertical: 16, borderRadius: 12, gap: 10 },
  btnGenerarText: { color: "#fff", fontSize: 16, fontWeight: "700" },
  // Resultado
  resultHeader: { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 10, borderBottomWidth: 1 },
  resultTitle: { flex: 1, fontSize: 16, fontWeight: "700", textAlign: "center" },
  btnGuardar: { backgroundColor: "#003366", paddingHorizontal: 12, paddingVertical: 8, borderRadius: 8 },
  tabsRow: { borderBottomWidth: 1, height: 66, flexShrink: 0 },
  tab: { paddingHorizontal: 16, paddingVertical: 10, alignItems: "center", justifyContent: "center", borderBottomWidth: 2, height: 66 },
  tabLabel: { fontSize: 12, fontWeight: "600", marginTop: 2 },
  horaPlanCard: { margin: 16, marginBottom: 0, borderRadius: 12, borderWidth: 1, overflow: "hidden" },
  horaPlanHeader: { padding: 12 },
  horaPlanTitle: { fontSize: 14, fontWeight: "700" },
  faseSection: { borderLeftWidth: 3, paddingLeft: 10, marginBottom: 12 },
  faseHeaderRow: { flexDirection: "row", alignItems: "center", gap: 6, marginBottom: 6 },
  faseName: { fontSize: 12, fontWeight: "700", flex: 1 },
  actRow: { flexDirection: "row", alignItems: "flex-start", marginBottom: 5 },
  actNum: { width: 20, height: 20, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  duaSquaresRow: { flexDirection: "row", gap: 3, marginLeft: 6 },
  duaMini: { width: 11, height: 11, borderRadius: 2 },
  planFooterSection: { padding: 12, borderTopWidth: 1 },
  planFooterLabel: { fontSize: 11, fontWeight: "700", color: "#003366", marginBottom: 3 },
  duaLegend: { flexDirection: "row", padding: 10, borderTopWidth: 1, gap: 12, flexWrap: "wrap" },
  duaLegendItem: { flexDirection: "row", alignItems: "center", gap: 4 },
  duaLegendTxt: { fontSize: 10, color: "#666" },
  btnRegenerar: { flexDirection: "row", alignItems: "center", justifyContent: "center", borderWidth: 1, borderRadius: 8, padding: 8 },
});
// probe
// MARKER
