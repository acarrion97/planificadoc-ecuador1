import { useState, useMemo } from "react";
import {
  Text,
  View,
  ScrollView,
  TextInput,
  StyleSheet,
  Alert,
  Platform,
  KeyboardAvoidingView,
  ActivityIndicator,
} from "react-native";
import { Pressable } from "react-native";
import { useRouter, useLocalSearchParams } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { usePlanificaciones } from "@/lib/planificaciones-context";
import {
  buscarPorCodigo,
  AREAS_INFO,
  SUBNIVEL_NAMES,
  SUBNIVEL_GRADOS,
  obtenerNombreBloqueDestreza,
  Planificacion,
  DUAActividad,
  generarTextoDUA,
  TECNICAS_EVALUACION,
  ESTILOS_APRENDIZAJE,
  HABILIDADES_SOCIOEMOCIONALES,
} from "@/data";
import { useExportPdf } from "@/hooks/use-export-pdf";
import { useAccess } from "@/lib/access-control";
import { trpc } from "@/lib/trpc";

function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
}

function getTodayDate() {
  const d = new Date();
  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const yyyy = d.getFullYear();
  return `${dd}/${mm}/${yyyy}`;
}

type PasoFlujo = "configuracion" | "generando" | "formulario";

export default function PlanificarScreen() {
  const colors = useColors();
  const router = useRouter();
  const { codigo } = useLocalSearchParams<{ codigo: string }>();
  const { addPlanificacion } = usePlanificaciones();
  const { exportarPDF, isExporting } = useExportPdf();

  const destreza = buscarPorCodigo(codigo || "");
  const { hasAccess } = useAccess();

  // ===== PASO 1: ConfiguraciÃÂ³n =====
  const [paso, setPaso] = useState<PasoFlujo>("configuracion");
  const [temaDocente, setTemaDocente] = useState("");
  const [temasAlternativos, setTemasAlternativos] = useState<{ titulo: string; descripcion: string }[]>([]);
  const [generandoTemas, setGenerandoTemas] = useState(false);
  const [errorTemas, setErrorTemas] = useState<string | null>(null);

  // Selecciones
  const [tecnicasSeleccionadas, setTecnicasSeleccionadas] = useState<string[]>([]);
  const [estilosSeleccionados, setEstilosSeleccionados] = useState<string[]>([]);
  const [habilidadesSocioemocionales, setHabilidadesSocioemocionales] = useState<string[]>([]);

  // Nuevos campos formato oficial 2026-2027
  const [periodoPedagogico, setPeriodoPedagogico] = useState("");
  const [trimestre, setTrimestre] = useState("Primero");
  const [nivel, setNivel] = useState("");
  const [fechaInicio, setFechaInicio] = useState("");
  const [fechaFin, setFechaFin] = useState("");
  const [paralelo, setParalelo] = useState("");

  // Estilos de aprendizaje con porcentajes
  const [pctVisual, setPctVisual] = useState("25");
  const [pctAuditivo, setPctAuditivo] = useState("25");
  const [pctLectorEscritor, setPctLectorEscritor] = useState("25");
  const [pctKinestesico, setPctKinestesico] = useState("25");

  // ===== PASO 2: Resultado generado =====
  const [generandoPlan, setGenerandoPlan] = useState(false);
  const [errorPlan, setErrorPlan] = useState<string | null>(null);

  // Formulario
  const [institucion, setInstitucion] = useState("");
  const [docente, setDocente] = useState("");
  const [grado, setGrado] = useState(destreza ? SUBNIVEL_GRADOS[destreza.subnivel] : "");
  const [fecha, setFecha] = useState(getTodayDate());
  const [periodos, setPeriodos] = useState("1");
  const [objetivoAprendizaje, setObjetivoAprendizaje] = useState(destreza?.objetivos[0] || "");
  const [actividades, setActividades] = useState("");
  const [recursos, setRecursos] = useState("");
  const [evaluacion, setEvaluacion] = useState(destreza?.indicadoresEvaluacion[0] || "");
  const [tecnicas, setTecnicas] = useState("");
  const [observaciones, setObservaciones] = useState("");
  const [duaRepresentacion, setDuaRepresentacion] = useState("");
  const [duaAccionExpresion, setDuaAccionExpresion] = useState("");
  const [duaImplicacion, setDuaImplicacion] = useState("");

  // Estructura ERCA generada con DUA por actividad
  const [estructuraGenerada, setEstructuraGenerada] = useState<any>(null);
  const [temaFinal, setTemaFinal] = useState("");

  // Bloques curriculares del área
  const bloquesCurriculares = useMemo(() => {
    if (!destreza) return [];
    const areaInfo = AREAS_INFO[destreza.area];
    if (!areaInfo?.bloques) return [];
    return Object.entries(areaInfo.bloques).map(([key, name]) => ({
      id: key,
      nombre: name,
    }));
  }, [destreza]);

  // Nivel automÃÂ¡tico segÃÂºn subnivel
  useMemo(() => {
    if (destreza) {
      const subnivelName = SUBNIVEL_NAMES[destreza.subnivel];
      if (destreza.subnivel <= 4) {
        setNivel("Educación General Básica");
      } else {
        setNivel("Bachillerato General Unificado");
      }
    }
  }, [destreza]);

  // tRPC mutations
  const generateAiMutation = trpc.topics.generateAi.useMutation();
  const generatePlanMutation = trpc.topics.generatePlan.useMutation();

  if (!destreza) {
    return (
      <ScreenContainer edges={["top", "bottom", "left", "right"]} className="flex-1">
        <View className="flex-1 items-center justify-center px-5">
          <Text style={{ fontSize: 56 }}>{"⚠️"}</Text>
          <Text className="text-lg font-semibold text-foreground mt-4">
            Destreza no encontrada
          </Text>
          <Pressable
            onPress={() => router.back()}
            style={({ pressed }) => [
              styles.backBtnFull,
              { backgroundColor: colors.primary, opacity: pressed ? 0.8 : 1 },
            ]}
          >
            <Text style={{ color: "#fff", fontWeight: "600", fontSize: 16 }}>Volver</Text>
          </Pressable>
        </View>
      </ScreenContainer>
    );
  }

  const areaInfo = AREAS_INFO[destreza.area];
  const isEFL = destreza.area === "EFL";

  // ===== Generar 2 temas alternativos con IA =====
  const handleSugerirTemas = async () => {
    if (!temaDocente.trim()) {
      if (Platform.OS === "web") {
        alert(isEFL ? "Please enter your topic first" : "Por favor escribe tu tema primero");
      } else {
        Alert.alert("", isEFL ? "Please enter your topic first" : "Por favor escribe tu tema primero");
      }
      return;
    }
    setGenerandoTemas(true);
    setErrorTemas(null);
    try {
      const result = await generateAiMutation.mutateAsync({
        codigoDestreza: destreza.codigo,
        descripcionDestreza: destreza.descripcion,
        area: destreza.area,
        bloque: obtenerNombreBloqueDestreza(destreza),
        subnivel: destreza.subnivel,
        temaDocente: temaDocente.trim(),
        temasExistentes: [temaDocente.trim()],
      });
      if (result.success && result.temas.length > 0) {
        setTemasAlternativos(result.temas.map((t: any) => ({ titulo: t.titulo, descripcion: t.descripcionBreve })));
      } else {
        setErrorTemas(result.error || (isEFL ? "Could not generate suggestions" : "No se pudieron generar sugerencias"));
      }
    } catch (e: any) {
      setErrorTemas(isEFL ? "Connection error" : "Error de conexión");
    }
    setGenerandoTemas(false);
  };

  // ===== Generar planificaciÃÂ³n completa =====
  const handleGenerarPlanificacion = async (temaElegido?: string) => {
    const tema = temaElegido || temaDocente.trim();
    if (!tema) {
      if (Platform.OS === "web") {
        alert(isEFL ? "Please enter a topic" : "Por favor escribe un tema");
      } else {
        Alert.alert("", isEFL ? "Please enter a topic" : "Por favor escribe un tema");
      }
      return;
    }

    setTemaFinal(tema);
    setPaso("generando");
    setGenerandoPlan(true);
    setErrorPlan(null);

    try {
      const result = await generatePlanMutation.mutateAsync({
        codigoDestreza: destreza.codigo,
        descripcionDestreza: destreza.descripcion,
        area: destreza.area,
        bloque: obtenerNombreBloqueDestreza(destreza),
        subnivel: destreza.subnivel,
        tema,
      });

      if (result.success && result.plan) {
        const plan = result.plan;
        setObjetivoAprendizaje(plan.objetivoClase || destreza.objetivos[0] || "");
        setEstructuraGenerada(plan.estructura);
        setRecursos((plan.recursos || []).join(", "));
        setEvaluacion(plan.evaluacionFormativa || destreza.indicadoresEvaluacion[0] || "");

        // Construir texto de actividades
        const fases = ["experiencia", "reflexion", "conceptualizacion", "aplicacion"] as const;
        const labels = isEFL
          ? { experiencia: "EXPERIENCE", reflexion: "REFLECTION", conceptualizacion: "CONCEPTUALIZATION", aplicacion: "APPLICATION" }
          : { experiencia: "EXPERIENCIA", reflexion: "REFLEXIÓN", conceptualizacion: "CONCEPTUALIZACIÓN", aplicacion: "APLICACIÓN" };

        const actTexto = fases.map(f => {
          const data = plan.estructura[f];
          const header = `${labels[f]} (${data?.duracion || "10 minutos"})`;
          const acts = (data?.actividades || []).map((a: string, i: number) => `${i + 1}. ${a}`).join("\n");
          return `${header}\n${acts}`;
        }).join("\n\n");

        setActividades(actTexto);

        // DUA general text
        const textoDUA = generarTextoDUA(destreza.area);
        const partes = textoDUA.split("\n\n");
        if (partes.length >= 3) {
          setDuaRepresentacion(partes[0]);
          setDuaAccionExpresion(partes[1]);
          setDuaImplicacion(partes[2]);
        }

        // Técnicas sugeridas
        setTecnicas(isEFL
          ? "Technique: Direct observation\nInstrument: Checklist / Assessment rubric"
          : "Técnica: Observación directa\nInstrumento: Lista de cotejo / Rúbrica de evaluación");

        setPaso("formulario");
      } else {
        setErrorPlan(result.error || (isEFL ? "Error generating plan" : "Error al generar planificación"));
        setPaso("configuracion");
      }
    } catch (e: any) {
      setErrorPlan(isEFL ? "Connection error" : "Error de conexión. Intenta de nuevo.");
      setPaso("configuracion");
    }
    setGenerandoPlan(false);
  };

  // ===== Guardar =====
  const handleSave = async (irAAdaptacion = false) => {
    if (!docente.trim()) {
      if (Platform.OS === "web") {
        alert(isEFL ? "Please enter teacher name" : "Por favor ingresa el nombre del docente");
      } else {
        Alert.alert("", isEFL ? "Please enter teacher name" : "Por favor ingresa el nombre del docente");
      }
      return;
    }

    const plan: Planificacion = {
      id: generateId(),
      fecha,
      institucion: institucion.trim(),
      docente: docente.trim(),
      grado: grado.trim(),
      asignatura: areaInfo.name,
      periodos: periodos.trim(),
      periodoPedagogico: periodoPedagogico.trim() || undefined,
      trimestre: trimestre || undefined,
      nivel: nivel.trim() || undefined,
      fechaInicio: fechaInicio.trim() || undefined,
      fechaFin: fechaFin.trim() || undefined,
      paralelo: paralelo.trim() || undefined,
      habilidadesSocioemocionales: habilidadesSocioemocionales.length > 0 ? habilidadesSocioemocionales : undefined,
      estilosAprendizajePorcentaje: {
        visual: parseInt(pctVisual) || 25,
        auditivo: parseInt(pctAuditivo) || 25,
        lectorEscritor: parseInt(pctLectorEscritor) || 25,
        kinestesico: parseInt(pctKinestesico) || 25,
      },
      destreza,
      objetivoAprendizaje: objetivoAprendizaje.trim(),
      temaSeleccionado: temaFinal ? {
        id: generateId(),
        titulo: temaFinal,
        descripcionBreve: "",
        objetivoClase: objetivoAprendizaje.trim(),
        estructura: estructuraGenerada || {
          experiencia: { titulo: "Experiencia", duracion: "10 minutos", actividades: [] },
          reflexion: { titulo: "Reflexión", duracion: "10 minutos", actividades: [] },
          conceptualizacion: { titulo: "Conceptualización", duracion: "15 minutos", actividades: [] },
          aplicacion: { titulo: "Aplicación", duracion: "10 minutos", actividades: [] },
        },
        recursos: recursos.split(",").map(r => r.trim()).filter(Boolean),
        evaluacionFormativa: evaluacion.trim(),
      } : undefined,
      actividades: actividades.trim(),
      recursos: recursos.trim(),
      evaluacion: evaluacion.trim(),
      tecnicasInstrumentos: tecnicas.trim(),
      observaciones: observaciones.trim(),
      usaEjesTransversales: false,
      usaCompetencias: false,
      tecnicasEvaluacionSeleccionadas: tecnicasSeleccionadas.length > 0 ? tecnicasSeleccionadas : undefined,
      estilosAprendizaje: estilosSeleccionados.length > 0 ? estilosSeleccionados : undefined,
      dua: {
        representacion: duaRepresentacion.trim(),
        accionExpresion: duaAccionExpresion.trim(),
        implicacion: duaImplicacion.trim(),
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await addPlanificacion(plan);
    if (irAAdaptacion) {
      router.replace({ pathname: "/adaptacion-curricular", params: { planId: plan.id } });
    } else {
      router.replace(`/ver-plan/${plan.id}` as any);
    }
  };

  // ==========================================
  // PASO: Generando (loading)
  // ==========================================
  if (paso === "generando") {
    return (
      <ScreenContainer edges={["top", "bottom", "left", "right"]} className="flex-1">
        <View className="flex-1 items-center justify-center px-5">
          <ActivityIndicator size="large" color={colors.primary} />
          <Text className="text-lg font-semibold text-foreground mt-6 text-center">
            {isEFL ? "Generating your lesson plan..." : "Generando tu planificación..."}
          </Text>
          <Text className="text-sm text-muted mt-2 text-center">
            {isEFL ? "Using Marzano's Taxonomy and UDL principles" : "Usando Taxonomía de Marzano y principios DUA"}
          </Text>
        </View>
      </ScreenContainer>
    );
  }

  // ==========================================
  // PASO 1: ConfiguraciÃÂ³n (tema + toggles + datos oficiales)
  // ==========================================
  if (paso === "configuracion") {
    return (
      <ScreenContainer edges={["top", "bottom", "left", "right"]} className="flex-1">
        <ScrollView contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">
          <View className="px-5 pt-4">
            <Pressable
              onPress={() => router.back()}
              style={({ pressed }) => [styles.backButton, { opacity: pressed ? 0.6 : 1 }]}
            >
              <Text style={{ fontSize: 18 }}>{"←"}</Text>
              <Text style={{ color: colors.primary, fontSize: 16, marginLeft: 6 }}>
                {isEFL ? "Back" : "Atrás"}
              </Text>
            </Pressable>
          </View>

          {/* Destreza info */}
          <View className="px-5 mt-3">
            <View style={[styles.destrezaInfo, { backgroundColor: areaInfo.color + "10", borderColor: areaInfo.color + "30" }]}>
              <View style={styles.destrezaInfoHeader}>
                <Text style={[styles.destrezaCode, { color: areaInfo.color }]}>{destreza.codigo}</Text>
                <Text style={{ color: areaInfo.color, fontSize: 12, fontWeight: "500" }}>{areaInfo.name}</Text>
              </View>
              <Text className="text-sm text-foreground mt-2 leading-5">{destreza.descripcion}</Text>
            </View>
          </View>

          {/* Título del paso */}
          <View className="px-5 mt-5">
            <View style={styles.stepIndicator}>
              <View style={[styles.stepBadge, { backgroundColor: colors.primary }]}>
                <Text style={styles.stepBadgeText}>1</Text>
              </View>
              <Text className="text-xl font-bold text-foreground ml-3">
                {isEFL ? "Configure your lesson plan" : "Configura tu planificación"}
              </Text>
            </View>
          </View>

          {/* ===== DATOS INFORMATIVOS OFICIALES ===== */}
          <SectionTitle title={isEFL ? "General Information" : "1. Datos Informativos"} emoji={"ℹ️"} colors={colors} />

          <FormField label={isEFL ? "Educational Institution" : "Institución Educativa"} value={institucion} onChangeText={setInstitucion} placeholder={isEFL ? "Institution name" : "Unidad Educativa Fiscal..."} colors={colors} />
          <FormField label={isEFL ? "Teacher *" : "Nombre Docente *"} value={docente} onChangeText={setDocente} placeholder={isEFL ? "Teacher's name" : "Lic. ..."} colors={colors} />

          <View style={styles.row}>
            <View style={{ flex: 1 }}>
              <FormField label={isEFL ? "Grade / Level" : "Grado/Curso"} value={grado} onChangeText={setGrado} placeholder={isEFL ? "e.g.: 10th" : "Ej: 10mo"} colors={colors} />
            </View>
            <View style={{ flex: 1 }}>
              <FormField label={isEFL ? "Level" : "Nivel"} value={nivel} onChangeText={setNivel} placeholder="EGB / BGU" colors={colors} />
            </View>
          </View>

          <View style={styles.row}>
            <View style={{ flex: 1 }}>
              <FormField label={isEFL ? "Sublevel" : "Subnivel"} value={SUBNIVEL_NAMES[destreza.subnivel]} onChangeText={() => {}} placeholder="" colors={colors} />
            </View>
            <View style={{ flex: 1 }}>
              <FormField label={isEFL ? "Section" : "Paralelo"} value={paralelo} onChangeText={setParalelo} placeholder={isEFL ? "e.g.: A" : 'Ej: "A"'} colors={colors} />
            </View>
          </View>

          <FormField label={isEFL ? "Pedagogical Period" : "Período Pedagógico"} value={periodoPedagogico} onChangeText={setPeriodoPedagogico} placeholder={isEFL ? "e.g.: Civic Education" : "Ej: Cívica y Acompañamiento Integral en el Aula"} colors={colors} />

          {/* Trimestre selector */}
          <View className="px-5 mt-3">
            <Text className="text-sm font-medium text-muted mb-2">{isEFL ? "Quarter" : "Trimestre"}</Text>
            <View style={{ flexDirection: "row", gap: 8 }}>
              {["Primero", "Segundo", "Tercero"].map((t) => (
                <Pressable
                  key={t}
                  onPress={() => setTrimestre(t)}
                  style={({ pressed }) => [{
                    flex: 1, paddingVertical: 10, borderRadius: 10, alignItems: "center" as const,
                    borderWidth: 1.5,
                    borderColor: trimestre === t ? colors.primary : colors.border,
                    backgroundColor: trimestre === t ? colors.primary + "15" : colors.surface,
                    opacity: pressed ? 0.7 : 1,
                  }]}
                >
                  <Text style={{ fontSize: 13, fontWeight: trimestre === t ? "700" : "500", color: trimestre === t ? colors.primary : colors.foreground }}>
                    {t}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>

          <View style={styles.row}>
            <View style={{ flex: 1 }}>
              <FormField label={isEFL ? "Start Date" : "Fecha Inicio"} value={fechaInicio} onChangeText={setFechaInicio} placeholder="DD/MM/AAAA" colors={colors} />
            </View>
            <View style={{ flex: 1 }}>
              <FormField label={isEFL ? "End Date" : "Fecha Fin"} value={fechaFin} onChangeText={setFechaFin} placeholder="DD/MM/AAAA" colors={colors} />
            </View>
          </View>

          <FormField label={isEFL ? "Number of Periods" : "Número de Períodos"} value={periodos} onChangeText={setPeriodos} placeholder="1" keyboardType="numeric" colors={colors} />


          {/* ===== 2. PRINCIPIOS DUA ===== */}
          <SectionTitle title={isEFL ? "2. UDL Principles" : "2. Principios DUA"} emoji={"♿"} colors={colors} />
          <View className="px-5 mt-1">
            <View style={[styles.duaPrincipiosBox, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <View style={styles.duaPrincipioRow}>
                <Text className="text-xs text-foreground flex-1">
                  I. Proporcionar múltiples formas de representación: ¿qué?
                </Text>
                <View style={[styles.duaSquareLarge, { backgroundColor: "#EC4899" }]} />
              </View>
              <View style={styles.duaPrincipioRow}>
                <Text className="text-xs text-foreground flex-1">
                  II. Proporcionar múltiples formas de acción y expresión: ¿Cómo?
                </Text>
                <View style={[styles.duaSquareLarge, { backgroundColor: "#1E3A5F" }]} />
              </View>
              <View style={styles.duaPrincipioRow}>
                <Text className="text-xs text-foreground flex-1">
                  III. Proporcionar múltiples formas de implicación o participación: ¿Por qué?
                </Text>
                <View style={[styles.duaSquareLarge, { backgroundColor: "#22C55E" }]} />
              </View>
            </View>
          </View>

          {/* ===== 3. ESTILOS DE APRENDIZAJE ===== */}
          <SectionTitle title={isEFL ? "3. Learning Styles" : "3. Estilos de Aprendizaje"} emoji={"🧠"} colors={colors} />
          <View className="px-5 mt-1">
            <Text className="text-xs text-muted mb-2">
              {isEFL ? "Enter the percentage distribution for your class:" : "Ingresa la distribución porcentual de tu grado/curso:"}
            </Text>
            <View style={[styles.estilosGrid, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <View style={styles.estiloRow}>
                <Text className="text-xs text-foreground" style={{ width: 120 }}>{"👁️"} VISUAL:</Text>
                <TextInput
                  value={pctVisual}
                  onChangeText={setPctVisual}
                  keyboardType="numeric"
                  style={[styles.pctInput, { borderColor: colors.border, color: colors.foreground }]}
                />
                <Text className="text-xs text-muted">%</Text>
              </View>
              <View style={styles.estiloRow}>
                <Text className="text-xs text-foreground" style={{ width: 120 }}>{"👂"} AUDITIVO:</Text>
                <TextInput
                  value={pctAuditivo}
                  onChangeText={setPctAuditivo}
                  keyboardType="numeric"
                  style={[styles.pctInput, { borderColor: colors.border, color: colors.foreground }]}
                />
                <Text className="text-xs text-muted">%</Text>
              </View>
              <View style={styles.estiloRow}>
                <Text className="text-xs text-foreground" style={{ width: 120 }}>{"📚"} LECTOR-ESCRITOR:</Text>
                <TextInput
                  value={pctLectorEscritor}
                  onChangeText={setPctLectorEscritor}
                  keyboardType="numeric"
                  style={[styles.pctInput, { borderColor: colors.border, color: colors.foreground }]}
                />
                <Text className="text-xs text-muted">%</Text>
              </View>
              <View style={styles.estiloRow}>
                <Text className="text-xs text-foreground" style={{ width: 120 }}>{"🏃"} KINESTÉSICO:</Text>
                <TextInput
                  value={pctKinestesico}
                  onChangeText={setPctKinestesico}
                  keyboardType="numeric"
                  style={[styles.pctInput, { borderColor: colors.border, color: colors.foreground }]}
                />
                <Text className="text-xs text-muted">%</Text>
              </View>
            </View>
          </View>

          {/* ===== 4. HABILIDADES SOCIOEMOCIONALES ===== */}
          <SectionTitle title={isEFL ? "4. Socioemotional Skills" : "4. Habilidades Socioemocionales"} emoji={"💚"} colors={colors} />
          <View className="px-5 mt-1 mb-2">
            <Text className="text-xs text-muted mb-2">
              {isEFL ? "Select the associated socioemotional skills:" : "Selecciona las habilidades socioemocionales asociadas:"}
            </Text>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
              {HABILIDADES_SOCIOEMOCIONALES.map((hab) => {
                const isSelected = habilidadesSocioemocionales.includes(hab.id);
                return (
                  <Pressable
                    key={hab.id}
                    onPress={() => {
                      if (isSelected) {
                        setHabilidadesSocioemocionales(habilidadesSocioemocionales.filter(id => id !== hab.id));
                      } else {
                        setHabilidadesSocioemocionales([...habilidadesSocioemocionales, hab.id]);
                      }
                    }}
                    style={({ pressed }) => [{
                      paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20,
                      borderWidth: 1.5, borderColor: isSelected ? "#16A34A" : colors.border,
                      backgroundColor: isSelected ? "#16A34A15" : colors.surface,
                      opacity: pressed ? 0.7 : 1,
                    }]}
                  >
                    <Text style={{ fontSize: 12, fontWeight: isSelected ? "700" : "500", color: isSelected ? "#16A34A" : colors.foreground }}>
                      {hab.emoji} {isEFL ? hab.nameEN : hab.nombre}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
          </View>

          {/* ===== TEMA DEL DOCENTE ===== */}
          <SectionTitle title={isEFL ? "Your Topic" : "5. Tu Tema de Clase"} emoji={"📝"} colors={colors} />
          <View className="px-5 mt-2">
            <Text className="text-xs text-muted mb-2">
              {isEFL ? "Write the topic you want to teach:" : "Escribe el tema que deseas enseñar:"}
            </Text>
            <TextInput
              value={temaDocente}
              onChangeText={setTemaDocente}
              placeholder={isEFL ? "e.g.: Photosynthesis in tropical plants" : "Ej: La fotosíntesis en las plantas tropicales"}
              placeholderTextColor={colors.muted}
              style={[styles.input, { backgroundColor: colors.surface, borderColor: colors.border, color: colors.foreground }]}
              returnKeyType="done"
            />

            {/* Botón sugerir 2 temas con IA */}
            {hasAccess && (
              <Pressable
                onPress={handleSugerirTemas}
                disabled={generandoTemas}
                style={({ pressed }) => [
                  styles.aiButton,
                  {
                    backgroundColor: generandoTemas ? colors.surface : "#7C3AED",
                    opacity: pressed && !generandoTemas ? 0.85 : 1,
                    marginTop: 12,
                  },
                ]}
              >
                {generandoTemas ? (
                  <>
                    <ActivityIndicator size="small" color="#7C3AED" />
                    <Text style={{ color: colors.muted, fontSize: 14, fontWeight: "600", marginLeft: 10 }}>
                      {isEFL ? "Generating suggestions..." : "Generando sugerencias..."}
                    </Text>
                  </>
                ) : (
                  <>
                    <Text style={{ fontSize: 16 }}>{"✨"}</Text>
                    <Text style={{ color: "#fff", fontSize: 14, fontWeight: "700", marginLeft: 8 }}>
                      {isEFL ? "Suggest 2 alternatives with AI" : "Sugerir 2 alternativas con IA"}
                    </Text>
                  </>
                )}
              </Pressable>
            )}

            {errorTemas && (
              <Text style={{ color: colors.error, fontSize: 12, marginTop: 6 }}>{errorTemas}</Text>
            )}

            {/* Temas alternativos sugeridos */}
            {temasAlternativos.length > 0 && (
              <View style={{ marginTop: 12 }}>
                <Text className="text-xs text-muted mb-2">
                  {isEFL ? "AI Alternatives (tap to use):" : "Alternativas de IA (toca para usar):"}
                </Text>
                {temasAlternativos.map((t, i) => (
                  <Pressable
                    key={i}
                    onPress={() => setTemaDocente(t.titulo)}
                    style={({ pressed }) => [
                      styles.temaAlternativo,
                      { borderColor: colors.border, backgroundColor: pressed ? colors.primary + "10" : colors.surface },
                    ]}
                  >
                    <Text className="text-sm font-semibold text-foreground">{t.titulo}</Text>
                    {t.descripcion ? <Text className="text-xs text-muted mt-1">{t.descripcion}</Text> : null}
                  </Pressable>
                ))}
              </View>
            )}
          </View>

          {/* ===== TÉCNICAS DE EVALUACIÓN ===== */}
          <SectionTitle title={isEFL ? "Assessment Techniques" : "Técnicas de Evaluación"} emoji={"📋"} colors={colors} />
          <View className="px-5 mt-1 mb-2">
            <Text className="text-xs text-muted mb-2">
              {isEFL ? "Select assessment techniques:" : "Selecciona técnicas de evaluación:"}
            </Text>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
              {TECNICAS_EVALUACION.map((tec) => {
                const isSelected = tecnicasSeleccionadas.includes(tec.id);
                return (
                  <Pressable
                    key={tec.id}
                    onPress={() => {
                      if (isSelected) {
                        setTecnicasSeleccionadas(tecnicasSeleccionadas.filter(id => id !== tec.id));
                      } else {
                        setTecnicasSeleccionadas([...tecnicasSeleccionadas, tec.id]);
                      }
                    }}
                    style={({ pressed }) => [{
                      paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20,
                      borderWidth: 1.5, borderColor: isSelected ? "#16A34A" : colors.border,
                      backgroundColor: isSelected ? "#16A34A15" : colors.surface,
                      opacity: pressed ? 0.7 : 1,
                    }]}
                  >
                    <Text style={{ fontSize: 12, fontWeight: isSelected ? "700" : "500", color: isSelected ? "#16A34A" : colors.foreground }}>
                      {isEFL ? tec.nameEN : tec.nombre}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
          </View>

          {/* Error de generación */}
          {errorPlan && (
            <View className="px-5 mt-3">
              <Text style={{ color: colors.error, fontSize: 13, textAlign: "center" }}>{errorPlan}</Text>
            </View>
          )}

          {/* ===== BOTÓN GENERAR PLANIFICACIÓN ===== */}
          <View className="px-5 mt-6 mb-10">
            <Pressable
              onPress={() => handleGenerarPlanificacion()}
              style={({ pressed }) => [
                styles.generateBtn,
                { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1, transform: [{ scale: pressed ? 0.98 : 1 }] },
              ]}
            >
              <Text style={{ fontSize: 20 }}>{"🚀"}</Text>
              <Text style={styles.generateBtnText}>
                {isEFL ? "Generate Lesson Plan" : "Generar Planificación"}
              </Text>
            </Pressable>
            <Text className="text-xs text-muted text-center mt-3">
              {isEFL ? "AI will generate activities with Marzano verbs and UDL indicators" : "La IA generará actividades con verbos de Marzano e indicadores DUA"}
            </Text>
          </View>
        </ScrollView>
      </ScreenContainer>
    );
  }

  // ==========================================
  // PASO 2: Formulario de planificación (resultado)
  // ==========================================
  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]} className="flex-1">
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">
          <View className="px-5 pt-4">
            <Pressable
              onPress={() => setPaso("configuracion")}
              style={({ pressed }) => [styles.backButton, { opacity: pressed ? 0.6 : 1 }]}
            >
              <Text style={{ fontSize: 18 }}>{"←"}</Text>
              <Text style={{ color: colors.primary, fontSize: 16, marginLeft: 6 }}>
                {isEFL ? "Back to configuration" : "Volver a configuración"}
              </Text>
            </Pressable>

            <View style={styles.stepIndicator}>
              <View style={[styles.stepBadge, { backgroundColor: colors.primary }]}>
                <Text style={styles.stepBadgeText}>2</Text>
              </View>
              <Text className="text-xl font-bold text-foreground ml-3">
                {isEFL ? "Microcurricular Lesson Plan" : "Planificación Microcurricular"}
              </Text>
            </View>
          </View>

          {/* Tema badge */}
          {temaFinal && (
            <View className="px-5 mt-3">
              <View style={[styles.temaBadge, { backgroundColor: areaInfo.color + "12", borderColor: areaInfo.color + "35" }]}>
                <Text style={{ fontSize: 18 }}>{"✨"}</Text>
                <View style={{ flex: 1, marginLeft: 10 }}>
                  <Text style={{ color: areaInfo.color, fontSize: 13, fontWeight: "600" }}>
                    {isEFL ? "Topic" : "Tema"}
                  </Text>
                  <Text className="text-sm font-bold text-foreground mt-1">{temaFinal}</Text>
                </View>
              </View>
            </View>
          )}

          {/* Destreza compact */}
          <View className="px-5 mt-3">
            <View style={[styles.destrezaCompact, { backgroundColor: areaInfo.color + "08", borderColor: areaInfo.color + "20" }]}>
              <Text style={{ color: areaInfo.color, fontSize: 15, fontWeight: "800" }}>{destreza.codigo}</Text>
              <Text className="text-xs text-muted mt-1" numberOfLines={2}>{destreza.descripcion}</Text>
            </View>
          </View>

          <SectionTitle title={isEFL ? "Learning Objective" : "Objetivo de Aprendizaje"} emoji={"🎯"} colors={colors} />
          <FormField label={isEFL ? "Objective" : "Objetivo"} value={objetivoAprendizaje} onChangeText={setObjetivoAprendizaje} placeholder={isEFL ? "Learning objective" : "Objetivo de aprendizaje"} multiline colors={colors} />

          {/* Estructura ERCA con DUA squares */}
          {estructuraGenerada && (
            <>
              <SectionTitle title={isEFL ? "ERCA Structure (45 min)" : "Estructura ERCA (45 min)"} emoji={"🏫"} colors={colors} />
              <EstructuraERCAConDUA estructura={estructuraGenerada} colors={colors} areaColor={areaInfo.color} isEFL={isEFL} />
            </>
          )}

          <SectionTitle title={isEFL ? "Learning Activities" : "Actividades de Aprendizaje"} emoji={"📋"} colors={colors} />
          <FormField label={isEFL ? "Activities (editable)" : "Actividades (editable)"} value={actividades} onChangeText={setActividades} placeholder={isEFL ? "Describe the activities..." : "Describe las actividades..."} multiline colors={colors} />

          <SectionTitle title={isEFL ? "Teaching Resources" : "Recursos Didácticos"} emoji={"📦"} colors={colors} />
          <FormField label={isEFL ? "Resources" : "Recursos"} value={recursos} onChangeText={setRecursos} placeholder={isEFL ? "List of resources..." : "Lista de recursos..."} multiline colors={colors} />

          <SectionTitle title={isEFL ? "Assessment" : "Evaluación"} emoji={"📊"} colors={colors} />
          <FormField label={isEFL ? "Assessment Indicators" : "Indicadores de Evaluación"} value={evaluacion} onChangeText={setEvaluacion} placeholder={isEFL ? "Indicators..." : "Indicadores..."} multiline colors={colors} />
          <FormField label={isEFL ? "Techniques and Instruments" : "Técnicas e Instrumentos"} value={tecnicas} onChangeText={setTecnicas} placeholder={isEFL ? "Assessment techniques..." : "Técnicas de evaluación..."} multiline colors={colors} />

          {/* DUA General */}
          <SectionTitle title={isEFL ? "Universal Design for Learning (UDL)" : "Diseño Universal para el Aprendizaje (DUA)"} emoji={"♿"} colors={colors} />
          <View className="px-5 mt-1 mb-1">
            <View style={[styles.duaBanner, { backgroundColor: "#7C3AED10", borderColor: "#7C3AED30" }]}>
              <Text style={{ color: "#7C3AED", fontSize: 12, fontWeight: "600", textAlign: "center" }}>
                {isEFL ? "Curricular adaptations based on the 3 UDL principles" : "Adaptaciones curriculares basadas en los 3 principios del DUA"}
              </Text>
            </View>
          </View>
          <FormField label={isEFL ? "Representation" : "Representación"} value={duaRepresentacion} onChangeText={setDuaRepresentacion} placeholder={isEFL ? "How to present information..." : "Cómo presentar la información..."} multiline colors={colors} />
          <FormField label={isEFL ? "Action and Expression" : "Acción y Expresión"} value={duaAccionExpresion} onChangeText={setDuaAccionExpresion} placeholder={isEFL ? "How students demonstrate..." : "Cómo demostrarán lo aprendido..."} multiline colors={colors} />
          <FormField label={isEFL ? "Engagement" : "Implicación"} value={duaImplicacion} onChangeText={setDuaImplicacion} placeholder={isEFL ? "How to motivate..." : "Cómo motivar..."} multiline colors={colors} />

          <SectionTitle title={isEFL ? "Observations" : "Observaciones"} emoji={"📌"} colors={colors} />
          <FormField label={isEFL ? "Observations" : "Observaciones"} value={observaciones} onChangeText={setObservaciones} placeholder={isEFL ? "Additional observations (optional)" : "Observaciones adicionales (opcional)"} multiline colors={colors} />

          {/* Guardar */}
          <View className="px-5 mt-6 mb-10">
            <Pressable
              onPress={() => handleSave()}
              style={({ pressed }) => [styles.saveBtn, { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1, transform: [{ scale: pressed ? 0.98 : 1 }] }]}
            >
              <Text style={{ fontSize: 20 }}>{"💾"}</Text>
              <Text style={styles.saveBtnText}>{isEFL ? "Save Lesson Plan" : "Guardar Planificación"}</Text>
            </Pressable>
            <Pressable
              onPress={() => handleSave(true)}
              style={({ pressed }) => [styles.saveBtn, {
                backgroundColor: "#4A1942",
                opacity: pressed ? 0.85 : 1,
                transform: [{ scale: pressed ? 0.98 : 1 }],
                marginTop: 10,
              }]}
            >
              <Text style={{ fontSize: 20 }}>{"♿"}</Text>
              <Text style={styles.saveBtnText}>
                {isEFL ? "Save & Create Adaptation" : "Guardar y crear Adaptación Curricular"}
              </Text>
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

// ==========================================
// COMPONENTE: Estructura ERCA con DUA squares
// ==========================================
function EstructuraERCAConDUA({
  estructura,
  colors,
  areaColor,
  isEFL = false,
}: {
  estructura: any;
  colors: any;
  areaColor: string;
  isEFL?: boolean;
}) {
  const fases = [
    { key: "experiencia" as const, label: isEFL ? "Experience" : "Experiencia", color: "#2980B9", emoji: "💡" },
    { key: "reflexion" as const, label: isEFL ? "Reflection" : "Reflexión", color: "#8E44AD", emoji: "🤔" },
    { key: "conceptualizacion" as const, label: isEFL ? "Conceptualization" : "Conceptualización", color: "#27AE60", emoji: "📚" },
    { key: "aplicacion" as const, label: isEFL ? "Application" : "Aplicación", color: "#E67E22", emoji: "✅" },
  ];

  return (
    <View className="px-5 mt-2">
      {/* Leyenda DUA */}
      <View style={[styles.duaLegend, { borderColor: colors.border }]}>
        <Text className="text-xs font-semibold text-foreground mb-1">
          {isEFL ? "UDL Indicators:" : "Indicadores DUA:"}
        </Text>
        <View style={{ flexDirection: "row", gap: 12, flexWrap: "wrap" }}>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
            <View style={[styles.duaSquare, { backgroundColor: "#EC4899" }]} />
            <Text className="text-xs text-muted">{isEFL ? "Representation" : "Representación"}</Text>
          </View>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
            <View style={[styles.duaSquare, { backgroundColor: "#1E3A5F" }]} />
            <Text className="text-xs text-muted">{isEFL ? "Action & Expression" : "Acción y Expresión"}</Text>
          </View>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
            <View style={[styles.duaSquare, { backgroundColor: "#22C55E" }]} />
            <Text className="text-xs text-muted">{isEFL ? "Engagement" : "Implicación"}</Text>
          </View>
        </View>
      </View>

      {/* Duración total */}
      <View style={[styles.totalDurationBadge, { backgroundColor: areaColor + "10", borderColor: areaColor + "30" }]}>
        <Text style={{ fontSize: 14 }}>{"⏰"}</Text>
        <Text style={{ color: areaColor, fontSize: 13, fontWeight: "700", marginLeft: 6 }}>
          {isEFL ? "Total duration: 45 minutes" : "Duración total: 45 minutos"}
        </Text>
      </View>

      {fases.map((fase) => {
        const data = estructura[fase.key];
        if (!data) return null;
        const actividades: string[] = data.actividades || [];
        const duaActividades: DUAActividad[] = data.duaActividades || [];

        return (
          <View key={fase.key} style={[styles.faseCard, { borderLeftColor: fase.color, backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={styles.faseCardHeader}>
              <Text style={{ fontSize: 16 }}>{fase.emoji}</Text>
              <Text style={[styles.faseCardTitle, { color: fase.color }]}>{fase.label}</Text>
              <View style={[styles.durationBadge, { backgroundColor: fase.color + "18" }]}>
                <Text style={{ fontSize: 11 }}>{"⏰"}</Text>
                <Text style={{ color: fase.color, fontSize: 11, fontWeight: "600", marginLeft: 3 }}>{data.duracion}</Text>
              </View>
            </View>
            {actividades.map((act: string, idx: number) => {
              const dua = duaActividades[idx] || { implicacion: false, representacion: false, accionExpresion: false };
              // Limpiar texto: remover indicadores DUA del texto
              const cleanAct = act
                .replace(/\s*\(\s*I\s*:\s*(true|false)\s*,\s*R\s*:\s*(true|false)\s*,\s*A\s*:\s*(true|false)\s*\)\s*/gi, "")
                .replace(/\s*\[\s*I\s*:\s*(true|false)\s*,\s*R\s*:\s*(true|false)\s*,\s*A\s*:\s*(true|false)\s*\]\s*/gi, "")
                .replace(/\s*DUA\s*:\s*\{[^}]*\}\s*/gi, "")
                .replace(/\s*\(DUA[^)]*\)\s*/gi, "")
                .trim();
              return (
                <View key={idx} style={styles.faseActRow}>
                  <View style={[styles.faseActNum, { backgroundColor: fase.color + "15" }]}>
                    <Text style={{ color: fase.color, fontSize: 11, fontWeight: "700" }}>{idx + 1}</Text>
                  </View>
                  <Text className="text-sm text-foreground flex-1 leading-5" style={{ marginLeft: 8 }}>{cleanAct}</Text>
                  {/* DUA Squares */}
                  <View style={styles.duaSquaresRow}>
                    <View style={[styles.duaSquareSmall, { backgroundColor: dua.representacion ? "#EC4899" : "#EC489930" }]} />
                    <View style={[styles.duaSquareSmall, { backgroundColor: dua.accionExpresion ? "#1E3A5F" : "#1E3A5F30" }]} />
                    <View style={[styles.duaSquareSmall, { backgroundColor: dua.implicacion ? "#22C55E" : "#22C55E30" }]} />
                  </View>
                </View>
              );
            })}
          </View>
        );
      })}
    </View>
  );
}

// ==========================================
// COMPONENTES DE FORMULARIO
// ==========================================
function SectionTitle({ title, emoji, colors }: { title: string; emoji: string; colors: any }) {
  return (
    <View style={styles.sectionTitle}>
      <Text style={{ fontSize: 18 }}>{emoji}</Text>
      <Text className="text-lg font-semibold text-foreground" style={{ marginLeft: 8 }}>{title}</Text>
    </View>
  );
}

function FormField({
  label, value, onChangeText, placeholder, multiline, keyboardType, colors,
}: {
  label: string; value: string; onChangeText: (text: string) => void; placeholder: string;
  multiline?: boolean; keyboardType?: "default" | "numeric"; colors: any;
}) {
  return (
    <View className="px-5 mt-3">
      <Text className="text-sm font-medium text-muted mb-1">{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={colors.muted}
        multiline={multiline}
        keyboardType={keyboardType || "default"}
        textAlignVertical={multiline ? "top" : "center"}
        style={[styles.input, { backgroundColor: colors.surface, borderColor: colors.border, color: colors.foreground, minHeight: multiline ? 100 : 48 }]}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  scrollContent: { paddingBottom: 40 },
  backButton: { flexDirection: "row", alignItems: "center" },
  destrezaInfo: { borderRadius: 14, padding: 16, borderWidth: 1 },
  destrezaInfoHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  destrezaCode: { fontSize: 20, fontWeight: "800" },
  destrezaCompact: { borderRadius: 12, padding: 12, borderWidth: 1 },
  stepIndicator: { flexDirection: "row", alignItems: "center", marginTop: 12 },
  stepBadge: { width: 30, height: 30, borderRadius: 15, alignItems: "center", justifyContent: "center" },
  stepBadgeText: { color: "#fff", fontSize: 15, fontWeight: "800" },
  temaBadge: { flexDirection: "row", alignItems: "center", borderRadius: 12, padding: 14, borderWidth: 1 },
  totalDurationBadge: { flexDirection: "row", alignItems: "center", borderRadius: 10, padding: 10, borderWidth: 1, marginBottom: 4 },
  faseCard: { borderRadius: 12, borderWidth: 1, borderLeftWidth: 4, padding: 14, marginTop: 10 },
  faseCardHeader: { flexDirection: "row", alignItems: "center", marginBottom: 10 },
  faseCardTitle: { fontSize: 14, fontWeight: "700", marginLeft: 8, flex: 1 },
  durationBadge: { flexDirection: "row", alignItems: "center", paddingHorizontal: 8, paddingVertical: 3, borderRadius: 10 },
  faseActRow: { flexDirection: "row", alignItems: "flex-start", marginTop: 6 },
  faseActNum: { width: 22, height: 22, borderRadius: 11, alignItems: "center", justifyContent: "center" },
  sectionTitle: { flexDirection: "row", alignItems: "center", paddingHorizontal: 20, marginTop: 24, marginBottom: 4 },
  input: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12, fontSize: 15, lineHeight: 22 },
  row: { flexDirection: "row", gap: 0 },
  saveBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", borderRadius: 14, paddingVertical: 16, gap: 10 },
  saveBtnText: { color: "#fff", fontSize: 18, fontWeight: "700" },
  generateBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", borderRadius: 14, paddingVertical: 16, gap: 10 },
  generateBtnText: { color: "#fff", fontSize: 18, fontWeight: "700" },
  backBtnFull: { marginTop: 20, paddingVertical: 14, paddingHorizontal: 28, borderRadius: 12 },
  duaBanner: { borderRadius: 10, padding: 10, borderWidth: 1, alignItems: "center" as const },
  aiButton: { flexDirection: "row" as const, alignItems: "center" as const, justifyContent: "center" as const, borderRadius: 14, paddingVertical: 14, paddingHorizontal: 20 },
  toggleRow: { flexDirection: "row", alignItems: "center", paddingVertical: 8 },
  temaAlternativo: { borderRadius: 12, padding: 12, borderWidth: 1, marginTop: 8 },
  duaLegend: { borderRadius: 10, padding: 10, borderWidth: 1, marginBottom: 8 },
  duaSquare: { width: 14, height: 14, borderRadius: 2 },
  duaSquaresRow: { flexDirection: "row", gap: 3, marginLeft: 6, marginTop: 2 },
  duaSquareSmall: { width: 12, height: 12, borderRadius: 2 },
  duaSquareLarge: { width: 18, height: 18, borderRadius: 3 },
  duaPrincipiosBox: { borderRadius: 12, padding: 14, borderWidth: 1 },
  duaPrincipioRow: { flexDirection: "row", alignItems: "center", paddingVertical: 6, gap: 10 },
  bloquesContainer: { borderRadius: 12, padding: 12, borderWidth: 1 },
  bloqueRow: { flexDirection: "row", alignItems: "flex-start", paddingVertical: 4 },
  estilosGrid: { borderRadius: 12, padding: 14, borderWidth: 1 },
  estiloRow: { flexDirection: "row", alignItems: "center", paddingVertical: 6, gap: 8 },
  pctInput: { width: 50, borderWidth: 1, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 4, fontSize: 14, textAlign: "center" as const },
});
